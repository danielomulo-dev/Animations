(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[196,98,83,146],[302,0,194,116],[366,118,72,130],[281,118,83,146],[0,98,194,116],[0,0,300,96]]}
];


// symbols:



(lib.blackcar = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.redcar = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.tiretracks = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.totalqaurtz = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.total = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.redcar();
	this.instance.parent = this;
	this.instance.setTransform(-36,-65);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-36,-65,72,130), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.blackcar();
	this.instance.parent = this;
	this.instance.setTransform(-41.5,-73);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-41.5,-73,83,146), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tiretracks();
	this.instance.parent = this;
	this.instance.setTransform(-26.75,-47,0.6438,0.6438);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-26.7,-47,53.4,94), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.tiretracks();
	this.instance.parent = this;
	this.instance.setTransform(-26.75,-47,0.6438,0.6438);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-26.7,-47,53.4,94), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// red_car
	this.instance = new lib.Symbol5();
	this.instance.parent = this;
	this.instance.setTransform(-61,14);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({y:35},44,cjs.Ease.get(1)).wait(15).to({y:14},51,cjs.Ease.get(1)).wait(18).to({rotation:14.9992,x:-55.45,y:10.05},27,cjs.Ease.get(1)).wait(12).to({x:-51.2,y:-2.1},23,cjs.Ease.get(1)).wait(12).to({rotation:0,x:-61,y:14},30,cjs.Ease.get(1)).wait(14));

	// tire_tracks
	this.instance_1 = new lib.Symbol3();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-59.25,66);
	this.instance_1.alpha = 0.5391;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(128).to({regX:-0.1,regY:0.1,rotation:14.9992,x:-72.15,y:79.8},27,cjs.Ease.get(1)).wait(47).to({regX:0,regY:0,rotation:0,x:-59.25,y:66},30,cjs.Ease.get(1)).wait(14));

	// black_car
	this.instance_2 = new lib.Symbol4();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-0.5,35);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).to({y:13},44,cjs.Ease.get(1)).wait(15).to({y:35},51,cjs.Ease.get(1)).wait(18).to({rotation:14.9992,x:10.8,y:0.9},27,cjs.Ease.get(1)).wait(47).to({rotation:0,x:-0.5,y:35},30,cjs.Ease.get(1)).wait(14));

	// tire_tracks_copy
	this.instance_3 = new lib.Symbol2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-1.25,66);
	this.instance_3.alpha = 0.5391;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(128).to({regX:-0.1,regY:0.1,rotation:14.9992,x:-11.35,y:75.8},27,cjs.Ease.get(1)).wait(47).to({regX:0,regY:0,rotation:0,x:-1.25,y:66},30,cjs.Ease.get(1)).wait(14));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-110,-80.3,179.8,212.39999999999998);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// cars
	this.instance = new lib.Symbol1();
	this.instance.parent = this;
	this.instance.setTransform(178.5,153);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(10));

	// total_quartz
	this.instance_1 = new lib.totalqaurtz();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-42,-23);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(10));

	// logo
	this.instance_2 = new lib.logo();
	this.instance_2.parent = this;
	this.instance_2.setTransform(106,-11);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(10));

	// total_bottle
	this.instance_3 = new lib.total();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,154);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(10));

	// background
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#DC1535").s().p("A9mX/MAAAgv9MA7NAAAMAAAAv9g");
	this.shape.setTransform(157.5,130.55);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(10));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(108,102,239,182.10000000000002);
// library properties:
lib.properties = {
	id: 'B9533641699FD048843803C1DBE378D6',
	width: 300,
	height: 250,
	fps: 15,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_P_.png", id:"index_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['B9533641699FD048843803C1DBE378D6'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;