(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[652,164,146,250],[0,303,193,150],[652,0,300,162],[800,164,146,250],[0,0,650,301]]},
		{name:"index_atlas_NP_", frames: [[0,0,160,600]]}
];


// symbols:



(lib.background = function() {
	this.initialize(ss["index_atlas_NP_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.blueband = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.lemon = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.plate = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.shadow = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.smoke_1 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("AgUAlQgKgGgGgJQgFgIAAgOQAAgMAFgJQAFgJAKgFQAKgFALAAQAOAAAJAFQAJAGAFAJQAFAKAAAMIAAACIg4AAQAAAJAEAFQAFADAHAAQAEABAEgCQADgBACgFIAaAAQgCAKgGAFQgGAGgIAEQgIACgJAAQgMAAgKgEgAARgKQgBgFgFgEQgEgDgGgBQgFABgEADQgEADgCAGIAfAAIAAAAg");
	this.shape.setTransform(51.925,0.65);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AgcAnIAAhMIAbAAIAAAMQADgGAHgEQAGgDAJAAIAFAAIAAAaIgGgCIgGgBQgIABgDADQgEADgCAFQAAAEgBAHIAAAfg");
	this.shape_1.setTransform(44.35,0.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF00").s().p("AgWAlQgLgGgGgJQgGgJAAgNQAAgMAGgJQAGgJALgFQAKgFAMAAQAMAAALAFQAKAFAHAJQAGAJAAAMQAAANgGAJQgHAKgKAEQgLAFgMAAQgMAAgKgEgAgJgOQgDACgDAFQgCAEAAADQAAAIAFAEQAEAFAIABQAIgBAFgFQAEgEAAgIQAAgDgCgEQgCgFgEgCQgEgCgFAAQgFAAgEACg");
	this.shape_2.setTransform(35.575,0.65);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AApA5IgIhAIAAAAIgbBAIgLAAIgahAIAAAAIgKBAIgdAAIAThxIAdAAIAWA8IAYg8IAeAAIARBxg");
	this.shape_3.setTransform(23.225,-1.15);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFF00").s().p("AgQAyIAAg2IgJAAIAAgWIAJAAIAAgXIAaAAIAAAXIAQAAIAAAWIgQAAIAAA2g");
	this.shape_4.setTransform(8.15,-0.5);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("AgUAlQgJgDgGgHQgFgIAAgMIAAguIAcAAIAAAoIAAAJQABAEADACQADACAFAAQAFAAADgCQAEgCABgEIABgJIAAgoIAbAAIAAAuQAAAMgGAIQgFAHgJADQgJADgMAAQgLAAgJgDg");
	this.shape_5.setTransform(0.35,0.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFF00").s().p("AgfA0QgOgHgJgOQgHgOAAgSQAAgNAEgKQAFgLAKgIQAIgIAMgEQALgEALAAQAMAAALAEQAMAEAIAIQAJAIAGALQAEAKAAANQAAASgHAOQgJAOgOAHQgOAIgSAAQgRAAgOgIgAgPgaQgHAEgFAHQgEAGAAAIQAAAJAEAIQAFAHAHAFQAHAEAIAAQAJAAAHgEQAHgFAFgHQAEgIAAgJQAAgIgEgGQgFgHgHgEQgHgEgJgBQgIABgHAEg");
	this.shape_6.setTransform(-11.25,-1.175);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF00").s().p("AgZA6QgJgGgFgJQgFgKAAgLQAAgLAFgJQAFgIAJgGQAIgGAMABQAGAAAGACQAGADAFAFIAAg3IAbAAIAAB7IgbAAIAAgIIgBAAQgDAFgHADQgGACgGABQgLgBgJgFgAgIAIQgDACgDAEQgCAEAAAEQAAAIAFAFQAFAEAHABQAIgBAFgEQAEgFABgIQAAgEgCgEQgDgEgDgCQgEgDgGAAQgFAAgEADg");
	this.shape_7.setTransform(-28.375,-1.6);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFF00").s().p("AANAoIAAgmIAAgHQAAgFgCgDQgEgEgGAAQgEAAgDACQgEADgBAEIgBAIIAAAoIgcAAIAAhMIAcAAIAAAKQAFgHAGgDQAEgDAJAAQAKAAAHAEQAGAEADAHQACAIAAAJIAAAvg");
	this.shape_8.setTransform(-38.25,0.525);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFF00").s().p("AgNA9IAAhMIAbAAIAABMgAgKghQgEgFAAgGQAAgHAEgFQAEgEAGAAQAGAAAFAEQAEAFAAAHQAAAGgEAFQgFADgGABQgGgBgEgDg");
	this.shape_9.setTransform(-45.475,-1.6);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF00").s().p("AggA5IAAhxIBBAAIAAAZIgjAAIAAATIAfAAIAAAYIgfAAIAAAtg");
	this.shape_10.setTransform(-51.7,-1.15);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FF0000").s().p("Ap1CbQgeAAAAgeIAAj5QAAgeAeAAITrAAQAeAAAAAeIAAD5QAAAegeAAg");
	this.shape_11.setTransform(0.025,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-65.9,-15.5,131.9,31), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#492915").s().p("AggA3QgJgEgFgKQgGgIABgPQgBgMAEgMQAEgNAHgMQAHgMALgIQALgIANAAQAKABAHADQAFADADAFQABAFAAAGQAAAJgEAJQgEAKgMAIQgLAKgWAMQABAJAHAFQAFADAIAAQAIAAAIgDQAKgDAHgGQAIgGAGgHQAEAAABADQACACgCADQgHAMgMAIQgLAJgLAEQgLAFgMgBQgLABgIgFgAgGgiQgHAGgDAIQgDAJgCAJQgCAIAAAGQARgKAJgLQAKgMAAgLQAAgDgBgDQgCgCgDgBQgIAAgFAHg");
	this.shape.setTransform(-84.6,62.3);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#492915").s().p("AgYBIQgFgDgCgIQgBgHACgNIAPhEIgMAAQAAgGACgEQADgEAFAAIAFAAIAEgTQACgHAFgEQAFgDAGAAIAGABIAFACIgHAeIARAAQABAGgCAEQgDAEgFAAIgLAAIgMA/QgCAKACAEQABADAFAAQAGAAAHgDQAGgEAFgEIADACIABADIgBADIgBACQgJAKgLAGQgLAHgMAAQgHAAgFgDg");
	this.shape_1.setTransform(-92.4531,60.725);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#492915").s().p("AgdA3QgIgEgDgHQgDgHABgIQABgHAFgFQAFgGAJABQACgBADABIAEACQgDADgBAEIgBAIQAAAIAEADQAFAEAFAAQAEAAAEgCQAEgCADgEQACgEAAgGQAAgGgDgDIgKgGIgKgIQgGgDgDgGQgEgHAAgKQAAgJAEgJQAEgHAJgFQAIgGANAAQAPABAHAFQAHAGAAALQAAAJgFAFQgFAFgGAAIgFgBIgEgDIACgFIABgHQAAgGgDgDQgDgDgEAAQgFgBgEAFQgDAFAAAJQAAAIADAEQADAEAGAEIALAGQAGACAEAFQADAGAAAIQABAMgFAIQgFAKgKAEQgLAGgQgBQgMABgHgFg");
	this.shape_2.setTransform(-100.9625,62.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#492915").s().p("AALA5QgEgCgEgFQgDgFAAgJQgGALgJAGQgJAGgKAAQgJAAgFgDQgGgEgDgGQgDgHgCgGIgBgMQABgQAEgNQAEgOAIgLQAJgMAKgHQAKgGANgBQAGAAAGACQAGACAEAEQADgEAEgBQAEgBAFgBIAGABIAEADIgQBKQgCAKACAEQADADAEABQAHgBAHgDQAGgEAFgEIACADIABACIAAADIgCADQgFAGgHAFQgHAFgHADQgHAEgGgBQgGAAgFgCgAgOgjQgHAFgFAKQgEAKgCAKQgCAKAAAJQAAAJAEADQADAFAGAAQAFAAAGgFQAHgEADgGIAOg9IgGgBIgGgBQgIABgIAGg");
	this.shape_3.setTransform(-110.1,62.3);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#492915").s().p("AgYBIQgFgDgCgIQgBgHACgNIAPhEIgMAAQAAgGACgEQADgEAFAAIAFAAIAEgTQACgHAFgEQAFgDAGAAIAGABIAFACIgHAeIARAAQABAGgCAEQgDAEgFAAIgLAAIgMA/QgCAKACAEQABADAFAAQAGAAAHgDQAGgEAFgEIADACIABADIgBADIgBACQgJAKgLAGQgLAHgMAAQgHAAgFgDg");
	this.shape_4.setTransform(-119.0531,60.725);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#492915").s().p("AgdBPQgGgDgDgIQgDgHABgMQAFgqAIgdQAHgdALgQQAJgPAPAAQAIAAAFAFQAGAFAAAIQAAAKgFAOQgFAPgKAUQgKARgOAYIgBAEIAAAEQgBAJADAEQAEADAFAAQAHABAHgEQAHgDAGgGQAGgFADgGQADAAACACQABADgBAEQgEAKgJAJQgKAIgLAFQgLAFgLAAQgIAAgGgEgAAJg4QgEALgFASQgDASgEAYQAJgSAGgQQAHgQADgMQADgLAAgEIgBgEIgDgBQgEAAgEALg");
	this.shape_5.setTransform(-131.205,59.95);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#492915").s().p("AALA5QgFgCgDgFQgDgFAAgJQgGALgJAGQgJAGgKAAQgJAAgFgDQgGgEgDgGQgDgHgCgGIgBgMQABgQAEgNQAFgOAHgLQAJgMAKgHQAKgGANgBQAGAAAGACQAGACAEAEQADgEAEgBQAEgBAFgBIAGABIAEADIgQBKQgCAKACAEQADADAEABQAHgBAHgDQAGgEAFgEIACADIABACIAAADIgCADQgFAGgHAFQgHAFgHADQgHAEgGgBQgGAAgFgCgAgOgjQgHAFgFAKQgEAKgCAKQgCAKAAAJQAAAJAEADQADAFAGAAQAFAAAGgFQAHgEADgGIAOg9IgGgBIgFgBQgJABgIAGg");
	this.shape_6.setTransform(-141.05,62.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#492915").s().p("AgpA6IgEgCIAShXIAAgFIgCgBIgCABIgCACQgDgCAAgEQgBgEAEgDQAFgFAHgDQAGgDAHAAQAHAAACADQADADgCAHIgCAMQAHgOAHgFQAIgGAHAAQAJAAAEAGQAEAFAAAHQAAAGgCAEQgCAFgEAEQgEADgGAAIgEAAIgDgBIACgDIABgEQAAgBAAgBQgBAAAAgBQAAAAAAgBQgBAAAAAAQgCgCgDAAQgDAAgEADQgDACgEAHQgDAHgEAMQgEAMgFAUIgCAOQgCAIgGADQgFADgHAAIgGgBg");
	this.shape_7.setTransform(-151.925,62.3481);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#492915").s().p("AAHA5QgFgDgCgFQgDgGABgKQgHALgJAHQgIAIgKAAQgJAAgGgFQgFgEgCgHQgCgGABgIIACgOIAKguQABgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgCAAIgCACQgDgBAAgEQgBgEAEgDQAFgFAHgDQAGgDAHAAQAHAAADADQADADgCAGIgOBBQgBAHACADQACADAFABQAGgBAFgDQAGgDAEgFIANhBQACgHAFgEQAGgDAGAAIAGABIAFACIgQBLQgCAKACADQACAEAFAAQAGAAAHgEQAHgDAEgFIADADIABADIgBACIgBADQgGAGgGAGQgHAEgHADQgIAEgGAAQgGAAgFgCg");
	this.shape_8.setTransform(-161.33,62.35);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#492915").s().p("AgYBIQgFgDgCgIQgBgHACgNIAPhEIgMAAQAAgGACgEQADgEAFAAIAFAAIAEgTQACgHAFgEQAFgDAGAAIAGABIAFACIgHAeIARAAQABAGgCAEQgDAEgFAAIgLAAIgMA/QgCAKACAEQABADAFAAQAGAAAHgDQAGgEAFgEIADACIABADIgBADIgBACQgJAKgLAGQgLAHgMAAQgHAAgFgDg");
	this.shape_9.setTransform(-169.9531,60.725);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#492915").s().p("AALA5QgFgCgDgFQgDgFAAgJQgGALgJAGQgJAGgKAAQgJAAgFgDQgGgEgDgGQgDgHgCgGIgBgMQAAgQAFgNQAFgOAHgLQAJgMAKgHQALgGAMgBQAGAAAGACQAGACAEAEQADgEAEgBQAFgBAEgBIAGABIAEADIgPBKQgDAKADAEQACADAEABQAHgBAHgDQAGgEAEgEIADADIABACIAAADIgCADQgFAGgHAFQgHAFgHADQgHAEgGgBQgGAAgFgCgAgOgjQgHAFgFAKQgEAKgCAKQgCAKAAAJQAAAJAEADQADAFAGAAQAFAAAGgFQAHgEADgGIAOg9IgGgBIgFgBQgJABgIAGg");
	this.shape_10.setTransform(-178.75,62.3);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#492915").s().p("AAHA5QgFgEgCgHQgBgGABgOIAKgtQABgHgCgDQgCgEgEABQgDAAgGADQgGAEgEAFIgOBAQgCAJgGACQgFAEgHAAIgGgBIgEgCIAShXQABgBAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAIgBgBIgCAAIgDACQgDgBAAgEQAAgEADgDQAGgFAGgDQAHgDAGAAQAHAAADADQADADgCAGIgCALQAHgLAKgGQAJgGALAAQAGAAAEADQAFADABAIQACAIgDALIgKA0QgBAFABADQACACADAAQAHAAAHgEQAGgDAEgFIADADIACADIgBACIgCADQgHAJgMAHQgLAGgLABQgGAAgFgCg");
	this.shape_11.setTransform(-190.6,62.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#492915").s().p("AALBRQgFgCgDgGQgDgFAAgIQgGAKgJAGQgJAHgKAAQgIAAgGgEQgGgEgDgGQgDgGgBgHIgBgLQAAgQAEgOQAFgOAIgLQAIgMAKgGQALgHAMAAQAGAAAFABQAGACAEAEIAFgbQABgFgCgBQgCgBgDADIgDgEIgBgDQAAgCAFgEIALgHQAHgDAGAAQAHAAADADQADADgCAGIgYByQgCAKACADQACAEAFAAQAHAAAGgEQAHgDAEgFIADADIABADIAAACIgCADQgFAHgHAFQgHAFgHADQgHADgHAAQgFAAgFgCgAgOgMQgHAGgEAIQgFAKgCAKQgCALAAAKQAAAIAEAEQADAEAGAAQAFAAAHgEQAGgEAEgGIAAAAIANg9QgGgCgFAAQgKABgHAFg");
	this.shape_12.setTransform(-82.575,29.2);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#492915").s().p("AAHA5QgGgEgBgGQgCgIACgNIAKgtQABgHgCgDQgCgDgEAAQgDAAgGADQgGAEgEAFIgOBBQgCAIgGADQgFADgHAAIgGgBIgEgCIAThXQAAgBAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAIgCgBIgDAAIgCADQgDgCAAgEQgBgEAEgDQAGgFAGgDQAGgDAHAAQAHAAADADQADADgCAGIgCALQAIgKAJgHQAJgGALAAQAGAAAEADQAFAEABAHQACAIgCAMIgLA0QgBAFABACQACACADAAQAHAAAHgEQAGgDAEgFIADADIABADIAAACIgCADQgHAJgMAHQgLAGgLABQgGAAgFgCg");
	this.shape_13.setTransform(-94.4,31.6);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#492915").s().p("AALA5QgEgBgEgGQgDgFAAgJQgGAKgJAHQgJAGgKABQgIAAgHgFQgFgDgDgHQgDgFgBgHIgBgMQgBgPAFgOQAEgOAJgMQAHgLALgHQAKgHAMAAQAHABAGACQAGABAEAEQADgDAFgCQAEgBAEAAIAFAAIAGADIgQBKQgCAKACAEQACAEAFgBQAGABAGgEQAHgDAEgFIAEACIABAEIgBACIgBACQgGAHgHAFQgHAFgHADQgHAEgHAAQgFAAgFgDgAgOgkQgHAHgEAJQgFAKgCAKQgCAJAAAKQAAAIADAFQAEAEAFgBQAGABAHgEQAGgFAEgGIAMg8IgFgCIgGgBQgJABgHAFg");
	this.shape_14.setTransform(-105.55,31.55);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#492915").s().p("AgdA3QgIgFgDgGQgDgHABgIQABgHAFgFQAFgFAJgBIAFABIAEADQgDACgBAEIgBAIQAAAIAEAEQAFADAFAAQAEAAAEgCQAEgCADgFQACgDAAgGQAAgFgDgEIgKgHIgKgHQgGgDgDgHQgEgGAAgKQAAgKAEgIQAEgIAJgEQAIgFANgBQAPAAAHAGQAHAFAAAMQAAAKgFAEQgFAFgGgBIgFAAIgEgCIACgGIABgHQAAgHgDgDQgDgCgEAAQgFAAgEAEQgDAFAAAJQAAAIADADQADAFAGADIALAHQAGADAEAFQADAFAAAIQABAMgFAJQgFAIgKAFQgLAGgQAAQgMAAgHgFg");
	this.shape_15.setTransform(-123.0125,31.55);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#492915").s().p("AgdA3QgIgFgDgGQgDgHABgIQABgHAFgFQAFgFAJgBIAFABIAEADQgDACgBAEIgBAIQAAAIAEAEQAFADAFAAQAEAAAEgCQAEgCADgFQACgDAAgGQAAgFgDgEIgKgHIgKgHQgGgDgDgHQgEgGAAgKQAAgKAEgIQAEgIAJgEQAIgFANgBQAPAAAHAGQAHAFAAAMQAAAKgFAEQgFAFgGgBIgFAAIgEgCIACgGIABgHQAAgHgDgDQgDgCgEAAQgFAAgEAEQgDAFAAAJQAAAIADADQADAFAGADIALAHQAGADAEAFQADAFAAAIQABAMgFAJQgFAIgKAFQgLAGgQAAQgMAAgHgFg");
	this.shape_16.setTransform(-131.8625,31.55);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#492915").s().p("AghA3QgIgFgFgIQgFgJgBgPQABgMADgMQAEgNAHgMQAIgMAKgIQALgHANgBQALAAAFAEQAGADACAFQACAFAAAGQABAJgFAJQgEAJgNAJQgKAKgXANQADAIAFAEQAGAEAIAAQAIAAAJgDQAIgEAIgFQAJgGAFgGQAEgBACADQACACgCAEQgJALgLAJQgKAHgMAFQgLAFgMAAQgKAAgKgFgAgHgjQgFAHgEAJQgEAIgBAJQgCAIAAAGQARgKAJgLQAKgLAAgMQAAgEgCgCQgCgDgCAAQgIABgGAFg");
	this.shape_17.setTransform(-139.65,31.55);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#492915").s().p("AAHA5QgGgEgBgGQgBgIABgNIAJgtQACgHgCgDQgCgDgDAAQgEAAgGADQgGAEgEAFIgOBBQgCAIgGADQgFADgGAAIgHgBIgEgCIAThXQAAgBAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAIgDgBIgCAAIgCADQgDgCAAgEQgBgEAEgDQAFgFAHgDQAGgDAIAAQAGAAADADQADADgCAGIgCALQAHgKAKgHQAKgGAKAAQAGAAAEADQAFAEACAHQABAIgCAMIgMA0QgBAFACACQACACADAAQAHAAAHgEQAGgDAFgFIACADIABADIAAACIgCADQgIAJgKAHQgLAGgMABQgGAAgFgCg");
	this.shape_18.setTransform(-150.4,31.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#492915").s().p("AAGBRQgFgEgBgGQgCgIACgNIAJguQACgFgBgDQgBgEgFAAQgFAAgGADQgFADgFAFIgOBCQgCAIgGADQgFADgHAAIgFgBIgEgBIAdiIQABgFgCgBQgDgBgDADIgDgEIAAgDQAAgCAFgEIALgHQAGgDAHAAQAGAAADADQADADgBAGIgMA5QAGgKAHgFQAIgGAIAAQAHAAAFACQAHAEADAHQADAHgDAOIgLA0QgBAFACACQACACADAAQAHAAAGgEQAHgDAEgFIADADIABADIAAACIgCADQgIAJgLAHQgLAGgMABQgFAAgGgCg");
	this.shape_19.setTransform(-161.375,29.2);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#492915").s().p("AgdA3QgIgFgDgGQgDgHABgIQABgHAFgFQAFgFAJgBIAFABIAEADQgDACgBAEIgBAIQAAAIAEAEQAFADAFAAQAEAAAEgCQAEgCADgFQACgDAAgGQAAgFgDgEIgKgHIgKgHQgGgDgDgHQgEgGAAgKQAAgKAEgIQAEgIAJgEQAIgFANgBQAPAAAHAGQAHAFAAAMQAAAKgFAEQgFAFgGgBIgFAAIgEgCIACgGIABgHQAAgHgDgDQgDgCgEAAQgFAAgEAEQgDAFAAAJQAAAIADADQADAFAGADIALAHQAGADAEAFQADAFAAAIQABAMgFAJQgFAIgKAFQgLAGgQAAQgMAAgHgFg");
	this.shape_20.setTransform(-172.2125,31.55);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#492915").s().p("AggA3QgJgFgFgIQgGgJABgPQgBgMAEgMQAEgNAHgMQAHgMALgIQALgHANgBQAKAAAHAEQAFADADAFQABAFAAAGQAAAJgEAJQgEAJgMAJQgLAKgWANQABAIAHAEQAFAEAIAAQAIAAAIgDQAKgEAHgFQAIgGAGgGQAEgBABADQACACgCAEQgHALgMAJQgLAHgLAFQgLAFgMAAQgLAAgIgFgAgGgjQgHAHgDAJQgDAIgCAJQgCAIAAAGQARgKAJgLQAKgLAAgMQAAgEgBgCQgCgDgDAAQgIABgFAFg");
	this.shape_21.setTransform(-180,31.55);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#492915").s().p("AgpA6IgEgCIAShXIAAgFIgCgBIgCABIgCACQgDgCAAgEQgBgEAEgDQAFgFAHgDQAGgDAHAAQAHAAACADQADADgCAHIgCAMQAHgOAHgFQAIgGAHAAQAJAAAEAGQAEAFAAAHQAAAGgCAEQgCAFgEAEQgEADgGAAIgEAAIgDgBIACgDIABgEQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAQgCgCgDAAQgDAAgEADQgDACgEAHQgDAHgEAMQgEAMgFAUIgCAOQgCAIgGADQgFADgHAAIgGgBg");
	this.shape_22.setTransform(-189.775,31.5981);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#492915").s().p("AhCB/QgGgDgDgFQgEgGAAgKQAAgDADgCQABgBAEAAQABAGAFADQAEADAGAAQAHAAAGgHQAFgHAFgPQAEgPAGgYIAVhkIgLAAQgBgGADgEQACgEAGAAIADAAIACgIQADgPAHgLQAHgKAKgGQAKgGALAAQAOAAAHAGQAIAFgBAMQAAAJgEAFQgFAFgHAAIgEgBIgFgDIADgIIABgHQAAgDgCgCQgCgBgEAAQgGAAgDAEQgEAFgDAHQgDAIgCAIIgBAHIARAAQABAGgCAEQgDAEgFAAIgLAAIgWBkQgFAfgIAUQgHATgKAKQgLAJgQAAQgGAAgGgDg");
	this.shape_23.setTransform(-197.85,33.175);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#492915").s().p("AgzBkQgGgDgEgHQgEgGAAgJQAAgLAGgKQAGgJAKgIQAKgIALgGIAXgKIACgJIACgIQgFAIgJAGQgJAGgJAAQgJAAgGgEQgFgEgDgGQgDgFgBgGIgCgMQAAgQAFgOQAFgOAHgMQAJgLAKgHQALgHALAAQAHAAAGACQAFACAFAEQADgEAEgBIAIgCIAHABIAEACIgTBbIgBAFIgBAEIASgJIAPgKQACACABADQAAADgDADIABAAIgIAGIgNAHIgQAIQgDAQgGAQQgFAPgIANQgHANgLAHQgKAIgPAAQgHAAgGgDgAgaApQgLAHgGAIQgGAIgBAIQAAAEACACIAEADIAEABQAMABAIgNQAJgNAIgcQgNAFgKAHgAgHhPQgHAGgEAKQgFAJgCALQgCAKAAAKQAAAIADAFQAEADAFAAQAGAAAGgEQAGgEAFgGIAMg+IgFgBIgFgBQgKABgHAFg");
	this.shape_24.setTransform(-88.9,5.125);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#492915").s().p("AAHA4QgFgCgCgIQgBgGABgOIAKgsQABgIgCgDQgCgDgEAAQgDAAgGAEQgGADgEAFIgOBBQgCAHgFADQgGAEgHAAIgFgBIgGgCIAThYQABAAAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAIgBgBIgCABIgDABQgCgBgBgEQAAgEADgDQAFgFAHgDQAHgDAGAAQAHAAADADQADADgCAHIgCAKQAHgKAKgHQAJgGALAAQAGAAAFADQAEADABAIQACAHgDAMIgKA0QgCAFACADQACACAEAAQAGAAAGgDQAHgEAEgEIAEACIABADIgBADIgCACQgHAKgMAGQgKAHgMAAQgGAAgFgDg");
	this.shape_25.setTransform(-100.05,0.85);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#492915").s().p("AgVBPQgGgCgDgGQgDgGACgLIAOg/IAAgDQAAgBgBAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgCABIgDABQgCgBgBgEQAAgEADgDQAGgFAGgDQAHgDAGAAQAGAAADADQADADgBAHIgNBBQgCAJACAFQABADAFAAQAGAAAHgDQAGgEAFgEIADACIABADIgBADIgBACQgJAKgKAGQgLAHgLAAQgGAAgFgDgAgGg2QgEgEAAgHQABgGAFgFQAEgEAHgBQAHABAEAEQAEAFAAAGQgCAHgEAEQgFAFgHABQgGgBgEgFg");
	this.shape_26.setTransform(-108.165,-1.45);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#492915").s().p("AgYBIQgFgDgCgIQgBgHACgNIAPhEIgMAAQAAgGACgEQADgEAFAAIAFAAIAEgTQACgHAFgEQAFgDAGAAIAGABIAFACIgHAeIARAAQABAGgCAEQgDAEgFAAIgLAAIgMA/QgCAKACAEQABADAFAAQAGAAAHgDQAGgEAFgEIADACIABADIgBADIgBACQgJAKgLAGQgLAHgMAAQgHAAgFgDg");
	this.shape_27.setTransform(-113.8531,-0.775);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#492915").s().p("AgdA3QgIgEgDgHQgDgHABgIQABgHAFgGQAFgEAJAAIAFAAIAEADQgDACgBAEIgBAIQAAAIAEAEQAFADAFAAQAEAAAEgCQAEgCADgFQACgEAAgFQAAgGgDgDIgKgGIgKgHQgGgEgDgGQgEgHAAgKQAAgJAEgIQAEgIAJgGQAIgEANAAQAPgBAHAGQAHAFAAALQAAALgFAEQgFAFgGgBIgFgBIgEgCIACgFIABgHQAAgGgDgDQgDgEgEAAQgFABgEAEQgDAFAAAJQAAAHADAFQADAEAGADIALAHQAGADAEAEQADAGAAAJQABALgFAJQgFAJgKAEQgLAFgQABQgMgBgHgEg");
	this.shape_28.setTransform(-122.3625,0.8);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#492915").s().p("AALA6QgFgCgDgGQgDgFAAgJQgGAKgJAHQgJAGgKABQgJgBgFgDQgGgFgDgGQgDgGgCgGIgBgMQAAgPAFgOQAFgOAHgLQAJgMAKgHQALgGAMAAQAGAAAGABQAGACAEAEQADgDAEgCQAFgCAEABIAGAAIAEACIgPBMQgDAJADAEQACAEAEAAQAHAAAHgEQAGgEAEgEIADADIABADIAAACIgCACQgFAHgHAFQgHAFgHADQgHADgGABQgGAAgFgCgAgOgkQgHAHgFAJQgEAJgCALQgCAKAAAJQAAAJAEAEQADADAGAAQAFAAAGgDQAHgEADgHIAOg8IgGgCIgFAAQgJAAgIAFg");
	this.shape_29.setTransform(-131.5,0.8);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#492915").s().p("AgdBPQgGgDgDgHQgDgIABgMQAFgqAIgcQAHgeALgPQAJgQAPAAQAIAAAFAFQAGAEAAAJQAAAKgFAPQgFAOgKAUQgKASgOAWIgBAFIAAAEQgBAJADAEQAEADAFABQAHgBAHgDQAHgDAGgFQAGgGADgHQADAAACADQABADgBADQgEALgJAIQgKAJgLAFQgLAFgLAAQgIAAgGgEgAAJg4QgEAKgFATQgDATgEAXQAJgSAGgQQAHgRADgLQADgLAAgEIgBgEIgDgBQgEAAgEALg");
	this.shape_30.setTransform(-141.105,-1.55);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#492915").s().p("AACALIgIgCQgEgCgFAAQgFAAgDACIgEADIgCgEIgBgFQAAgEAGgFQAFgEAKAAIAMABIANABIAGgBQADgBADgCIACAFIABADQAAAGgFAFQgGAFgJAAQgFABgEgCg");
	this.shape_31.setTransform(-149.475,0.2);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#492915").s().p("AgzBkQgHgDgDgHQgEgGAAgJQAAgLAGgKQAGgJAKgIQAKgIALgGIAXgKIACgJIACgIQgFAIgJAGQgIAGgKAAQgJAAgFgEQgGgEgDgGQgDgFgCgGIgBgMQABgQAEgOQAFgOAHgMQAJgLAKgHQAKgHAMAAQAHAAAGACQAFACAFAEQADgEAEgBIAIgCIAHABIAEACIgTBbIgBAFIgBAEIATgJIAOgKQACACABADQAAADgDADIABAAIgIAGIgNAHIgQAIQgEAQgFAQQgFAPgIANQgGANgMAHQgKAIgPAAQgHAAgGgDgAgbApQgKAHgGAIQgGAIAAAIQAAAEABACIAEADIAEABQALABAJgNQAIgNAJgcQgNAFgLAHgAgHhPQgHAGgFAKQgEAJgCALQgCAKAAAKQAAAIAEAFQADADAGAAQAFAAAGgEQAGgEAEgGIAOg+IgGgBIgFgBQgKABgHAFg");
	this.shape_32.setTransform(-158.85,5.125);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#492915").s().p("AAHA4QgGgCgBgIQgCgGACgOIAKgsQABgIgCgDQgCgDgEAAQgDAAgGAEQgGADgEAFIgOBBQgCAHgGADQgFAEgHAAIgGgBIgEgCIAThYQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAIgCgBIgDABIgCABQgDgBAAgEQgBgEAEgDQAGgFAGgDQAGgDAHAAQAHAAADADQADADgCAHIgCAKQAIgKAJgHQAJgGALAAQAGAAAEADQAFADABAIQACAHgCAMIgLA0QgBAFABADQACACADAAQAHAAAHgDQAGgEAEgEIADACIABADIAAADIgCACQgHAKgMAGQgLAHgLAAQgGAAgFgDg");
	this.shape_33.setTransform(-170,0.85);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#492915").s().p("AggA1QgHgFgEgJQgDgJAAgMQAAgNAEgMQAEgOAIgLQAIgMALgHQAKgHAMAAQANgBAIAGQAIAFADAKQAEAJAAALQAAANgEANQgFAOgHALQgIAMgMAHQgLAHgMABQgMAAgIgHgAACgkQgFAFgFAIQgEAIgDAKQgCAHAAAKQAAAOAFAHQAEAGAGABQAGgBAGgGQAGgFAEgKQAFgIACgKQADgKAAgJQAAgKgDgGQgEgGgHAAQgIAAgGAFg");
	this.shape_34.setTransform(-181.2,0.8);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#492915").s().p("AgdBPQgGgDgDgHQgDgIABgMQAFgqAIgcQAHgeALgPQAJgQAPAAQAIAAAFAFQAGAEAAAJQAAAKgFAPQgFAOgKAUQgKASgOAWIgBAFIAAAEQgBAJADAEQAEADAFABQAHgBAHgDQAHgDAGgFQAGgGADgHQADAAACADQABADgBADQgEALgJAIQgKAJgLAFQgLAFgLAAQgIAAgGgEgAAJg4QgEAKgFATQgDATgEAXQAJgSAGgQQAHgRADgLQADgLAAgEIgBgEIgDgBQgEAAgEALg");
	this.shape_35.setTransform(-189.155,-1.55);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#492915").s().p("Ag0BjQgGgDgEgGQgFgGABgKQAAgOAJgLQAKgKAPgIQAPgJATgIIACgIIADgIQgHAHgHAFQgHAFgJAAQgMAAgEgGQgFgHgBgJQAAgKACgKIALgwQAAAAAAgBQAAgBAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAIgCAAIgCACQgDgBgBgEQAAgEAEgDQAFgFAGgDQAHgDAHAAQAGAAAEADQACADgBAGIgOBDQgBAFABAEQACADAFAAQAFAAAEgCQAFgCADgEIAQhFQABgIAGgDQAFgDAHAAIAGAAIAEADIgTBbIgBAFIgBADIASgIIAOgLQAEADAAADQAAADgDADIgHAFIgOAHIgPAIIgKAgQgFAQgIAMQgHANgLAIQgMAHgOAAQgIAAgGgDgAgaAqQgLAGgFAHQgGAHAAAJQAAAEACADIADADIAFABQAHAAAGgFQAHgGAFgMQAGgLAGgTQgPAHgKAGg");
	this.shape_36.setTransform(-120,-25.575);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#492915").s().p("AggA2QgHgGgEgJQgDgJgBgLQABgOAEgMQAEgOAIgMQAIgLALgHQALgHAMgBQAMABAIAFQAIAGADAJQAEAJABAMQgBANgEAMQgFAOgHALQgJAMgLAHQgLAHgMAAQgMAAgIgFgAADgkQgGAFgFAIQgEAIgCAJQgDAIAAAJQAAAPAFAHQAEAGAGAAQAGAAAGgGQAGgGAFgIQAEgKACgJQADgKAAgJQAAgKgDgGQgDgGgIAAQgHAAgGAFg");
	this.shape_37.setTransform(-130.25,-29.95);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#492915").s().p("Ag0B6QgGgDgEgGQgFgGAAgKQABgOAJgLQAJgKAQgIQAPgJATgIIADgMIACgNIAOhAIAAgEQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAIgCAAIgCACQgDgBAAgEQgBgEAEgDQAFgFAHgDQAGgDAHAAQAHAAADADQADADgCAGIgRBRIgBAFIgBAEIASgKQAJgFAGgFQACADABADQAAADgDADIgIAFIgNAIIgPAIIgKAgQgFAQgIAMQgHANgLAIQgMAHgPAAQgGAAgHgDgAgaBBQgKAGgGAHQgGAHAAAJIACAHIAEADIADABQAMAAAJgNQAJgNAIgbQgOAHgLAGgAAhhhQgEgEAAgHQABgHAFgEQAEgFAHAAQAHAAAFAFQAEAEAAAHQgBAHgFAEQgEAFgHAAQgHAAgFgFg");
	this.shape_38.setTransform(-141.075,-27.875);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#492915").s().p("AAHA5QgGgEgBgHQgCgGACgOIAKgtQABgHgCgDQgCgEgEABQgDAAgGADQgGAEgEAFIgOBAQgCAJgGACQgFAEgHAAIgGgBIgEgCIAThXQAAgBAAgBQAAgBAAAAQAAgBAAAAQAAgBAAAAIgCgBIgDAAIgCACQgDgBAAgEQgBgEAEgDQAGgFAGgDQAGgDAHAAQAHAAADADQADADgCAGIgCALQAIgLAJgGQAJgGALAAQAGAAAEADQAFADABAIQACAIgCALIgLA0QgBAFABADQACACADAAQAHAAAHgEQAGgDAEgFIADADIABADIAAACIgCADQgHAJgMAHQgLAGgLABQgGAAgFgCg");
	this.shape_39.setTransform(-145.7,-29.9);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#492915").s().p("AgjBTQgJgGgFgKQgEgLAAgMQAAgMAEgKQAFgLAJgIQAJgIANgEQgJgGgFgJQgFgJAAgKQABgLAFgLQAGgKALgHQAKgHAQAAQAOABAHAEQAJADAEAHQADAHAAAHQAAAHgCAFQgCAGgFADQgEADgFAAQgEAAgEgCQgDgDgDgEQAGgCACgFQAEgFAAgFQAAgGgEgEQgDgDgHAAQgJAAgGAEQgFAFgEAIQgDAHAAAJQABAHACAHQADAHADAEQAGAGAIACIAAAFIgDADQgLABgHAFQgHAHgFAJQgEAJAAAKQAAAIADAGQADAHAGAEQAGAEAJAAQAKAAALgDQALgDAKgHIADADIABACIAAADIgDADQgHAHgLAGQgKAEgLADQgKACgKAAQgPAAgKgGg");
	this.shape_40.setTransform(-155.75,-32.95);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-204.2,-48.1,132.6,127), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.lemon();
	this.instance.parent = this;
	this.instance.setTransform(-36,-28,0.3732,0.3732);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-36,-28,72,56), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.shadow();
	this.instance.parent = this;
	this.instance.setTransform(-55,-94.15,0.7534,0.7534);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-55,-94.1,110,188.3), null);


(lib.Symbol1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.blueband();
	this.instance.parent = this;
	this.instance.setTransform(-60,-102.75,0.8219,0.8219);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol1, new cjs.Rectangle(-60,-102.7,120,205.5), null);


(lib.steam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.smoke_1();
	this.instance.parent = this;
	this.instance.setTransform(106.5,0,0.3538,0.3538,90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.steam, new cjs.Rectangle(0,0,106.5,230), null);


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2_copy
	this.instance = new lib.steam();
	this.instance.parent = this;
	this.instance.setTransform(83,97.45,0.9274,0.9274,0,0,0,53.4,114.8);
	this.instance.alpha = 0.1016;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(259).to({_off:false},0).to({scaleX:1.0492,scaleY:1.0492,y:11.75,alpha:0.25},47).to({regX:53.2,scaleX:1.1036,scaleY:1.1036,x:82.9,y:-26.55},21).wait(3));

	// Layer_1_copy
	this.instance_1 = new lib.steam();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_1.alpha = 0.1016;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(234).to({_off:false},0).to({regX:53.2,scaleX:1.1036,scaleY:1.1036,x:82.9,y:-26.55,alpha:0.25},71).to({_off:true},1).wait(24));

	// Layer_2
	this.instance_2 = new lib.steam();
	this.instance_2.parent = this;
	this.instance_2.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_2.alpha = 0.1016;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(187).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(72));

	// Layer_1
	this.instance_3 = new lib.steam();
	this.instance_3.parent = this;
	this.instance_3.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_3.alpha = 0.1016;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(163).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.25},71).to({_off:true},1).wait(95));

	// Layer_2
	this.instance_4 = new lib.steam();
	this.instance_4.parent = this;
	this.instance_4.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_4.alpha = 0.1016;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(116).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(143));

	// Layer_1
	this.instance_5 = new lib.steam();
	this.instance_5.parent = this;
	this.instance_5.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_5.alpha = 0.1016;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(92).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.25},71).to({_off:true},1).wait(166));

	// Layer_2
	this.instance_6 = new lib.steam();
	this.instance_6.parent = this;
	this.instance_6.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_6.alpha = 0.1016;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(68).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},48).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(190));

	// Layer_1
	this.instance_7 = new lib.steam();
	this.instance_7.parent = this;
	this.instance_7.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_7.alpha = 0.1016;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(44).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.2383},72).to({_off:true},1).wait(213));

	// Layer_2
	this.instance_8 = new lib.steam();
	this.instance_8.parent = this;
	this.instance_8.setTransform(36.7,93.8,0.5638,0.5638,0,0,0,53.4,114.8);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.2109},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75,alpha:0.1016},21).to({_off:true},1).wait(261));

	// Layer_1
	this.instance_9 = new lib.steam();
	this.instance_9.parent = this;
	this.instance_9.setTransform(36.7,93.8,0.5638,0.5638,0,0,0,53.4,114.8);
	this.instance_9.alpha = 0.0898;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.3281},47).to({_off:true},1).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.6,-153.2,135.20000000000002,358.4);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Symbol6();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.1742,scaleY:1.1742},23).to({scaleX:1,scaleY:1},24).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-77.4,-18.2,154.9,36.4);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// btn
	this.instance = new lib.btn();
	this.instance.parent = this;
	this.instance.setTransform(80.7,518.35,1.025,1.025);
	this.instance.alpha = 0.1016;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(112).to({_off:false},0).to({alpha:1},20,cjs.Ease.get(1)).wait(156));

	// text
	this.instance_1 = new lib.Symbol5();
	this.instance_1.parent = this;
	this.instance_1.setTransform(234.15,85.8,1.1081,1.1081,0,0,0,0.1,0.1);
	this.instance_1.alpha = 0;
	this.instance_1.shadow = new cjs.Shadow("rgba(255,255,255,1)",0,0,4);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(61).to({_off:false},0).to({y:71.4,alpha:1},30,cjs.Ease.get(0.5)).wait(197));

	// lemons
	this.instance_2 = new lib.Symbol3();
	this.instance_2.parent = this;
	this.instance_2.setTransform(33.05,450.05,1.1081,1.1081,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(288));

	// plate
	this.instance_3 = new lib.plate();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,364,0.6575,0.6575);

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(288));

	// smoke
	this.instance_4 = new lib.Symbol4();
	this.instance_4.parent = this;
	this.instance_4.setTransform(46.7,235.35,1.1081,1.1081);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(288));

	// blueband
	this.instance_5 = new lib.Symbol1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(86.55,164.9,1.1081,1.1081,0,0,0,0,101.9);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(1).to({regY:101.8,y:173.5},0).wait(1).to({regY:101.9,y:182.7},0).wait(1).to({regY:101.8,y:192.15},0).wait(1).to({y:202.25},0).wait(1).to({y:212.7},0).wait(1).to({y:223.7},0).wait(1).to({y:235.15},0).wait(1).to({regY:101.9,y:247.05},0).wait(1).to({y:259.45},0).wait(1).to({regY:102,y:272.3},0).wait(1).to({y:285.65},0).wait(1).to({regY:101.9,y:299.3},0).wait(1).to({y:313.55},0).wait(1).to({y:328.25},0).wait(1).to({y:343.4},0).wait(1).to({y:359.1},0).wait(1).to({y:375.15},0).wait(1).to({regX:0.1,regY:102,scaleX:1.4054,scaleY:0.7022,x:86.7,y:391.75},0).wait(1).to({regY:101.9,scaleX:1.4423,scaleY:0.652,y:368.4},0).wait(1).to({regY:102,scaleX:1.4054,scaleY:0.7022,y:347.85},0).wait(1).to({regX:0,regY:101.9,scaleX:1.1081,scaleY:1.1081,x:86.55,y:329.95},0).wait(1).to({y:314.85},0).wait(1).to({y:302.45},0).wait(1).to({y:292.8},0).wait(1).to({regY:102,y:286},0).wait(1).to({regY:101.9,y:281.85},0).wait(1).to({y:280.5},0).wait(1).to({y:281.85},0).wait(1).to({regY:102,y:286},0).wait(1).to({regY:101.9,y:292.8},0).wait(1).to({y:302.45},0).wait(1).to({y:314.85},0).wait(1).to({y:329.95},0).wait(1).to({y:347.8},0).wait(1).to({y:368.4},0).wait(1).to({regX:0.1,scaleX:1.3053,scaleY:0.8469,x:86.7,y:391.7},0).wait(1).to({regY:102,scaleX:1.3297,scaleY:0.815,y:379.35},0).wait(1).to({regY:101.9,scaleX:1.3053,scaleY:0.8522,y:369.05},0).wait(1).to({regX:0,scaleX:1.1081,scaleY:1.1081,x:86.55,y:361},0).wait(1).to({y:355.4},0).wait(1).to({regY:102,y:352},0).wait(1).to({y:350.9},0).wait(1).to({y:352},0).wait(1).to({regY:101.9,y:355.4},0).wait(1).to({y:361},0).wait(1).to({regY:102,y:369.05},0).wait(1).to({regY:101.9,y:379.25},0).wait(1).to({regX:0.1,regY:102,scaleX:1.2188,scaleY:0.8864,x:86.65,y:391.75},0).wait(1).to({regX:0,scaleX:1.1081,scaleY:1.1081,x:86.55,y:385.25},0).wait(1).to({regY:101.9,y:380.5},0).wait(1).to({y:377.65},0).wait(1).to({y:376.7},0).wait(1).to({y:377.65},0).wait(1).to({y:380.5},0).wait(1).to({regY:102,y:385.25},0).wait(1).to({y:391.85},0).wait(232));

	// shadow
	this.instance_6 = new lib.Symbol2();
	this.instance_6.parent = this;
	this.instance_6.setTransform(85.45,289.35,1.1081,1.1081,0,0,0,0,0.1);
	this.instance_6.alpha = 0.1016;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).to({alpha:1},19).wait(269));

	// background
	this.instance_7 = new lib.background();
	this.instance_7.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(288));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(73.1,238.2,124.20000000000002,361.8);
// library properties:
lib.properties = {
	id: 'A09197C163357440BDB87146867A7ADF',
	width: 160,
	height: 600,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_P_.png", id:"index_atlas_P_"},
		{src:"images/index_atlas_NP_.jpg", id:"index_atlas_NP_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['A09197C163357440BDB87146867A7ADF'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;