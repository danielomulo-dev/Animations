(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[0,0,2000,2000]]},
		{name:"index_atlas_P_2", frames: [[0,0,2000,2000]]},
		{name:"index_atlas_P_3", frames: [[0,252,300,250],[0,0,300,250],[302,231,195,227],[0,504,214,231],[302,0,197,229]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["index_atlas_P_3"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["index_atlas_P_3"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.Image = function() {
	this.initialize(ss["index_atlas_P_3"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.Image_1 = function() {
	this.initialize(ss["index_atlas_P_3"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.Image_2 = function() {
	this.initialize(ss["index_atlas_P_3"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.black = function() {
	this.initialize(ss["index_atlas_P_2"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.blue = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.zoom = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.1538,0.1538);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.zoom, new cjs.Rectangle(0,0,30,34.9), null);


(lib.xhd = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_2();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.1574,0.1574);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.xhd, new cjs.Rectangle(0,0,31,36.1), null);


(lib.Tween1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AglAmQgOgOAAgYQAAgXAOgOQAOgPAYABQAYAAAOAOQANAOAAAYQAAAYgNAOQgPAOgYAAQgXgBgOgOg");
	this.shape.setTransform(10.4778,-3.3005,0.158,0.1578);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgqC6IAAlzIBVAAIAAFzg");
	this.shape_1.setTransform(10.4857,1.0875,0.158,0.1578);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAZEHQgegCgUACQgMABgDgFQgEgEAAgLIAAnnQAAgMAEgEQAEgEALABQAaABAbgBQAJgBAEAEQAEAEAAAKIgBD3IABDyQAAAMgEAEQgEADgIAAIgEAAg");
	this.shape_2.setTransform(13.1239,-0.1071,0.158,0.1578);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgqEGIAAoLIBVAAIAAILg");
	this.shape_3.setTransform(28.9134,-0.1081,0.158,0.1578);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAlC7IglAAQgXAAgOgBQgFAAgFgDQgGgDgBgEIiAlgIgCgKIBbAAQADAAAEAFQADAFACAFIBREUIAHgSIBNkBQADgKAEgDQAFgEAJAAIBQAAIiBFoQgDAIgDADQgEAEgHAAIgCgBg");
	this.shape_4.setTransform(-0.4145,1.0876,0.158,0.1578);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhMCzQhUglgQhiQgRhmAzhDQBEhbB5AbQAxALAkAoQAjAnAJA1IAFAsQgCBAgXArQgZAwg1AZQgoASgmAAQgmAAgmgRgAhLhJQglBVAtBKQAYAnArAAQAsgBAZgnQATgfAGg2IgHgiQgFgVgFgNQgVg3g2gBIgCAAQg0AAgXAzg");
	this.shape_5.setTransform(-25.5067,1.0937,0.158,0.1578);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgXDBQhHgNgmgzQgxhAALhZQALhbA+guQBHg1BSAcQBTAcAYBVQAQA5gJApIj5AAQgCAhASAbQARAbAdAJQAiAKAagLQAagLAXgkIBIAiQgVA0gvAVQgmARgqAAQgTAAgUgEgAg0hlQgXAZgDAmICdAAQABgkgWgYQgVgYghgCIgEAAQgdAAgXAXg");
	this.shape_6.setTransform(33.2725,1.0734,0.158,0.1578);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgsDCQhNgMgkhQQgcg8AEg5QADg8Alg2QAqg9BGgFQBFgEAzA2IAKAJIACgiQABgRAQABIA/AAIAAF1IhGAAQgCAAgEgFQgDgFgBgEQgBgHgBgbIgHAEQg1A1g9AAQgMAAgMgCgAhEhUQgxBXAyBTQAZAoArgBQAtgBAZgpQALgRAGgWQADgOAFgdIgIgjQgFgWgGgOQgUgzg1gDIgEAAQguAAgWAog");
	this.shape_7.setTransform(17.6064,1.0841,0.158,0.1578);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag2DAQhSgSgfhcQgnh2BBheQArg8BGgEQBGgEAxA3IAEAHIAFgCIAEgkQAAgDADgEQAEgEACAAQAPgBA2AAIAAF1IhNAAIgFguIgEABQg3A2g+AAQgQAAgRgEgAhAhaQgbAjABA4QAAA6AbAiQAbAiAogCQAogCAYgjQAOgVAFgbQAFgWgBgkIgEgVQgEgQgEgMQgUgwgvgIIgNgBQgkAAgbAig");
	this.shape_8.setTransform(5.7555,1.0794,0.158,0.1578);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AhZDbIgKgJIgFAwIhNAAIAAn1QAAgOAEgFQAFgGANACQAUACAegCQAKgBAEAEQAEAEAAAKIgBCbIABANIAhgTQATgLAOgEQA+gUA2AdQA2AeAWBCQAoB2hABdQgqA9hGAFIgNABQg8AAgvgxgAgDg0Qg2ACgVA2QgFAOgEATIgHAjIAHAiQAEAUAFANQAVA2A0ADQA1ADAZgxQAmhMglhNQgXgxgzAAIgDAAg");
	this.shape_9.setTransform(24.4315,-0.0435,0.158,0.1578);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AiPD9IhUgBIA1ieIBvlJQADgKAFgDQAGgEAJAAIBXABQAEAAAGAEQAFADACAEICjHjIAAAJIhfAAQgFAAgGgNIgdhjQgDgKgEgEQgFgEgKABQhHABhIgBQgKAAgEADQgFADgCAIIgdBlQgDAJgEADQgEADgHAAIgCAAgAgDijIg9DNIB+AAIg9jOg");
	this.shape_10.setTransform(-7.1047,0.0577,0.158,0.1578);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("ACfC8QgjgCgjACQgJAAgEgEQgEgDgDgJIhFkKIgDgBIhBD+QgHAagBAAQgBACgaAAIg/ABQgMAAgEgNIhclcIgBgNIBRABQADAAADAGQAEAGABAEIAnC6IASBRIAGgOIA/j3QAEgOAGgFQAGgGAOABQAZADAmgCQAKgBAFAEQAEAEADAKIBBD8QACAHAFAEIA4kIQACgJAEgEQAEgEAKABIBGAAIgcBpIhCD7QgDAKgEAEQgFAEgIAAIgDAAg");
	this.shape_11.setTransform(-17.7877,1.0829,0.158,0.1578);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AiHD8IhFAAIAAn4IBgABQAGAAAJANIDHEpQAFAIAIAFIAAlDIBWAAIAAH3IhPgBQgIAAgKgOIjglLIAAFHQAAALgDAEQgFAFgJAAIgCgBg");
	this.shape_12.setTransform(-32.5228,0.062,0.158,0.1578);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("EgnGAHdQgyAAgjgjQgjgjAAgyIAArJQAAgyAjgjQAjgjAyAAMBOMAAAQAyAAAjAjQAkAjAAAyIAALJQAAAygkAjQgjAjgyAAg");
	this.shape_13.setTransform(0.0018,0.0188,0.1581,0.1579);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-41.4,-7.5,82.9,15.1);


(lib.right = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._1();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.right, new cjs.Rectangle(0,0,300,250), null);


(lib.reno = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgbAcQgKgKAAgSQAAgRAKgKQAKgKARAAQARAAALAKQAKALAAAQQAAARgKALQgLAKgRAAQgRgBgKgJg");
	this.shape.setTransform(30.7388,69.3563,0.2365,0.2378);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgdCTIAAklIA7AAIAAElg");
	this.shape_1.setTransform(30.7388,74.5821,0.2365,0.2378);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AhNCWIAAklIAvABQAEAAABAHIADAjIAGgIQAdgsA1ADQAMAAAAAMIgBAuIggAAQgZAEgQAQQgPARgDAZIgCAoIAACLg");
	this.shape_2.setTransform(25.8015,74.4966,0.2365,0.2378);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgeDOIAAmcIA9AAIAAGcg");
	this.shape_3.setTransform(8.7655,73.1375,0.2365,0.2378);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AALC1QgXgGgPgUQgPgUgBgZIgBifIAAgPIgpAAIAAgyIAoAAIAAhGIA+AAIAABGIA5gBQAHAAADADQACADAAAGQgCAOACAOQAAAMgLgBIg5AAIAACdQAAAUAJAJQAIAKAUAAIAegCIAAAtQAAADgHADQgRAEgRAAQgRAAgQgEg");
	this.shape_4.setTransform(94.9331,73.8256,0.2365,0.2378);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AAXCTQgQgBghABQgJABgDgJIhlkTIgCgKIBAABQAFAAADAJIAzCjQAOAqAGAQIBFjbQAEgNAMABIA3AAIhmEZQgDAHgDADQgDACgGAAIgCAAg");
	this.shape_5.setTransform(50.3587,74.5709,0.2365,0.2378);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ABECWIgBgNIAAiiQAAgTgEgPQgGgbgdgHQgigJgbASQgbATgFAjIgCAdIAACXIg+AAIAAkkIAwAAQACAAADADIACAGIADAgIANgPQAZgaArgGQArgGAfASQArAaACA0QAAAtAACdIAAAGg");
	this.shape_6.setTransform(35.4043,74.487,0.2365,0.2378);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgQCZQhNgKgehEQgQgkABgiQAAhPAugrQAxgvBDANQBFANAbA9QAtBjg9BRQgmAzg+AAIgUgBgAg0hNQgXAcgBAxQAAAvAXAdQAXAdAhgCQAigCAUgfQARgdAAgqQAAgpgSgcQgUgfghgCIgEAAQgeAAgVAag");
	this.shape_7.setTransform(89.5665,74.5772,0.2365,0.2378);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgFCZQg1gFggghQgigjgGg2QgIhCAcgwQAUgjAjgRQAjgRAnAFQBQAKAZBRQAMAmgFAoIjHAAQADBEA1APQAcAIATgJQAUgJAUgfIAzAYQgOAlggARQgdARgmAAIgSgBgAgthSQgVAWAAAeICFAAQgCgigSgTQgRgTgdgBIgBAAQgaAAgTAVg");
	this.shape_8.setTransform(56.8116,74.5778,0.2365,0.2378);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgFCZQg2gGggghQgigjgGg5QgGhDAfgwQAshFBTAKQBPAKAZBSQALApgFAjIjFAAQgEAYAOAYQAOAYAWAJQAcAMAXgJQAXgJAWggIAyAYQgNAlghARQgdARgmAAIgSgBgAAAhnQgbABgUAWQgUAWABAcICGAAQgBgggTgVQgTgUgbAAIgCAAg");
	this.shape_9.setTransform(13.2345,74.5786,0.2365,0.2378);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgTCaQg6gDgigzQgcgqABg8QABg8AdgpQAigwA4gCQA3gCAmAtIAGAGIADgiQAAgCACgDQABgBAAAAQABgBAAAAQABAAAAAAQABgBAAAAIAxAAIAAEkIg3AAIgDgpIgFAFQglAsgzAAIgHAAgAg3hJQgVAdABAsQAAAtAVAdQAVAdAhAAQAhAAAVgdQAVgcAAgtQAAgmgOgaQgSgkgmgDIgFAAQghAAgWAdg");
	this.shape_10.setTransform(19.9055,74.5773,0.2365,0.2378);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("AgpDDQhFgYgehIQgphmAshmQAWg0AygbQAygbA4AHQBHAKAgAyQAEAGANAbIg4AbIgLgXQgUgmgwgDQgmgDgcAVQgZATgNAjQghBVAmBQQAUAqArAOQApAOAlgXQALgIAHgJQAHgJALgZIA4AZQgSA8g1AVQgkAPgjAAQgdAAgegLg");
	this.shape_11.setTransform(3.807,73.3561,0.2365,0.2378);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ABCDPIAAi4QAAgzgogKQgagGgXALQgYAKgJAXQgJATgBAYIgBCWIAAANIg9AAIAAmbIA9AAIAACXIAEADIAFgJQAZgYAngIQApgGAfAPQAvAZACA2IACCyIAAAhg");
	this.shape_12.setTransform(82.7569,73.1493,0.2365,0.2378);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("Ah2DGIAAmLIDtAAIAAA4IiqAAIAABoICfAAIAAA4IifAAIAAB7ICqAAIAAA4g");
	this.shape_13.setTransform(44.0138,73.3455,0.2365,0.2378);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AhYC3QgpgXgOgvIAzgYIAPAVQAIALAHAGQAwAkA8gaQAegMAAgmQAAgjgegNQgUgIgogLQg0gNgXgQQgrggAEg5QADg4AvgdQAxgeBGAMQA6AJAcAuIAKAXIg2AaIgEgJQgTgngtgBQgZAAgRAFQgfAIgCAjQgDAiAcALQAUAJAiAIQAyAMAZAPQAuAaAEA6QADAxgcAhQgZAegqALQgdAIgZAAQgvAAgngXg");
	this.shape_14.setTransform(75.8478,73.3556,0.2365,0.2378);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AA2DMIg3AAIAsheQAEgKgDgHIhjj9QAAgEgEgDIAAAVIgaAAQggAEgSATQgRAUgBAhIAAClIg/AAIAAkkIAwAAQABAAAAABQAAAAABAAQAAAAABABQAAAAABABIACAFIACAiIAIgJQAggvAxAJQAXAEAtABQAFAAACAIIA8C6IAMAkIACAAIBDjZQACgIAFgDQAEgDAIAAIA1ABIiQGEQgDAIgEADQgEACgGAAIgCAAg");
	this.shape_15.setTransform(65.5791,75.7921,0.2365,0.2378);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AndTrQkJiPhAkIIC5htQB0E5EsBGQEWBADViAQDziRAhk4QAOiCgdh/Qgch6g8hUQhOhuh1g4Qhrg1iPgIQiVgJhmAcQiAAjhSBgIiViJIOww3IwLAAIAAjWIVKAAIABBNQAAAtgDAgQAAAKgKANIgSAVIr4NfQGoggEDD2QBxBrBACWQA+COAHCgQAQFUjBD5QjBD5k8AuQhVANhPAAQjrAAjGhrg");
	this.shape_16.setTransform(93.6251,46.3892,0.1008,0.1008);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AsjVBMAAAgp9QAQgDAHgBIGyAAQEBAACwAIQEmAODJDKQDHDKATEoQAIB9gKBkQgMB1gnBkQhWDbioB5QikB1jsAUQh0AKisAAIkigBIg/AAIAAQPgAmKxlIiZAAIAASxIEuAEQCyABB4gHQCXgKBuhLQBwhNBAiLQAqheALhuQAKhfgOh1QgVi4hyh7Qh1h/i0gdQhJgLhlgEIiygDIhqgBIgrAAg");
	this.shape_17.setTransform(33.9746,14.0509,0.1008,0.1008);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AsjVBMAAAgp9QARgDAGgBIGzAAQEBAACwAIQEkAODJDJQDGDHAVEoQARDeg0CtQhGDmi0COQi2CRjvAMQh1AGisABIkhABIhAAAIAAQPgAkJxlIkJABQgFAAgMAFIAAStIEoAEQCuABB1gHQCcgJBxhLQB1hOBBiOQBFiagOjFQgTj8iLiJQiMiLj5gNQhigFiNAAIgZAAg");
	this.shape_18.setTransform(52.3124,14.0509,0.1008,0.1008);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("ArpVAMAAAgp/IXTAAIAADfIzUAAIAAOrISKAAIAADiIyJAAIAAQ1ITUAAIAADeg");
	this.shape_19.setTransform(29.1554,46.1561,0.1008,0.1008);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AmvUNQlzisi4muQiFk2ABl8QAAj9A2jVQA7jrB/jEQCgj5D5iDQDsh7EJAIQEJAIDkCKQDxCQCSEDQB7DYAxD6QAuDmgOEJQgWGVi4FCQhnCziaCAQiWB8i2A9QiiA2ifAAQjZAAjWhjgAiAx/QjDAeiTB0QiLBthbC2QklJJDhKwQBrFKESCmQCGBRCYAVQCTAVCQgnQCRgmB6hcQB+hfBViMQBnipAvjMQAqi0ABjcQgBjfgoizQgwjQhpinQiLjfjGheQiPhFisAAQhEAAhLALg");
	this.shape_20.setTransform(72.9407,14.0922,0.1008,0.1008);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgcVtQkJgIjkiHQjxiPiSkAQh+jbgyj9QgujpAQkOQAXmYC2k1QETnUHmhAQFBgqEBB2QD+B1C3EPQCGDEA+DxQA3DXABEDQgBD+g2DWQg7Drh/DEQifD3j4CBQjdB0j4AAIgeAAgAiAx+QjEAfiSBzQiMBthZC2Qk6KAERK+QB6E6EcCNQEPCIEchYQEchYCjkOQBoipAvjMQAqi0AAjcQAAjcgqi2QgvjNhoiqQiFjajOhiQiVhGipAAQhDAAhIAMg");
	this.shape_21.setTransform(73.0683,46.1758,0.1008,0.1008);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AgcVsQkIgHjliIQjxiPiSj/Qh7jXgzj6QgvjmAOkJQAWmkC4k4QELnGHQhJQFJg0EHB0QEFByC9EUQCIDFA/DyQA4DYAAEGQAAD9g2DVQg8Drh/DEQifD3j4CCQjdB0j4AAIgegBgAiAx/QjDAeiTB0QiLBthbC2QkoJSDnKxQBsFAEKCkQCGBSCYAWQCSAVCSgmQCRgmB6hbQB/heBViLQBpirAwjPQAqi5AAjsQAAjRgpivQgwjNhpinQiMjejFhfQiPhEirAAQhFAAhLALg");
	this.shape_22.setTransform(12.1452,14.0926,0.1008,0.1008);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AJ8U3QgfgQgcgpQj4lgn0q8QgQgWgRgKQgSgKgaABQhJABlvAAIAASFIj7AAMAAAgp+IAUgDIH2gCQEqAADLAIQEnALC5DAQC3C/AKErQAFCRgUBvQgYCFg+BrQimEflmApIgzAFINbSMIh0gBQhCgBgrAEIgQABQgkAAgbgOgAk1xnIltABQgCAAgEADIgHAEIAAQ4IAQAFIFgABQDPABCQgEQCXgEBqhFQBuhIA5iLQAihUAIhiQAHhTgKhnQgVjAhzhzQh1h0i8gJQiKgHjHAAIgaAAg");
	this.shape_23.setTransform(11.2532,46.1615,0.1008,0.1008);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AMjVBQgQgBgZgkIvH2nIn4rzIglgyMAAAAjwIjqAAMAAAgqCICDAAQBMAAA1ACQAPABAaAmIKNPNIMKSIMAAAgh6IDlAAMAAAAqBIhZAAIgPAAQgqAAgggCg");
	this.shape_24.setTransform(49.4418,46.159,0.1008,0.1008);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.reno, new cjs.Rectangle(0,0.1,101.8,80.60000000000001), null);


(lib.night = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Image_1();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.1543,0.1544);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.night, new cjs.Rectangle(0,0,33,35.7), null);


(lib.left = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._2();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.left, new cjs.Rectangle(0,0,300,250), null);


(lib.clear = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AgPAPQgFgFAAgKQAAgIAGgGQAGgGAIAAQAJABAHAFQAFAGAAAIQAAAKgGAFQgGAGgJAAQgJAAgGgGg");
	this.shape.setTransform(91.9647,76.2879,0.1514,0.1514);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("AgQBNIAAiZIAhABIAACYg");
	this.shape_1.setTransform(91.9647,78.0253,0.1514,0.1514);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AgpBOIAAiYIAZAAQAEAAABAGIABAQQAWgeAeAGIAAAfIgHAAQgSgBgLAKQgKAKgBATIAABVg");
	this.shape_2.setTransform(109.1579,78.0026,0.1514,0.1514);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgRBrIAAjWIAiAAIAADWg");
	this.shape_3.setTransform(89.1641,77.5598,0.1514,0.1514);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("AgaBuIAAh7IgVAAIAAgcIAVAAIAAgSQABgdAVgNQATgOAbALQAFACAAAEIABAUQgcABgHAHQgHAHAEAVIAgAAIAAAdIghAAIAAB7g");
	this.shape_4.setTransform(90.6136,77.5137,0.1514,0.1514);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AgiBHQghgUgCguQgCgzAlgXQAigVAgASQAiASAEAoIAAAYIhmAAQgBAMAGALQAGALALAFQAZAMAYgeIAXALIAFADQgJAXgXAIQgQAFgPAAQgUAAgSgKgAgWgoQgKALABAOIBAAAQAAgQgJgKQgJgKgPAAQgNABgJAKg");
	this.shape_5.setTransform(93.7922,78.0253,0.1514,0.1514);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("AgxA7QgagbAGgsQAGgwApgPQAfgLAcARQAbARAFAiIACASQABAKgLAAIheAAQAAAOAHALQAHALALAEQAbAJATgcIAdAOQgMAcgfAGQgLABgJAAQggAAgVgVgAgUgqQgKAJgCASIBBAAQAAgQgIgJQgJgKgNgBIgBAAQgNAAgJAJg");
	this.shape_6.setTransform(106.986,78.0265,0.1514,0.1514);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AgoBCQgigZAFgzQAFgxAogPQAfgNAcAQQAcAQAFAiIADAeIhoAAQAAAOAHAMQAGALAMAEQANAEALgEQALgEALgPIAdANQgKAYgWAHQgRAGgPAAQgXAAgUgPgAgYgnQgJALABAMIBBAAQAAgQgJgKQgKgJgOAAQgOAAgKAMg");
	this.shape_7.setTransform(87.3389,78.0309,0.1514,0.1514);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#000000").s().p("AgQBQQgfgFgQgfQgNgXADgeQADgeARgTQASgVAbAAQAagBASAVIAGAFIABgQQACgGAEAAIAaAAIAACYIggAAIgBgUIgEACQgVAWgZAAIgIAAgAAAgzQgSAAgKAQQgSAfAPAiQALAWAWAAQAWgCAJgXIAHgdIgFgRQgDgKgEgHQgKgPgRAAIgBAAg");
	this.shape_8.setTransform(111.2502,78.033,0.1514,0.1514);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#000000").s().p("AgVBPQghgIgNgmQgRguAagnQASgaAdgBQAbgCAVAXIACAEIADgBIACgVIAfAAIAACYIgfAAIgCgTIgCAAQgXAXgZAAIgNgBgAAAgzQgTAAgJASQgGAKgFAXIAFARQACAKAEAGQAJATATAAQASABALgSQAKgOAAgVQgBgVgJgOQgLgQgSAAIAAAAg");
	this.shape_9.setTransform(100.4163,78.0306,0.1514,0.1514);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#000000").s().p("AgyBVQgfgbgCguQgDg1AaggQAWgcAmgEQAngFAbAWQAPAMAEAUIgeAOIgCgDQgJgagcgDQgbgDgRAVQgRAVAAAjQAAAjARAWQAPAUAagCQAegBAMgfIAeAOQgEATgQAOQgRANgWADIgQABQgiAAgagWg");
	this.shape_10.setTransform(97.6701,77.6217,0.1514,0.1514);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#000000").s().p("Ag4BaQgPgLgFgUIAegOQAQAjAsgHQAUgDADgVQADgVgUgHIgmgLQgTgFgKgHQgOgKgFgQQgHgXAKgVQAKgUAXgIQAwgQAjAZQAOAKAFASIgdAOIgDgDQgIgPgRgFQgQgFgQAIQgNAHAAAOQAAAQANAEIAmAMQAkAJAMAUQANAYgIAYQgHAZgYALQgXALgVAAQgcAAgbgSg");
	this.shape_11.setTransform(84.7645,77.6276,0.1514,0.1514);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#000000").s().p("ABLBOIAAhgQAAgbgUgCQgOgCgKAHQgJAGgCAOQgCAFAAAMIAABTIgiAAIgBhkQgCgWgQgDQgLgCgKAEQgJAEgEAJQgFAKAAAMIAABYIgkAAIAAiYIAfAAIACAVQARgYAdAAQAegBAOAaQAUgdAlAEQARACAKAKQAMAKABAQQABAaAABZIgBACg");
	this.shape_12.setTransform(103.7725,78.0023,0.1514,0.1514);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#000000").s().p("AgPAPQgFgGAAgJQAAgIAGgGQAGgGAIAAQAJAAAGAGQAGAGAAAIQAAAKgGAFQgGAGgJAAQgJgBgGgFg");
	this.shape_13.setTransform(74.5857,76.326,0.1514,0.1514);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#000000").s().p("AgQBMIAAiXIAhAAIAACXg");
	this.shape_14.setTransform(74.5822,78.0632,0.1514,0.1514);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#000000").s().p("AgoBOIAAiYIAcAAIADAXQATgfAfAGIAAAfIgFAAQgTgBgMAKQgKAKAAAUIAABUg");
	this.shape_15.setTransform(66.2599,78.038,0.1514,0.1514);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#000000").s().p("AgQBrIAAjVIAhAAIAADVg");
	this.shape_16.setTransform(63.0809,77.5939,0.1514,0.1514);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#000000").s().p("AAIBeQgNgEgJgKQgIgLgBgPIAAhLIAAgLIgVAAIAAgcIAUgBIAAgiIAjAAIAAAiIAiAAIAAAdIgiAAIAABNQABAMAFAFQAFAEAMAAIALgBIAAAbQgLAEgLAAQgIAAgHgCg");
	this.shape_17.setTransform(81.3036,77.8254,0.1514,0.1514);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#000000").s().p("AgCBbQgUgLgBgaIgBhIIAAgNIgUAAIAAgcIATAAIAAgkIAkAAIAAAjIAiAAIAAAdIgiAAIAABNQAAAVAWgBIAMAAIAAAXQAAACgFADQgKACgJAAQgNAAgKgFg");
	this.shape_18.setTransform(64.4925,77.8238,0.1514,0.1514);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#000000").s().p("AANBoIAAgsIhWAAIAAgSQABgKAGgIQAbgmAzhPQAGgKAMAAQAOABACACQACACAAAOIAABxIAaAAIAAAfIgaAAIAAAsgAgkAdIAqAAIAGAAIAAhHg");
	this.shape_19.setTransform(50.4802,77.6544,0.1514,0.1514);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#000000").s().p("AANBnIAAgrIhVAAQgCgNACgGQABgKAFgIIBOh0QAHgLAKACIATAAIAACDIAaAAIAAAfIgaAAIAAArgAgjAdIAvAAIAAhEIgBgBg");
	this.shape_20.setTransform(47.9124,77.6521,0.1514,0.1514);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#000000").s().p("AgJBQQgdgBgRgXQgTgXAAghQAAghATgXQARgWAdgBQAagBATAUIADAGQAEgRADgCQAEgDAPAAIAJAAIAACYIgfAAIgCgUIgCgCIgCAFQgSAVgaAAIgCAAgAgBgzQgSAAgKASQgEAKgHAXIAGASIAFAQQAKARASABQASAAAMgQQAKgOgBgWQABgVgKgPQgMgPgRAAIgBAAg");
	this.shape_21.setTransform(68.349,78.0707,0.1514,0.1514);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#000000").s().p("AAhBsIAAhdQAAgfgagCQgPgBgLAIQgLAIgCAPIgBAzIAAAsIgjAAIAAjVIAjAAIAABPIAMgLQAbgQAfAJQAVAGAHAYQAEAJgBAHIAABrg");
	this.shape_22.setTransform(79.1653,77.5977,0.1514,0.1514);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#000000").s().p("AhHBoIAAjPIAvABQAbAAATADQAZADAOAWQAOAWgEAcQgEAYgQAPQgQAPgaABIgpABIAABIgAggADIAVgBIATgCQAYgDABgeQABgfgZgFIgUgCIgVgBg");
	this.shape_23.setTransform(57.0397,77.6469,0.1514,0.1514);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#000000").s().p("AgCBpQgugDgVgcQgNgSAAgWIgBiHIABgDIAjAAIABB6IAAATQAHAlAngBQAmAAAGgmIABiLIAmAAIABB/QAAAngYAWQgVAVgkAAIgFAAg");
	this.shape_24.setTransform(60.9578,77.6897,0.1514,0.1514);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#000000").s().p("AgsBkQgUgHgGgVIAbgNQAMAPARAEQAQAFAPgHQAYgKgFgmIgMAJQgXAQgYgHQgagIgNgaQgVgqAWgsQAQgeAggDQAfgDASAYIAEADIACgVIAfAAIAAAGIAACGQgBAUgHARQgJAYgdAHQgQAFgOAAQgWAAgTgJgAgBhPQgQABgJAOQgGAKgGAYIAFASQADAKADAFQAJAPAQACQAQABALgOQAMgNAAgYQAAgZgNgNQgKgLgOAAIgBAAg");
	this.shape_25.setTransform(76.4507,78.4952,0.1514,0.1514);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#000000").s().p("AA0BnQgEAAgDgGIhVh/QgDgEgFgEIAACNIgjAAIAAjOIAlABQAEAAAEAGIBPB2IAIALIAAiHIAiAAIAADOIgfgBg");
	this.shape_26.setTransform(72.4363,77.662,0.1514,0.1514);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#000000").s().p("AgVBlQgFgDgCgKIgEgQIgnh2IgBAAIAACUIgiAAIAAjNIAyAAQAEAAACAIIAyCaIAxiaQACgJAJABIAvAAIAADNIglAAIAAiSIgDgBIgtCMQgDAJgJgBIgQABIgDAAQgIAAgEgDg");
	this.shape_27.setTransform(53.7065,77.6661,0.1514,0.1514);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#000000").s().p("AgPB+IAAj7IAfAAIAAD7g");
	this.shape_28.setTransform(44.5593,77.7453,0.1514,0.1514);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#000000").s().p("AglBBQgbgVgBgmQgCgyAjgXQAigXApATQARAJAGAUIgdANQgKgOgJgEQgIgEgMAEQgQAFgHARQgKAZAKAaQAJAaAbgCQARgBAIgTIAeAOQgJAcgfAHQgKACgKAAQgYAAgTgQg");
	this.shape_29.setTransform(35.0785,78.0883,0.1514,0.1514);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#000000").s().p("Ag0BNIgUAAIADgHIAqhBQAFgFgFgHIgthFIAnABQAFAAACAGIAaAzIALgRQAFgKADgHQALgeAfAGIAKABIgrBCQgGAJAGAIQATAbAaAqIgmAAQgDAAgDgGIgdg0IgXAqQgIARgPAAIgGgBg");
	this.shape_30.setTransform(7.0845,78.086,0.1514,0.1514);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#000000").s().p("AgoBEQgdgUgDgkQgEgfANgXQALgVAVgJQAVgKAYAEQAVADAQAQQARAQAEAXIACAUQAAAcgOAUQgNAVgYAHQgNAEgLAAQgVAAgSgMgAgbgjQgWAjAVAjQAKARASAAQATAAAKgRQAEgHACgKIAFgSIgFgSQgDgKgDgGQgKgRgTgBQgRAAgKARg");
	this.shape_31.setTransform(13.5768,78.0959,0.1514,0.1514);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#000000").s().p("AgoBEQgdgTgEgkQgDghANgWQALgVAVgKQAVgJAYAEQAWAEAQAQQAQARAEAWIACATQAAAcgOAUQgOAVgXAHQgNAEgLAAQgUAAgTgMgAgcgjQgVAjAUAiQAKASATAAQATAAAKgSQADgGADgKIAFgSIgFgRQgEgLgDgGQgKgRgSgBQgSAAgKARg");
	this.shape_32.setTransform(16.1997,78.094,0.1514,0.1514);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#000000").s().p("AgpBJQgZgMgBgcIgBhoQAAAAAAgBQAAAAAAgBQABAAAAgBQAAAAABgBIADgCIAegBIAABZQAAAUAHAIQAHAJAPAAQAQABAKgKQAKgLABgRIAAhOIAAgLIAfAAQAFAAAAAIIAACRIgeAAIgDgUIgCgCIgEAHQgMANgUAEIgOACQgNAAgMgGg");
	this.shape_33.setTransform(27.1238,78.1149,0.1514,0.1514);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#000000").s().p("Ag8BpQgFAAgCgCQgBgBgBgGQAAgPALgMQARgPA1g3QASgRACgQQAEgbgVgKQgLgFgMACQgNADgIAJIgLARIgagPQAJgcAagLQAcgKAcAJQAfAJALAeQAKAdgUAaQgIALgOAPIgYAZIgaAcIABACIBUAAIAAAeIgIAAg");
	this.shape_34.setTransform(1.9668,77.6608,0.1514,0.1514);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#000000").s().p("AgLBQQgjgCgQgiQgag0AgguQARgYAdgCQAbgBAUAWIACAEIADgBIABgJIABgLIAfAAIAACYIgfAAIgCgUIgDACQgQAXgdAAIgFgBgAAAgzQgSAAgKARQgRAfAPAiQAKAVAWAAQAWgCAJgVQACgFAFgYQgCgWgJgOQgLgPgSAAIAAAAg");
	this.shape_35.setTransform(29.7574,78.0905,0.1514,0.1514);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#000000").s().p("AgLBQQgegCgRgaQgQgWAAgeQABgfAPgWQASgZAcgBQAcgCAVAWQABADADABIACgVIAgAAIAACYIggAAIgCgUIgDACQgUAWgaAAIgDAAgAgBgzQgSAAgKASQgFAKgGAXIAGASIAFAQQAKARASABQASABAMgRQAKgOAAgWQAAgVgKgPQgMgPgRAAIgBAAg");
	this.shape_36.setTransform(37.5427,78.0929,0.1514,0.1514);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#000000").s().p("AhNBnQgDgWAJgMIBdiCIAGgJIhiAAIAAggICTAAQACAXgJAMIhcCAIgHAKIBsAAIAAAgg");
	this.shape_37.setTransform(10.8574,77.6809,0.1514,0.1514);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#000000").s().p("AgVBsQgcgHgOgdQgYgzAegsQARgaAegBQAcgCARATIAEADIAAhPIAjAAIAADWIgeAAIgCgXIgMAOQgSAOgSAAQgIAAgHgCgAgYgKQgNANAAAaQAAAaANAOQAMANAPgBQARgBAJgPQAEgGADgLIAGgTIgGgTQgDgKgEgGQgJgPgQgBIgCAAQgPAAgLAMg");
	this.shape_38.setTransform(32.4739,77.6535,0.1514,0.1514);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#000000").s().p("Ag/A9QgWg9AWg9QAQgtAvAAQAwAAASAtQAKAbgBAiQABAigKAcQgSAtgwAAQgwgBgPgtgAgdg2QgEASgGAkIAFAcIAGAbQAFAWAXgBQAYABAHgWQAFgSACgQQAEgvgLgcQgHgWgXAAQgYAAgGAWg");
	this.shape_39.setTransform(4.5306,77.6885,0.1514,0.1514);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#000000").s().p("ABLBOIAAhkQgCgWgQgDQgLgCgJAEQgKAEgEAJQgFALAAANIAABWIgjAAIAAhgQAAgbgVgCQgOgCgJAHQgJAHgDANIgBATIAABRIgjAAIAAiYIAaAAQADAAABAFIACAQQASgYAcAAQAfgBAMAZIAGgGQALgNAUgEQATgEARAHQAYALABAaIAAByg");
	this.shape_40.setTransform(19.4638,78.0597,0.1514,0.1514);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#000000").s().p("ABLBOIAAhgQAAgbgUgCQgOgCgJAGQgKAHgDAMQgBAIAAAIIAABWIgiAAIgBhlQgCgUgQgEQgKgCgJADQgKADgEAJQgGALAAANIAABYIgkAAIAAiYIAeAAIADAVQARgYAeAAQAegBAMAaQAUgdAlAEQASACALALQALALABASQABASAAA+IAAAhg");
	this.shape_41.setTransform(40.8996,78.0629,0.1514,0.1514);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#000000").s().p("AAqB3IgEgDIgGgIQgEgJgHgDQgGgDgLABQgiADgcgXQgcgXgGglQgJg4AbgmQAfgsA4AHQA1AHASAwQAaBCgmA4QgCAEgSARIAbAmgAgqg+QgNAUAAAfQAAAdANAVQAQAYAaAAQAbABAPgZQAfgygegzQgPgZgcAAQgaAAgQAZg");
	this.shape_42.setTransform(24.1702,77.8742,0.1514,0.1514);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#000000").s().p("AgyAzQgTgTABggQAAgfASgTQATgSAfAAQAfAAATATQATATAAAeQAAAfgTATQgUATgeAAQggAAgSgSg");
	this.shape_43.setTransform(35.7639,61.2932,0.1515,0.1515);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#000000").s().p("Ag2EKIAAoUIBtAAIAAIUg");
	this.shape_44.setTransform(35.7564,67.354,0.1515,0.1515);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#000000").s().p("AiNEQIAAoUIBYABQACAAADAEQACAFABAEIAFBAIALgPQA2hPBgAFQALAAAFAFQAFAFAAAMIAABTIgeAAQgRgBgLACQguAGgdAeQgcAegGAuQgCAYgBAxIAAD8g");
	this.shape_45.setTransform(30.0027,67.2495,0.1515,0.1515);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#000000").s().p("Ag3F3IAArtIBvAAIAALtg");
	this.shape_46.setTransform(10.1798,65.6835,0.1515,0.1515);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#000000").s().p("AAUFIQgqgMgcgkQgbgkgBgtIgDkiIAAgbIhKAAIAAhaIBJAAIAAiAIByAAIAAB/IBngBQANAAAEAFQAFAEgBAMQgCAaACAaQABALgFAFQgEAEgMAAIhogBIABEfQAAAkAQAQQAQARAkABQAJABAtgFIAABSQAAAGgNAEQghAKgfAAQgdAAgdgJg");
	this.shape_47.setTransform(110.4835,66.4753,0.1515,0.1515);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#000000").s().p("AArEMQgkgDg4ACQgIABgFgEQgEgDgDgIIi4n1IgFgSQBcAAAZABQAEAAAEAGQAFAFACAGIBdEoQAXBGAOAkIAHgTIB2l8QAEgNAGgEQAHgFALAAIBmABIg1CRIiFFvQgFAMgFAFQgHAFgLAAIgCAAg");
	this.shape_48.setTransform(58.598,67.3426,0.1515,0.1515);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#000000").s().p("AB7ERIgCgYIAAkmQAAglgHgaQgLgwg1gOQg+gQgxAiQgxAhgIBAQgDAXgBAeIAAETIhwAAIAAoUQBCAAAUABQAEAAADAGQAEAFACAFIAEA6IAZgbQAtgvBOgLQBPgLA4AhQBPAvACBeQACBMAABsIAAC4IgBALg");
	this.shape_49.setTransform(41.1959,67.2347,0.1515,0.1515);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#000000").s().p("AgeEXQhAgIgygkQg2gmgbg8QgchAACg/QAAhIASg0QAUg5AtgqQBZhVB7AYQB9AXAxBwQAnBXgGBQQgGBWg3BKQgoA0g9AYQgqARgtAAQgQAAgQgCgAhgiLQgqAzgBBYQAABXApA0QAqA1A9gDQA+gEAkg6QAgg1AAhMQAAhJgig0Qgjg3g9gEIgGAAQg4AAgnAvg");
	this.shape_50.setTransform(104.2366,67.3388,0.1515,0.1515);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#000000").s().p("AgJEWQhhgJg6g8Qg+hAgLhhQgOh4AzhZQAlg/A/gfQA/gfBIAKQCSATAtCSQAVBFgIBJIlrAAQACA8AaAnQAaAnAvANQA0APAjgQQAkgRAmg5IBbAsQgZBDg5AgQg2AehGAAQgQAAgQgCgAhTiVQglAngBA4ID0AAQgEg/ghgjQgfghg1gCIgCAAQgvAAgkAmg");
	this.shape_51.setTransform(66.1074,67.3438,0.1515,0.1515);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#000000").s().p("AgKEWQhigKg6g9Qg/hCgJhmQgMh6A4hXQAog+A8gbQA7gaBJAJQCQASAtCVQAVBFgJBFIloAAQgHArAZAsQAZAsAoARQA0AVAqgQQAqgRAog6IBbArQgZBEg6AgQg2AehFAAQgRAAgQgCgAAAi7QgxABglAoQgkAoACAzIDzAAQAAg6gkgmQgigkgwAAIgFAAg");
	this.shape_52.setTransform(15.3826,67.3498,0.1515,0.1515);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#000000").s().p("AgkEYQhngGg/hdQgzhMAChtQAChuA1hLQA+hWBlgEQBlgEBFBSIAKALIAFg+QABgEAEgFQAEgFADAAQAUgBBFAAIAAIUIhkAAIgGhJIgJAHQhDBRhfAAIgMAAgAhkiGQgmA1ABBRQAABSAmA1QAmA1A9AAQA9AAAmg1QAmgzAAhSQAAhFgZgwQgihBhEgGIgNgBQg7AAgmA1g");
	this.shape_53.setTransform(23.142,67.3513,0.1515,0.1515);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#000000").s().p("AhLFjQh+gtg2iDQhMi5BRi6QApheBbgxQBbgxBmANQCBARA8BbQALASASArIhmAwIgTgpQglhFhXgHQhFgEgzAlQguAjgYA/Qg7CcBFCSQAkBMBNAZQBNAZBDgqQAUgMAMgRQANgRAVguIBkAvQggBrhgAoQhCAahAAAQg2AAg2gTg");
	this.shape_54.setTransform(4.399,65.9306,0.1515,0.1515);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#000000").s().p("AB5F3IgBlMQAAgwgSgcQgSgbglgJQgwgLgqASQgrATgRApQgRAngBApQgCA4ABBQIAACJIAAAYIhxAAIAArtIBxAAIAAETIAIAHQAFgPADgDQAsgsBKgNQBJgMA4AdQBYAsACBiQADBCAABgIACCjIAAA6g");
	this.shape_55.setTransform(96.3112,65.6911,0.1515,0.1515);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#000000").s().p("AjXFoIAArPIGwAAIAABmIk3AAIAAC8IEiAAIAABoIkiAAIAADfIE3AAIAABmg");
	this.shape_56.setTransform(51.219,65.9146,0.1515,0.1515);

	this.shape_57 = new cjs.Shape();
	this.shape_57.graphics.f("#000000").s().p("AiiFNQhJgogZhXIBcgrQAKAMARAZQAPAVANAKQBXBCBugvQA2gXAAhFQAAhAg2gWQgsgThCgRQgvgLgYgJQgmgOgbgTQhPg7AHhmQAGhnBVg0QBZg3CAAWQBsARAwBUIATAqIhhAuIgJgPQghhJhTgBQgtAAghAJQg4APgDBAQgEA9AyAVQAoARA6AOQAuAKAZAIQAmAMAcARQBTAxAHBpQAGBZgzA9QgtA3hNATQg0AOgvAAQhUAAhJgpg");
	this.shape_57.setTransform(88.2703,65.928,0.1515,0.1515);

	this.shape_58 = new cjs.Shape();
	this.shape_58.graphics.f("#000000").s().p("ABiFzQgUgBgdAAIgzAAIASgpIA9iCQAIgRgGgNIiznNQgDgHgGgFIAAAlIgYAAQgOgBgIABQg7AIggAjQggAkgBA9IAAEsIhxAAIAAoUQBDAAATABQADAAADAFQADAEABAFQADAWACAoIANgRQAcgoAlgSQAngTAsAIQAZAEAmACIA+ADQADABADAEQAFAFABAEIBtFUIAWBBIADAAIAsiLIBPkAQAEgPAIgFQAHgGAQABIBeABIgkBlIjhJeQgFANgHAFQgHAFgMAAIgDAAg");
	this.shape_58.setTransform(76.3182,68.7496,0.1515,0.1515);

	this.shape_59 = new cjs.Shape();
	this.shape_59.graphics.f("#000000").s().p("AkfL3QighXgnifIBwhBQBGC8C1AqQCmAnCBhNQCShYAVi8QAIhOgShMQgRhKgjgyQhbh/ixgKQhagFg+ARQhMAVgyA5IhahSII4qKIpvAAIAAiBIMwAAQAABNgBAPQgBAGgFAIIgLANIm3HyIgTAWQD/gUCcCVQCLCDAKDOQAKDNh1CWQh0CWi/AbQgzAIgwAAQiNAAh3hAg");
	this.shape_59.setTransform(84.7373,41.8876,0.1515,0.1515);

	this.shape_60 = new cjs.Shape();
	this.shape_60.graphics.f("#000000").s().p("AnkMqIAA5RIAOgCIEGAAQCbAABpAFQCxAIB6B6QB4B5ALCzQALCdgrBtQg0CEhlBIQhjBHiOAMQhGAGhnAAIivgBIgmAAIAAJygAlJAuIC2ACQBrABBIgFQBagFBDgtQBEguAmhUQAvhogRiTQgNhvhFhLQhGhMhtgRQgsgHg8gCIhrgCIi2AAg");
	this.shape_60.setTransform(30.7188,12.5834,0.1515,0.1515);

	this.shape_61 = new cjs.Shape();
	this.shape_61.graphics.f("#000000").s().p("AnjMqIAA5RIAOgCIEFAAQCbAABqAFQCwAIB5B5QB3B4ANCyQAKCGgfBoQgqCLhsBVQhuBXiQAIQhHADhnABIiuAAIgnAAIAAJygAlJqiIAALRICyACQBpABBGgEQBegGBEgsQBHgvAnhWQAqhdgJh2QgMiYhThTQhUhUiWgIQhAgDhfAAQhrACg1gBIgKADg");
	this.shape_61.setTransform(47.3244,12.5834,0.1515,0.1515);

	this.shape_62 = new cjs.Shape();
	this.shape_62.graphics.f("#000000").s().p("AnBMqIAA5TIODAAIAACHIroAAIAAI1IK8AAIAACIIq8AAIAAKJILoAAIAACGg");
	this.shape_62.setTransform(26.3508,41.6752,0.1515,0.1515);

	this.shape_63 = new cjs.Shape();
	this.shape_63.graphics.f("#000000").s().p("AkDMLQjfhmhwkEQhPi5AAjnQABk9CPjfQBhiWCWhPQCOhKCfAFQCgAFCKBSQCRBYBYCbQBKCCAeCXQAbCKgJCgQgMD0hwDCQh9DcjlBMQhiAhhgAAQiCAAiBg8gAhMq1Qh2AShZBGQhTBCg3BuQixFhCIGdQBADHClBkQClBjC3gwQC4gxBoirQA+hmAch7QAZhsABiFQAAiGgZhsQgch9hAhlQhUiGh3g5QhWgqhoAAQgpAAgsAHg");
	this.shape_63.setTransform(66.0038,12.6171,0.1515,0.1515);

	this.shape_64 = new cjs.Shape();
	this.shape_64.graphics.f("#000000").s().p("AgRNFQifgFiKhRQiRhWhYiaQiQj8AUlQQAOj2Bti6QCmkaElgmQDBgaCbBIQCZBGBuCjQBRB3AlCQQAiCCAACcQAACZghCBQgkCNhMB3QhgCViWBNQiFBGiVAAIgSAAgAhNq1Qh2AThYBFQhUBCg2BuQi9GACkGoQBJC9CsBVQCkBSCqg1QCrg1BjiiQA+hnAch6QAZhtAAiEQABiEgahuQgch7g/hnQhQiEh8g7QhZgqhmAAQgoAAgsAHg");
	this.shape_64.setTransform(66.1222,41.6908,0.1515,0.1515);

	this.shape_65 = new cjs.Shape();
	this.shape_65.graphics.f("#000000").s().p("AgQNFQiggFiJhSQiRhWhZiaQiNj3ARlLQANj9Bvi8QCgkREYgsQDGggCeBGQCeBFByCmQBSB3AlCRQAiCDAACeQAAE7iRDhQhgCViVBOQiHBGiVAAIgQAAgAhNq1QjmAjhyDkQiyFmCLGfQBBDBCgBiQCkBlC4gwQC4gwBpiqQA/hnAch9QAahwAAiNQgBkOh0i6QiSjoj1AAQgqAAguAHg");
	this.shape_65.setTransform(10.9501,12.6208,0.1515,0.1515);

	this.shape_66 = new cjs.Shape();
	this.shape_66.graphics.f("#000000").s().p("AF/MlQgSgKgSgYIjhk+Ijhk9QgJgNgKgGQgMgGgPABIkJAAIAAK5IiXAAIAA5RIAMgCQBlAADKgBQCygBB6AFQCzAHBvB0QBuByAGC1QADBXgMBDQgOBQgmBBQhkCsjYAZIgeADIIGK+IhGgBQgogBgaACIgLABQgVAAgQgIgAmdqiIAAKLIAJADIDUABQB9ABBWgDQC8gGBDilQAmhbgOiDQgMh0hFhFQhHhGhygFQhXgFiDABQiSABhKAAIgHADg");
	this.shape_66.setTransform(10.1419,41.6786,0.1515,0.1515);

	this.shape_67 = new cjs.Shape();
	this.shape_67.graphics.f("#000000").s().p("AHkMqQgKAAgPgWIuM1NIAAVjIiNAAIAA5UIBPgBQAuAAAgACQAJAAAPAXINeUFIAA0bICKAAIAAZTIg1ABQggAAgWgCg");
	this.shape_67.setTransform(44.7225,41.6752,0.1515,0.1515);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_67},{t:this.shape_66},{t:this.shape_65},{t:this.shape_64},{t:this.shape_63},{t:this.shape_62},{t:this.shape_61},{t:this.shape_60},{t:this.shape_59},{t:this.shape_58},{t:this.shape_57},{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.clear, new cjs.Rectangle(0,-0.1,112.9,80.3), null);


(lib.blue_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.blue();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.155,0.155);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.blue_1, new cjs.Rectangle(0,0,310,310), null);


(lib.black_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.black();
	this.instance.parent = this;
	this.instance.setTransform(0,0,0.155,0.155);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.black_1, new cjs.Rectangle(0,0,310,310), null);


(lib.now_available = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.Tween1("synched",0);
	this.instance.parent = this;
	this.instance.setTransform(41.45,7.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.0905,scaleY:1.0905},29).to({scaleX:1,scaleY:1},30).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-3.7,-0.7,90.4,16.5);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#999999").ss(1,1,1).p("AXrzhIgUAAIAAAKMAAAAm0A3qzhIAZAAIAAAKMAuoAAAAXrTiIAAgFIgUAAMguoAAAMAAAgm0A3qTiIAAgFIAZAA");
	this.shape.setTransform(150.025,125.05);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(240));

	// xhd
	this.instance = new lib.xhd();
	this.instance.parent = this;
	this.instance.setTransform(275.5,202,1,1,0,0,0,15.5,18);
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(126).to({_off:false},0).to({regX:15.6,regY:18.1,scaleX:1.3503,scaleY:1.3503,x:275.65,y:202.2},8).to({regX:15.5,regY:18,scaleX:1,scaleY:1,x:275.5,y:202},4).wait(102));

	// _4_mp
	this.instance_1 = new lib.night();
	this.instance_1.parent = this;
	this.instance_1.setTransform(237.5,203.8,1,1,0,0,0,16.5,17.8);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(123).to({_off:false},0).to({regX:16.6,scaleX:1.2633,scaleY:1.2633,x:237.65,y:203.85},8).to({regX:16.5,scaleX:1,scaleY:1,x:237.5,y:203.8},4).wait(105));

	// _8mp
	this.instance_2 = new lib.zoom();
	this.instance_2.parent = this;
	this.instance_2.setTransform(198,203.4,1,1,0,0,0,15,17.4);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(120).to({_off:false},0).to({regY:17.5,scaleX:1.2435,scaleY:1.2435,y:203.55},8).to({regY:17.4,scaleX:1,scaleY:1,y:203.4},4).wait(108));

	// button
	this.instance_3 = new lib.now_available();
	this.instance_3.parent = this;
	this.instance_3.setTransform(230.2,151.75,1,1,0,0,0,41.5,7.5);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(120).to({_off:false},0).wait(120));

	// clear
	this.instance_4 = new lib.clear();
	this.instance_4.parent = this;
	this.instance_4.setTransform(235.1,73.45,0.2784,0.2784,0,0,0,56.6,40.3);
	this.instance_4.alpha = 0;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(111).to({_off:false},0).to({regX:56.5,regY:40.1,scaleX:1.1778,scaleY:1.1774,x:233.75,y:72.35,alpha:0.8281},6).to({scaleX:1,scaleY:1,x:235.05,y:73.35,alpha:1},3).wait(120));

	// blue
	this.instance_5 = new lib.blue_1();
	this.instance_5.parent = this;
	this.instance_5.setTransform(149,373,1,1,0,0,0,155,155);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(104).to({_off:false},0).to({y:133},15).wait(121));

	// black
	this.instance_6 = new lib.black_1();
	this.instance_6.parent = this;
	this.instance_6.setTransform(149,371.3,1,1,0,0,0,155,155);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(98).to({_off:false},0).to({y:133},15).wait(127));

	// logo
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("EADjAvIMAAAha6IOLAAIAADAQAADAAEAAQAGAABphFQBmhCCshVQCthWCAgvQIsjNKEggQKEgfJSCVQHgB5GADeQF6DbEDEvQEDEvB6FsQB8FzgaGZQgqJ1mQHvQmSHvqxEPQjgBZjwA6QjvA6kgAkQiYATlFAAQlGAAifgTQnBg2mGiEQmFiDk0jLIhWg4IAAf3gEAr1gi7QnTA8lVCnQq5FViPKoQgTBYAAC3QAAC2ATBYQAyDrByDCQByDACuCSQDwDKE7B5QE8B5GVAvQCFAPETgFQESgECGgUQIShPFyjUQFyjUDElPQByjDApj2QAoj2gqjxQhYn1mllLQmklLqjhjQjngijtAAQjbAAjgAdgEhhZAvIMAAAha6IOMAAIAADAQAADAADAAQAEAAB8hNQJal5MuhqQMuhpMRDFQLDCxHqGTQHpGTC3IqQBqFEgFFZQgGFah1E5QiRGEkoE2QknE1mvDWQrzF4vGAAQmQAAlyhCQlzhDlIiCQiCgziXhNQiVhMhmhCIhohEIAAf5gEg5xgi2Qp/BemeEvQmdEwh0HMQg0DLAJDUQAJDTBEDAQCZGyGyEWQGyEVJ/BJQCBAOEVgDQEVgCB5gSQF/g2Erh6QErh7DfjBQCoiSByjEQByjFAsjfQAShaAAiuQAAitgShbQg0kGiSjfQiSjfjhigQhbhBidhPQidhOh1goQlMhvmAggQiOgLiLAAQjvAAjpAigEib9AYiQrOhAoLjfQpUj+lvmkQlwmjhmodQgThogGi/QgGi/AMhwQBKqKHJnsQHKnsL1j0QGTiBHYgoQHYgpG+A5QMvBpJRFrQJQFsEPIxQDdHJgaIGQgaIGkKGpQh3DBi5C6Qi5C6jLCFQk7DPl9CBQl8CCnKA5QhcAMk0AGQiVAEhhAAQhoAAgsgEgEiatgjQQnmAgmBCYQkWBujXCvQjWCuiBDcQiJDrgcEpQgdEqBXETQBeEoDuDuQDuDuFVCLQC5BMDfAzQDeAzDkATQBXAHDXgDQDXgCBcgKQFjgmEohkQEnhlDhifQC4iCCKi2QCKi2BCjGQAmh0ALhSQAMhRAAifQAAiegMhSQgLhRgmh1Qh8l9ldkPQlckQn9hwQlRhKloAAQh0AAh2AIgECSjAYiIiUgPQl3gjl2hxQl3hwkhikQmHjekMk2QkMk2h8l2QhVj9gNkVQgOkUA6kHQBYmMDulNQDulMF3j5QHvlJKsiJQKtiKK+BZQJHBJHaDSQHZDTFOFOQD/D+CTErQCTEsAqFeQALBbgBCaQgBCZgNBhQhcK3oLH4QoMH5tMDPQkAA+jHAYQjJAYksADIjoABQhiAAgVgCgECD0gfYQoMD/jWHDQg/CGgeCPQgeCPAACmQAADbA1C2QA1C1B0CsQDUE/GHDGQGIDGIUA6QBtAMDYACQDYABBvgKQHBgpFniRQFmiRDrjrQCfigBfixQBeizAkjUQAPhYAAiXQAAiXgQhbQhSnomWlOQmXlOp9hoQiagZh3gJQh5gKifAAQrKAAoND/g");
	this.shape_1.setTransform(37.9818,12.2071,0.0162,0.0162);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(240));

	// reno_3
	this.instance_7 = new lib.reno();
	this.instance_7.parent = this;
	this.instance_7.setTransform(62.15,162.9,1,1,0,0,0,50.9,40.3);
	this.instance_7.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).to({y:133.45,alpha:0.9688},8).to({y:111.4,alpha:1},6).wait(73).to({alpha:0},2).wait(151));

	// left
	this.instance_8 = new lib.left();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-138.75,247.6,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({x:91.45,y:178.5},14).wait(74).to({x:451.5,y:48.2},6).wait(146));

	// right
	this.instance_9 = new lib.right();
	this.instance_9.parent = this;
	this.instance_9.setTransform(368.1,55.35,1,1,0,0,0,150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({x:184.35,y:116.9},14).wait(74).to({x:-168.1,y:223.95},6).wait(146));

	// bg
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("A3qTiMAAAgnDMAvVAAAMAAAAnDg");
	this.shape_2.setTransform(150.025,125.05);

	this.timeline.addTween(cjs.Tween.get(this.shape_2).wait(240));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-168.1,48.2,769.6,479.8);
// library properties:
lib.properties = {
	id: 'AC2C3FEAC1FD4298A3ECA967FA50E2B3',
	width: 300,
	height: 250,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_P_.png", id:"index_atlas_P_"},
		{src:"images/index_atlas_P_2.png", id:"index_atlas_P_2"},
		{src:"images/index_atlas_P_3.png", id:"index_atlas_P_3"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['AC2C3FEAC1FD4298A3ECA967FA50E2B3'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;