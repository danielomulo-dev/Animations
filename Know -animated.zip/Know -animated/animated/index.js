(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[302,303,300,250],[0,303,300,250],[604,303,190,161],[0,0,650,301]]}
];


// symbols:



(lib._1 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib._2 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.logo = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.smoke_1 = function() {
	this.initialize(ss["index_atlas_P_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.Symbol4 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFF00").s().p("AgbAnIAAhMIATAAIAAAHQACgDAGgDQAEgCAGAAQAGAAAEABQAFACADAEIgOAOIgFgDIgGgBIgEACQgDABgCADQgCAEAAAEIAAAug");
	this.shape.setTransform(95.8,16.25);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFF00").s().p("AgOAlQgGgDgDgDQgFgGgCgHQgCgIAAgKQAAgJACgIQACgHAFgGQADgEAGgCQAGgDAIAAQAJAAAGADQAGACADAEQAFAGACAHQACAIAAAJQAAAKgCAIQgCAHgFAGQgDADgGADQgGACgJABQgIgBgGgCgAgEgVIgEADQgDADgBAFIgBAKIABALQABAFADADIAEACIAEABIAFgBIAEgCQADgDABgFIABgLIgBgKQgBgFgDgDIgEgDIgFgBIgEABg");
	this.shape_1.setTransform(87.775,16.3);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFF00").s().p("AgGAnIgehNIAVAAIAPAvIAQgvIAUAAIgdBNg");
	this.shape_2.setTransform(80,16.3);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFF00").s().p("AgQAmQgFgBgEgEQgDgDgCgFQgBgEAAgFQAAgHADgFQACgEAGgDQAGgDAJAAIASAAIAAgEQAAgGgEgDQgDgDgHAAQgFAAgEABQgDACgDADIgMgMQAFgGAHgDQAGgCAKAAQAPAAAJAHQAIAHAAAOIAAAyIgTAAIAAgGIgIAFQgEACgGAAQgHAAgEgCgAgKAJQgDACAAAEQAAAEADADQADACAGAAIAGgBQACAAADgDIACgEIABgGIAAgEIgPAAQgFAAgDADg");
	this.shape_3.setTransform(72.075,16.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFF00").s().p("AAGA1QgHAAgFgDQgFgDgCgFQgDgFAAgGIAAhTIATAAIAABSQAAAEABABQACACAEAAIAHAAIAAAQg");
	this.shape_4.setTransform(66.15,14.85);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFF00").s().p("AgLA2IAAg8IgJAAIAAgPIAJAAIAAgKQAAgFABgGQADgEAFgEQAEgDAIAAIALAAIAAARIgHAAQgEAAgCABQgBACAAAEIAAAIIAOAAIAAAPIgOAAIAAA8g");
	this.shape_5.setTransform(60.9,14.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFF00").s().p("AgKgWIAVAAIAAAdIgVAQg");
	this.shape_6.setTransform(52.675,20.375);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFF00").s().p("AgcAnIAAhMIATAAIAAAHQAEgDAEgDQAFgCAGAAQAGAAAFABQADACAFAEIgPAOIgEgDIgGgBIgGACQgCABgCADQgCAEAAAEIAAAug");
	this.shape_7.setTransform(47.7,16.25);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFF00").s().p("AgPAlQgHgEgFgJQgGgIAAgQQAAgMAFgJQADgJAIgEQAIgFAJAAQALAAAHAFQAIAFAEAIQAEAJAAAKIAAAIIgwAAQABAHAEAGQAEAEAHAAQAHAAADgCQAFgCADgDIAMAMIgIAGIgJAFQgGABgHAAQgIAAgJgDgAAPgGIAAgFIgCgEQgCgEgCgCQgEgCgFAAQgEAAgDACQgEACgBAEIgCAEIAAAFIAdAAIAAAAg");
	this.shape_8.setTransform(39.65,16.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFF00").s().p("AAGA1QgHAAgFgDQgFgDgCgFQgDgFAAgGIAAhTIATAAIAABSQAAAEABABQACACAEAAIAHAAIAAAQg");
	this.shape_9.setTransform(33.4,14.85);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFF00").s().p("AAGA1QgHAAgFgDQgFgDgDgFQgCgFAAgGIAAhTIASAAIAABSQAAAEACABQACACAEAAIAHAAIAAAQg");
	this.shape_10.setTransform(28.55,14.85);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFF00").s().p("AgPAlQgGgCgCgCQgFgFgCgGQgCgFABgHIAAgwIATAAIAAAuQAAAFACADQACADADABIAFACIAGgCQADgBACgDQACgDAAgFIAAguIAUAAIAABMIgTAAIAAgHQgEAEgFACQgFACgFABQgGgBgEgCg");
	this.shape_11.setTransform(21.5,16.35);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFF00").s().p("AgMA2IAAg8IgIAAIAAgPIAIAAIAAgKQABgFACgGQACgEAFgEQAEgDAIAAIALAAIAAARIgIAAQgDAAgBABQgCACAAAEIAAAIIAOAAIAAAPIgOAAIAAA8g");
	this.shape_12.setTransform(14.7,14.8);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFF00").s().p("AgKgWIAVAAIAAAdIgVAQg");
	this.shape_13.setTransform(6.475,20.375);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFF00").s().p("AgcAnIAAhMIATAAIAAAHQAEgDAFgDQAEgCAGAAQAGAAAEABQAFACADAEIgOAOIgFgDIgFgBIgFACQgDABgCADQgCAEAAAEIAAAug");
	this.shape_14.setTransform(1.5,16.25);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFF00").s().p("AgPAlQgIgEgEgJQgGgIAAgQQAAgMAEgJQAFgJAHgEQAIgFAJAAQALAAAIAFQAHAFAEAIQAEAJAAAKIAAAIIgwAAQAAAHAFAGQAEAEAHAAQAGAAAEgCQAEgCAEgDIAMAMIgJAGIgJAFQgFABgHAAQgIAAgJgDgAAPgGIgBgFIgBgEQgBgEgDgCQgEgCgFAAQgEAAgDACQgDACgCAEIgCAEIAAAFIAdAAIAAAAg");
	this.shape_15.setTransform(-6.55,16.3);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFF00").s().p("AANA1IAAgvQgBgGgBgCQgCgCgDgBIgGgCIgFACQgDABgCACQgCADAAAFIAAAvIgTAAIAAhpIATAAIAAAkQAEgFAFgBQAEgCAFAAQAJgBAFAEQAGAEADAGQADAHAAAHIAAAyg");
	this.shape_16.setTransform(-14.875,14.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFF00").s().p("AgGAmQgGgCgGgFQgFgEgDgHQgDgJAAgLQAAgLADgIQADgHAFgFQAGgFAGgBQAGgCAFAAQAIAAAGACQAGADAFAFIgNAOIgGgFQgDgBgDgBQgEABgCABQgCABgCADQgDADgBADIgBAKIABAKQABAFADACQACADACABQACACAEgBQADABADgCQADgCADgDIANANQgFAGgGACQgGADgIAAQgFAAgGgCg");
	this.shape_17.setTransform(-22.675,16.3);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFF00").s().p("AgIA2IAAhNIASAAIAABNgAgJglIAAgQIATAAIAAAQg");
	this.shape_18.setTransform(-28.5,14.825);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFF00").s().p("AgbAnIAAhMIATAAIAAAHQACgDAGgDQAEgCAGAAQAGAAAEABQAEACAEAEIgOAOIgEgDIgHgBIgEACQgDABgCADQgCAEAAAEIAAAug");
	this.shape_19.setTransform(-33.45,16.25);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFF00").s().p("AgbAnIAAhMIATAAIAAAHQACgDAGgDQAEgCAGAAQAGAAAEABQAEACAEAEIgOAOIgEgDIgHgBIgEACQgDABgCADQgCAEAAAEIAAAug");
	this.shape_20.setTransform(-43.8,16.25);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFF00").s().p("AgOAlQgIgEgGgJQgFgIAAgQQAAgMAEgJQAEgJAIgEQAIgFAJAAQALAAAHAFQAIAFAEAIQAEAJAAAKIAAAIIgwAAQAAAHAEAGQAFAEAIAAQAFAAAFgCQAEgCADgDIAMAMIgJAGIgJAFQgFABgHAAQgIAAgIgDgAAPgGIgBgFIgBgEQgBgEgEgCQgDgCgFAAQgEAAgDACQgDACgCAEIgBAEIgBAFIAdAAIAAAAg");
	this.shape_21.setTransform(-51.85,16.3);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFF00").s().p("AgGAnIgdhNIAUAAIAPAvIAQgvIAVAAIgdBNg");
	this.shape_22.setTransform(-59.65,16.3);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFF00").s().p("AgOAlQgGgDgDgDQgFgGgCgHQgCgIAAgKQAAgJACgIQACgHAFgGQADgEAGgCQAGgDAIAAQAJAAAGADQAGACADAEQAFAGACAHQACAIAAAJQAAAKgCAIQgCAHgFAGQgDADgGADQgGACgJABQgIgBgGgCgAgEgVIgEADQgDADgBAFIgBAKIABALQABAFADADIAEACIAEABIAFgBIAEgCQADgDABgFIABgLIgBgKQgBgFgDgDIgEgDIgFgBIgEABg");
	this.shape_23.setTransform(-67.425,16.3);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFF00").s().p("AgGAmQgGgCgGgFQgFgEgDgHQgDgJAAgLQAAgLADgIQADgHAFgFQAGgFAGgBQAGgCAFAAQAIAAAGACQAGADAFAFIgNAOIgGgFQgDgBgDgBQgEABgCABQgCABgCADQgDADgBADIgBAKIABAKQABAFADACQACADACABQACACAEgBQADABADgCQADgCADgDIANANQgFAGgGACQgGADgIAAQgFAAgGgCg");
	this.shape_24.setTransform(-74.975,16.3);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFF00").s().p("AgLAnQgFgBgGgCQgFgDgFgEIAMgNQAFAEAGACIAJABIAHgBIAFgCQACgCAAgDQAAgBAAAAQAAgBAAgBQAAAAgBgBQAAAAAAAAQgCgCgFgBIgLgBQgLgBgGgFQgGgFAAgKQAAgJAEgFQAEgGAHgCQAHgDAHAAQAJAAAHACQAIACAGAFIgMANQgDgEgGgBIgKgBQgEAAgDACQgCADgBADQAAAAABABQAAAAAAABQAAAAAAABQABAAAAAAQACACAEABIAMACQAMABAFAFQAGAFAAAKQAAAJgEAGQgFAFgHADQgIADgJAAIgLgBg");
	this.shape_25.setTransform(-82.55,16.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFF00").s().p("AgJA2IAAhNIATAAIAABNgAgJglIAAgQIATAAIAAAQg");
	this.shape_26.setTransform(-88.3,14.825);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFF00").s().p("AgPA0QgFgCgEgDQgDgEgCgGIgCgLIgBgMIABgMIACgLQACgFADgEQAEgEAFgBQAFgCAFAAQAFAAAFABQAFACADAFIAAgkIAUAAIAABqIgTAAIAAgIQgEAFgFACQgEACgFAAQgGAAgFgCgAgIgFQgCAEgBADIgBAMIABAMQABAFACADQADACAFAAQAGAAADgCQADgDABgFQABgFgBgHQABgGgBgGQgBgDgDgEQgDgDgGAAQgFAAgDADg");
	this.shape_27.setTransform(-94.725,14.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFF00").s().p("AgPA0QgFgCgEgDQgDgEgCgFIgCgMIgBgMIABgMIACgKQACgGADgEQAEgDAFgCQAFgCAFAAQAFAAAFABQAFACADAFIAAgkIAUAAIAABqIgTAAIAAgHQgEAEgFACQgEACgFAAQgGAAgFgCgAgIgFQgCADgBAEIgBAMIABAMQABAEACAEQADADAFAAQAGAAADgDQADgEABgEQABgGgBgGQABgHgBgFQgBgEgDgDQgDgCgGAAQgFAAgDACg");
	this.shape_28.setTransform(8.125,0.75);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFF00").s().p("AANAnIAAgtQAAgGgCgDQgCgDgDgBIgGgCIgFACQgDABgCADQgCADAAAGIAAAtIgUAAIAAhMIATAAIAAAGQAFgDAEgCQAFgCAFgBQAGABAFACQAEABAEADQAEAFACAFQABAGAAAHIAAAwg");
	this.shape_29.setTransform(-0.15,2.1);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFF00").s().p("AgQAmQgFgBgEgEQgDgDgCgFQgBgEAAgFQAAgHADgFQACgEAGgDQAGgDAJAAIASAAIAAgEQAAgGgEgDQgDgDgHAAQgFAAgEABQgDACgDADIgMgMQAFgGAHgDQAGgCAKAAQAPAAAJAHQAIAHAAAOIAAAyIgTAAIAAgGIgIAFQgEACgGAAQgHAAgEgCgAgKAJQgDACAAAEQAAAEADADQADACAGAAIAGgBQACAAADgDIACgEIABgGIAAgEIgPAAQgFAAgDADg");
	this.shape_30.setTransform(-8.725,2.125);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFF00").s().p("AgOAlQgGgDgDgDQgFgGgCgIQgCgHAAgKQAAgKACgHQACgHAFgFQADgFAGgCQAGgDAIAAQAJAAAGADQAGACADAFQAFAFACAHQACAHAAAKQAAAKgCAHQgCAIgFAGQgDADgGADQgGACgJABQgIgBgGgCgAgEgUIgEACQgDADgBAFIgBAKIABALQABAFADADIAEADIAEABIAFgBIAEgDQADgDABgFIABgLIgBgKQgBgFgDgDIgEgCIgFgBIgEABg");
	this.shape_31.setTransform(42.125,-12);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFF00").s().p("AgQA0QgIgCgFgGIAMgMQADADAEABQADACAFAAQAFAAAEgDQADgCABgEQACgDAAgEIAAgIQgEAEgFACQgEABgFAAQgGAAgFgBIgIgFQgDgEgBgFQgCgEgBgFIgBgMIABgNQABgGACgEQABgFADgDQAEgEAEgBQAFgCAGAAQAGAAAEACQAEACAEAEIAAgHIAUAAIAABKQgBAJgEAIQgEAHgIAEQgHAEgKAAQgJAAgGgCgAgIghQgCADgBAFIgBAKIABAJQABAFACACQADADAFAAQAGAAADgDQACgCABgFIABgJIgBgKQgBgFgCgDQgDgDgGAAQgFAAgDADg");
	this.shape_32.setTransform(33.7,-10.575);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFF00").s().p("AgOAlQgGgDgDgDQgFgGgCgIQgCgHAAgKQAAgKACgHQACgHAFgFQADgFAGgCQAGgDAIAAQAJAAAGADQAGACADAFQAFAFACAHQACAHAAAKQAAAKgCAHQgCAIgFAGQgDADgGADQgGACgJABQgIgBgGgCgAgEgUIgEACQgDADgBAFIgBAKIABALQABAFADADIAEADIAEABIAFgBIAEgDQADgDABgFIABgLIgBgKQgBgFgDgDIgEgCIgFgBIgEABg");
	this.shape_33.setTransform(25.625,-12);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFF00").s().p("AAGA1QgHAAgFgDQgFgDgDgFQgCgFAAgGIAAhUIASAAIAABTQAAADADACQABACADAAIAIAAIAAAQg");
	this.shape_34.setTransform(19.4,-13.45);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFF00").s().p("AgOAkQgJgDgFgIQgFgKAAgPQAAgMAEgJQAFgIAHgGQAIgEAJAAQALAAAIAFQAHAFAEAIQAEAJAAALIAAAHIgwAAQAAAIAEAEQAFAGAIAAQAFAAAEgCQAEgDAEgDIAMALIgJAHIgJAEQgFACgHAAQgIAAgIgEgAAPgHIgBgEIgBgEQgCgDgCgCQgEgDgFAAQgEAAgDADQgDACgCADIgBAEIgBAEIAdAAIAAAAg");
	this.shape_35.setTransform(9.1,-12);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFF00").s().p("AANA1IAAgvQgBgFgBgCQgCgDgDgCIgGgBIgFABQgDACgCADQgCACAAAFIAAAvIgTAAIAAhqIATAAIAAAkQAEgDAFgDQAEgCAFAAQAJABAFADQAGAEADAGQADAHAAAHIAAAyg");
	this.shape_36.setTransform(0.775,-13.45);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFF00").s().p("AAKAxQgIAAgEgDQgFgDgCgFQgDgFAAgGIAAgmIgIAAIAAgOIAIAAIAAgYIATAAIAAAYIAOAAIAAAOIgOAAIAAAlQAAADACACQABACAEAAIAHAAIAAAQg");
	this.shape_37.setTransform(-6.325,-13.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFF00").s().p("AAMA1IgTggIgIAJIAAAXIgTAAIAAhqIATAAIAAA9IAZggIAXAAIgcAfIAfAug");
	this.shape_38.setTransform(-16.1,-13.45);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFF00").s().p("AgGAmQgGgCgGgEQgFgFgDgIQgDgHAAgMQAAgLADgIQADgIAFgEQAGgEAGgCQAGgCAFAAQAIAAAGACQAGADAFAGIgNAMIgGgEQgDgBgDAAQgEAAgCABIgEADQgDADgBAEIgBAKIABAKQABAEADADQACADACABQACACAEAAQADAAADgCQADgBADgEIANANQgFAFgGADQgGADgIAAQgFAAgGgCg");
	this.shape_39.setTransform(-24.225,-12);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFF00").s().p("AgIA2IAAhNIASAAIAABNgAgJglIAAgQIATAAIAAAQg");
	this.shape_40.setTransform(-30.05,-13.475);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFF00").s().p("AAGA1QgHAAgFgDQgFgDgDgFQgCgFAAgGIAAhUIASAAIAABTQAAADACACQACACADAAIAIAAIAAAQg");
	this.shape_41.setTransform(-34.25,-13.45);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFF00").s().p("AgcAqIgGgHIgDgJQgBgJAAgRQAAgRABgJIADgIIAGgIQAMgLAQAAQAKAAAIAEQAJADAFAIQAFAHACALIgVAAQgCgHgEgEQgEgEgIAAQgDAAgEACQgDABgCADIgEAFIgBAJIgBAPIABAQIABAJIAEAFIAFAEQAEACADAAQAIgBAEgEQAEgEACgHIAVAAQgCALgFAIQgFAHgJAEQgIAEgKAAQgQAAgMgMg");
	this.shape_42.setTransform(-41.425,-13.425);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol4, new cjs.Rectangle(-100.8,-25.7,201.6,51.5), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib._1();
	this.instance.parent = this;
	this.instance.setTransform(-150,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-150,-125,300,250), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AmXGYQipipAAjvQAAjuCpipQCpipDuAAQDvAACpCpQCoCpABDuQgBDvioCpQipCojvABQjugBipiog");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-57.6,-57.6,115.30000000000001,115.30000000000001), null);


(lib.steam = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.smoke_1();
	this.instance.parent = this;
	this.instance.setTransform(106.5,0,0.3538,0.3538,90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.steam, new cjs.Rectangle(0,0,106.5,230), null);


(lib.Symbol4_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2_copy
	this.instance = new lib.steam();
	this.instance.parent = this;
	this.instance.setTransform(83,97.45,0.9274,0.9274,0,0,0,53.4,114.8);
	this.instance.alpha = 0.1016;
	this.instance._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(259).to({_off:false},0).to({scaleX:1.0492,scaleY:1.0492,y:11.75,alpha:0.25},47).to({regX:53.2,scaleX:1.1036,scaleY:1.1036,x:82.9,y:-26.55},21).wait(3));

	// Layer_1_copy
	this.instance_1 = new lib.steam();
	this.instance_1.parent = this;
	this.instance_1.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_1.alpha = 0.1016;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(234).to({_off:false},0).to({regX:53.2,scaleX:1.1036,scaleY:1.1036,x:82.9,y:-26.55,alpha:0.25},71).to({_off:true},1).wait(24));

	// Layer_2
	this.instance_2 = new lib.steam();
	this.instance_2.parent = this;
	this.instance_2.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_2.alpha = 0.1016;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(187).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(72));

	// Layer_1
	this.instance_3 = new lib.steam();
	this.instance_3.parent = this;
	this.instance_3.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_3.alpha = 0.1016;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(163).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.25},71).to({_off:true},1).wait(95));

	// Layer_2
	this.instance_4 = new lib.steam();
	this.instance_4.parent = this;
	this.instance_4.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_4.alpha = 0.1016;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(116).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(143));

	// Layer_1
	this.instance_5 = new lib.steam();
	this.instance_5.parent = this;
	this.instance_5.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_5.alpha = 0.1016;
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(92).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.25},71).to({_off:true},1).wait(166));

	// Layer_2
	this.instance_6 = new lib.steam();
	this.instance_6.parent = this;
	this.instance_6.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_6.alpha = 0.1016;
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(68).to({_off:false},0).to({regX:53.4,scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.25},48).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75},21).to({_off:true},3).wait(190));

	// Layer_1
	this.instance_7 = new lib.steam();
	this.instance_7.parent = this;
	this.instance_7.setTransform(83.1,117.5,0.7608,0.7608,0,0,0,53.5,114.8);
	this.instance_7.alpha = 0.1016;
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(44).to({_off:false},0).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.2383},72).to({_off:true},1).wait(213));

	// Layer_2
	this.instance_8 = new lib.steam();
	this.instance_8.parent = this;
	this.instance_8.setTransform(36.7,93.8,0.5638,0.5638,0,0,0,53.4,114.8);
	this.instance_8.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).to({scaleX:0.8607,scaleY:0.8607,x:83.05,y:47.25,alpha:0.2109},47).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,y:15.75,alpha:0.1016},21).to({_off:true},1).wait(261));

	// Layer_1
	this.instance_9 = new lib.steam();
	this.instance_9.parent = this;
	this.instance_9.setTransform(36.7,93.8,0.5638,0.5638,0,0,0,53.4,114.8);
	this.instance_9.alpha = 0.0898;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).to({regX:53.3,regY:114.6,scaleX:0.9053,scaleY:0.9053,x:83.05,y:15.75,alpha:0.3281},47).to({_off:true},1).wait(282));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(6.6,-153.2,135.20000000000002,358.4);


(lib.btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_3
	this.instance = new lib.Symbol4();
	this.instance.parent = this;
	this.instance.setTransform(0,97.85);
	this.instance.shadow = new cjs.Shadow("#000000",0,0,4);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(52));

	// logo
	this.instance_1 = new lib.logo();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-77.3,-65.5,0.8138,0.8138);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(52));

	// _3_copy
	this.instance_2 = new lib.Symbol2();
	this.instance_2.parent = this;
	this.instance_2.setTransform(0,0.3,0.4472,0.4472,0,0,0,0,0.2);
	this.instance_2.alpha = 0.6992;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(21).to({_off:false},0).to({regY:0.3,scaleX:0.7754,scaleY:0.7754,y:0.35,alpha:0.5},7).to({scaleX:1.1555,scaleY:1.1555,alpha:0.3008},8).to({scaleX:1.6755,scaleY:1.6755,y:0.4,alpha:0.1016},7).to({regY:0.2,scaleX:2.0908,scaleY:2.0908,y:0.25,alpha:0},8).wait(1));

	// _3
	this.instance_3 = new lib.Symbol2();
	this.instance_3.parent = this;
	this.instance_3.setTransform(0,0.3,0.4472,0.4472,0,0,0,0,0.2);
	this.instance_3.alpha = 0.6992;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(13).to({_off:false},0).to({regY:0.3,scaleX:0.7754,scaleY:0.7754,y:0.35,alpha:0.5},7).to({scaleX:1.1555,scaleY:1.1555,alpha:0.3008},8).to({scaleX:1.6755,scaleY:1.6755,y:0.4,alpha:0.1016},7).to({regY:0.2,scaleX:2.0908,scaleY:2.0908,y:0.25,alpha:0},8).to({_off:true},1).wait(8));

	// _2
	this.instance_4 = new lib.Symbol2();
	this.instance_4.parent = this;
	this.instance_4.setTransform(0,0.3,0.4472,0.4472,0,0,0,0,0.2);
	this.instance_4.alpha = 0.6992;
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(6).to({_off:false},0).to({regY:0.3,scaleX:0.7754,scaleY:0.7754,y:0.35,alpha:0.5},7).to({scaleX:1.1555,scaleY:1.1555,alpha:0.3008},8).to({scaleX:1.6755,scaleY:1.6755,y:0.4,alpha:0.1016},7).to({regY:0.2,scaleX:2.0908,scaleY:2.0908,y:0.25,alpha:0},8).to({_off:true},1).wait(15));

	// _1
	this.instance_5 = new lib.Symbol2();
	this.instance_5.parent = this;
	this.instance_5.setTransform(0,0.3,0.4472,0.4472,0,0,0,0,0.2);
	this.instance_5.alpha = 0.6992;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({regY:0.3,scaleX:0.7754,scaleY:0.7754,y:0.35,alpha:0.5},7).to({scaleX:1.1555,scaleY:1.1555,alpha:0.3008},8).to({scaleX:1.6755,scaleY:1.6755,y:0.4,alpha:0.1016},7).to({regY:0.2,scaleX:2.0908,scaleY:2.0908,y:0.25,alpha:0},8).to({_off:true},1).wait(21));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-120.5,-120.7,241.1,252.89999999999998);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		/* Click to Go to Frame and Play
		Clicking on the specified symbol instance moves the playhead to the specified frame in the timeline and continues playback from that frame.
		Can be used on the main timeline or on movie clip timelines.
		
		Instructions:
		1. Replace the number 5 in the code below with the frame number you would like the playhead to move to when the symbol instance is clicked.
		2.Frame numbers in EaselJS start at 0 instead of 1
		*/
		
		this.btn.addEventListener("click", fl_ClickToGoToAndPlayFromFrame.bind(this));
		
		function fl_ClickToGoToAndPlayFromFrame()
		{
			this.gotoAndPlay(23);
		}
	}
	this.frame_5 = function() {
		this.stop()
	}
	this.frame_71 = function() {
		this.stop()
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(5).call(this.frame_5).wait(66).call(this.frame_71).wait(2));

	// logo
	this.btn = new lib.btn();
	this.btn.name = "btn";
	this.btn.parent = this;
	this.btn.setTransform(150.3,114.5);

	this.timeline.addTween(cjs.Tween.get(this.btn).to({_off:true},6).wait(67));

	// front
	this.instance = new lib.Symbol3();
	this.instance.parent = this;
	this.instance.setTransform(150,125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(24).to({alpha:0},30,cjs.Ease.get(1)).wait(19));

	// smoke
	this.instance_1 = new lib.Symbol4_1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(98.6,-119.95,2.1591,2.1591,0,0,0,0.1,0.1);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(73));

	// Layer_2
	this.instance_2 = new lib._2();
	this.instance_2.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(73));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(150,67.6,150,182.4);
// library properties:
lib.properties = {
	id: 'FDD833783F763F45842C0323F2F39765',
	width: 300,
	height: 250,
	fps: 18,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/index_atlas_P_.png", id:"index_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['FDD833783F763F45842C0323F2F39765'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;