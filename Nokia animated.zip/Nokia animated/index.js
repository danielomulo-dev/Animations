(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"index_atlas_P_", frames: [[214,307,300,300],[214,0,297,305],[0,482,94,250],[0,0,212,480]]}
];


// symbols:



(lib.backphone = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.background = function() {
	this.initialize(img.background);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,418,300);


(lib.flashlight = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.nokia23 = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.phone = function() {
	this.spriteSheet = ss["index_atlas_P_"];
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.white = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// svg8
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#000000").s().p("AjLDOQhThSAAh8QAAiBBchRQBShKBvAAQB7AABTBUQBSBTAAB2QAABshIBSQhSBeiGAAQh4AAhShPgAhzh7QgxAyAABLQAABLAzAxQAwAvBBAAQBCAAAwgyQAxgyAAhIQAAhIgvgxQgvgyhFAAQhEAAgvAvg");
	this.shape.setTransform(-101,-13.8,0.104,0.104);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#000000").s().p("Ag4A5QgYgXAAgiQAAggAYgYQAXgYAhAAQAhAAAYAYQAYAYAAAgQAAAigYAXQgYAYghAAQghAAgXgYg");
	this.shape_1.setTransform(-96.4,-18.7,0.104,0.104);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#000000").s().p("AjKFQQhNhRAAh7QAAiCBThQQBMhLBoAAQBKAAA5ApQAdAUANAUIAAlXIB7AAIAAM0IhXAAQgOAAgLgLQgLgLAAgNIAAgjQgNAUgdAUQg4AphLAAQhvAAhLhQgAhsAGQguAyAABKQAABPAyAyQAuAvA/AAQBGAAAwg2QAtgzAAhFQAAhDgpgzQgvg4hLAAQhEAAgtAwg");
	this.shape_2.setTransform(-91.8,-15.1,0.104,0.104);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#000000").s().p("AgZESQgOAAgLgKQgKgKAAgPIAAoAIB5AAIAAIjg");
	this.shape_3.setTransform(-96.4,-13.7,0.104,0.104);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#000000").s().p("Ah4EVQgPAAgKgKQgKgKAAgPIAAoAIB5AAIAABcQASgrAhgZQAngeA5AAQAXAAAVAEIAAB/QgbgKggAAQg9AAglAyQgiAtAAA9IAAEUg");
	this.shape_4.setTransform(-106,-13.8,0.104,0.104);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#000000").s().p("AjKFQQhNhRAAh7QAAiCBThQQBMhLBoAAQBKAAA6ApQAcAUAOAUIAAlXIB6AAIAAM0IhXAAQgOAAgLgLQgKgLAAgNIAAgjQgOAUgcAUQg5AphLAAQhvAAhLhQgAhsAGQguAyAABKQAABPAyAyQAuAvA/AAQBGAAAwg2QAtgzAAhFQAAhDgpgzQgvg4hLAAQhEAAgtAwg");
	this.shape_5.setTransform(-111.9,-15.1,0.104,0.104);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#000000").s().p("ACjEYQgQAAgLgMQgKgLAAgPIAAkdQAAgvgbgkQgggog3AAQg9AAgnAxQgkAvAAA9IAAEhIhXAAQgPAAgKgKQgLgJAAgQIAAn/IB7AAIAABDQAXgiAmgVQAugZA5AAQBgAAA7BDQA1A8AABSIAAFeg");
	this.shape_6.setTransform(-118.4,-13.8,0.104,0.104);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#000000").s().p("AjKDNQhNhRAAh7QAAiBBThRQBMhLBpAAQBJAAA5ApQAdAUANAVIAAhGIB7AAIAAIjIhXAAQgOAAgLgMQgLgLAAgNIAAgjQgNAUgdAVQg4AohKAAQhvAAhMhQgAhth7QguAxAABKQABBOAyAzQAuAuA/AAQBGAAAwg1QAtg0AAhFQAAhCgpgzQgvg5hLAAQhDAAgvAyg");
	this.shape_7.setTransform(-125.2,-13.8,0.104,0.104);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#32DE84").s().p("ArbGaQASi5BkiYQBjiWCehVIh6jTQgFgIADgKQADgKAIgFQAJgFAKACQAKADAFAJIB7DVQCShDCmAAQCnAACSBDIB7jVQAFgJAKgDQAKgCAIAFQAJAFADAKQACAKgFAIIh5DTQCeBVBjCWQBkCYASC5gAEkBkQgSASAAAZQAAAZASATQASASAaAAQAZAAASgSQASgTAAgZQAAgZgSgSQgSgSgZAAQgaAAgSASgAl6BkQgSASAAAZQAAAZASATQASASAZAAQAZAAASgSQASgTAAgZQAAgZgSgSQgSgSgZAAQgZAAgSASg");
	this.shape_8.setTransform(-78.6,-15.2,0.104,0.104);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("A7QI6IAAxzMA2hAAAIAARzg");

	this.timeline.addTween(cjs.Tween.get(this.shape_9).wait(1));

}).prototype = getMCSymbolPrototype(lib.white, new cjs.Rectangle(-174.5,-57,349,114), null);


(lib.tssttsts = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgRBYIAAivIAjAAIAACvg");
	this.shape.setTransform(50,11.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAoBYIgLgkIg7AAIgLAkIghAAIA6ivIAiAAIA5CvgAAUAWIgUhEIgVBEIApAAg");
	this.shape_1.setTransform(39,11.9);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgbBfIAAhgIgWAAIAAgdIAWAAIAAgKQAAgKADgKQACgKAGgIQAGgHAJgFQAJgEAOgBQALABAHABIAKACIgDAbIgHgCIgJAAQgMAAgHAFQgGAGAAAOIAAALIAhAAIAAAdIghAAIAABgg");
	this.shape_2.setTransform(21.1,11.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgZA+QgLgFgIgJQgJgIgDgMQgFgMAAgQQAAgOAFgMQADgNAJgIQAIgJALgFQALgFAOABQAPgBALAFQAMAFAHAJQAJAIADANQAFAMAAAOQAAAQgFAMQgDAMgJAIQgHAJgMAFQgLAFgPgBQgOABgLgFgAgUgbQgIAKABARQgBASAIAKQAHAKANAAQAOAAAHgKQAHgKAAgSQAAgRgHgKQgHgKgOAAQgNAAgHAKg");
	this.shape_3.setTransform(9.1,14.4);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgoBAIAAh9IAfAAIABASIAFgHIAHgGIAKgFQAFgCAHAAIALAAIAEACIgDAcIgEgBIgJAAQgHAAgFACQgGADgFAFQgDAGgDAKQgCAIgBANIAAAzg");
	this.shape_4.setTransform(-8.2,14.2);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgRA/QgMgFgJgJQgJgHgFgOQgFgMAAgQQAAgOAEgMQADgNAIgIQAIgJAKgFQALgEAOAAQAbAAAPAQQAPARAAAjIAAAHIhSAAQABANAJAHQAJAIAPAAQAMAAAJgBIAMgEIAIAZIgOAFQgLADgSAAQgNAAgMgDgAAagNQgCgZgXAAQgMAAgGAGQgGAIgBALIAyAAIAAAAg");
	this.shape_5.setTransform(-19.9,14.4);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AATA/IgThMIgRBMIghAAIgjh9IAhAAIAUBaIAThUIAeAAIATBUIAUhaIAdAAIgiB9g");
	this.shape_6.setTransform(-35.3,14.4);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgZA+QgLgFgJgJQgHgIgEgMQgFgMAAgQQAAgOAFgMQAEgNAHgIQAJgJALgFQAMgFANABQAPgBALAFQALAFAIAJQAIAIAFANQADAMAAAOQAAAQgDAMQgFAMgIAIQgIAJgLAFQgLAFgPgBQgNABgMgFgAgUgbQgIAKAAARQAAASAIAKQAHAKANAAQAOAAAHgKQAHgKAAgSQAAgRgHgKQgHgKgOAAQgNAAgHAKg");
	this.shape_7.setTransform(-51.1,14.4);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("Ag7BcIAAi0IAeAAIAAAQIAGgHIAIgGIALgEQAEgCAHAAQAOAAAKAFQAKAFAHAIQAGAJADAMQADAMAAAOQABASgGALQgEANgJAIQgHAIgLAEQgKAEgKAAQgQAAgOgIIAAA8gAgUg0QgGALAAAUIAAAaQAGAEAGABQAGACAGAAQANAAAHgKQAIgIAAgUQAAgSgGgJQgGgJgOAAQgOAAgGAKg");
	this.shape_8.setTransform(-65,16.9);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgRA+QgMgEgJgIQgJgJgFgNQgFgMAAgQQAAgPAEgMQADgMAIgIQAIgJAKgFQALgEAOAAQAbAAAPAQQAPARAAAkIAAAGIhSAAQABANAJAIQAJAHAPAAQAMAAAJgCIAMgDIAIAZIgOAFQgLAEgSAAQgNAAgMgFgAAagNQgCgagXABQgMgBgGAIQgGAGgBAMIAyAAIAAAAg");
	this.shape_9.setTransform(59.8,-8.7);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AAXBeIAAhMQAAgOgFgFQgGgFgJAAQgHAAgFADQgFADgDAFQgDAGgBAHIgBAQIAAA8IghAAIAAi7IAhAAIAABMQAFgHAIgFQAJgGAOAAQAWAAAKAOQAKANAAAWIAABQg");
	this.shape_10.setTransform(46.3,-11.8);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgMBJQgLgKABgTIAAg7IgYAAIAAgcIAYAAIAAghIAggHIAAAoIAgAAIAAAcIggAAIAAA1QAAALAFAEQAFADAJAAIAJgBIAGgBIADAcIgLABIgQABQgXAAgJgLg");
	this.shape_11.setTransform(34.6,-10.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgoBAIAAh9IAeAAIABASIAGgHIAHgGIAKgFQAGgCAGAAIAKAAIAFACIgDAcIgEgBIgJAAQgGAAgGACQgGADgFAFQgDAGgDAKQgDAIAAANIAAAzg");
	this.shape_12.setTransform(19.5,-8.9);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgRA+QgMgEgJgIQgJgJgFgNQgFgMAAgQQAAgPAEgMQADgMAIgIQAIgJAKgFQALgEAOAAQAbAAAPAQQAPARAAAkIAAAGIhSAAQABANAJAIQAJAHAPAAQAMAAAJgCIAMgDIAIAZIgOAFQgLAEgSAAQgNAAgMgFgAAagNQgCgagXABQgMgBgGAIQgGAGgBAMIAyAAIAAAAg");
	this.shape_13.setTransform(7.9,-8.7);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgRA/Igsh9IAjAAIAaBcIAahcIAkAAIgtB9g");
	this.shape_14.setTransform(-5.3,-8.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgZA+QgMgFgHgIQgIgJgFgNQgDgMAAgPQAAgOADgNQAFgMAIgIQAHgJAMgFQALgEAOAAQAOAAAMAEQALAFAJAJQAHAIAEAMQAEANAAAOQAAAPgEAMQgEANgHAJQgJAIgLAFQgMAFgOAAQgOAAgLgFgAgVgbQgGAJgBASQABASAGAKQAIAKANAAQAOAAAHgKQAHgKAAgSQAAgRgHgKQgHgKgOAAQgNAAgIAKg");
	this.shape_15.setTransform(-18.8,-8.7);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgQA+QgMgFgHgIQgIgJgFgNQgDgMAAgPQgBgOAFgMQAEgMAJgJQAHgJAMgFQALgEAOAAQAJgBAIADIAMAFIAJAEIAEAEIgOAWIgEgBIgFgDIgIgDIgJgBQgNAAgIAJQgJAJABASQAAAUAHAIQAJAJAOAAQALAAAGgCIAJgFIANAXIgGAEIgIAEIgNAEQgHACgIAAQgOAAgMgFg");
	this.shape_16.setTransform(-31.4,-8.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgfA9QgOgEgHgGIAMgXIAIAFIAKADIANADIALACQAJAAAFgEQAFgCAAgHQAAgFgEgDQgEgDgKgCIgPgDQgHgCgHgDQgHgDgFgEQgEgEgDgGQgDgHAAgJQAAgIADgHQAEgHAGgGQAGgFAKgDQAJgDALAAQAPAAANADQANAEAHAEIgKAYIgPgGQgJgDgMAAIgGABIgHABQgDACgCACQgDACAAAEQAAAEAEADQACADAKADIAOACQAWAEAJAJQAKAKAAAPQAAATgNALQgNALgbAAQgRgBgOgFg");
	this.shape_17.setTransform(-43.4,-8.7);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgPBcIAAh9IAgAAIAAB9gAgNg5QgFgGAAgIQAAgJAFgGQAFgFAJAAQAIAAAFAFQAFAGAAAJQAAAIgFAGQgFAGgIAAQgJAAgFgGg");
	this.shape_18.setTransform(-52.1,-11.7);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AhIBYIAAivIA9AAQAVAAAQAGQAPAHALALQALAMAFARQAFAQAAASQAAAUgFARQgFAPgLAMQgKAMgRAGQgQAGgUAAgAglA6IAaAAQALAAAIgFQAJgEAHgHQAGgIADgLQADgKABgNQAAgcgOgOQgNgOgVgBIgaAAg");
	this.shape_19.setTransform(-63.4,-11.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.tssttsts, new cjs.Rectangle(-74.3,-30.6,148.6,61.2), null);


(lib.Symbol6 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A8cYZMAAAgwxMA45AAAMAAAAwxg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol6, new cjs.Rectangle(-182,-156,364.1,312.1), null);


(lib.Symbol5 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("A7GT7MAAAgn1MA2NAAAMAAAAn1g");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol5, new cjs.Rectangle(-173.5,-127.5,347.1,255.1), null);


(lib.Symbol3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgPAkQgEgBgDgDQgDgCgCgFQgCgEAAgHQgBgMAIgFQAHgFAPgBIADAAIAEABIADAAIACAAIAAgCQABgGgEgCQgDgDgGAAQgIAAgGACIgHAEIgFgOIACgBIAHgDIAIgCIAJgBQAQAAAIAHQAGAHAAAMIAAAtIgPAAIgCgGQgCADgFACQgFADgHAAIgJgBgAgJAGQgDADgBAFQABAFADACQACACAGAAQAFAAAFgDQADgFAAgFIAAgFIgFgBIgHAAQgHgBgCADg");
	this.shape.setTransform(-22.1,6.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgWAkIAAhGIARAAIAAAKIADgDIAEgEIAGgDIAGgBIAHABIACAAIgCAQIgCAAIgGgBIgGACIgFAEQgCADgCAGQgBAEAAAIIAAAcg");
	this.shape_1.setTransform(-27.8,6.6);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgDgHQgCgHAAgJQAAgIABgGQADgHAEgFQAEgFAHgDQAFgCAHAAQAQAAAIAJQAIAJAAAUIAAAEIgtAAQAAAHAFAEQAGAEAIAAIALgBIAHgCIAFAPIgIACQgHACgJAAQgHAAgHgCgAAPgHQgCgOgNAAQgFAAgEAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_2.setTransform(-34.3,6.7);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAhAkIAAgpQAAgOgKAAQgEAAgDABIgDAFIgDAHIgBAJIAAAhIgSAAIAAgpQAAgOgKAAQgEAAgCABQgDACgBADIgCAHIgBAJIAAAhIgTAAIAAhFIARAAIABAJIADgEIAEgEIAGgCIAGgBQAOAAAGAKQACgEAGgDQAFgDAIAAQANAAAGAHQAGAHAAANIAAAsg");
	this.shape_3.setTransform(-43.8,6.6);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAkQgEgBgEgDQgDgCgDgFQgCgEAAgHQAAgMAIgFQAHgFAOgBIAEAAIAEABIAEAAIABAAIAAgCQAAgGgDgCQgEgDgFAAQgJAAgFACIgHAEIgFgOIADgBIAGgDIAIgCIAKgBQAQAAAGAHQAIAHgBAMIAAAtIgQAAIgBgGQgCADgFACQgFADgGAAIgJgBgAgKAGQgDADAAAFQAAAFADACQAEACAEAAQAGAAAFgDQADgFAAgFIAAgFIgFgBIgHAAQgHgBgDADg");
	this.shape_4.setTransform(-53.4,6.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgMAwQgJgEgFgGQgFgHgEgJQgCgKAAgMQAAgJADgKQADgJAFgIQAGgHAJgEQAIgDAJAAQALAAAHACQAJAEAFAFIgKANIgHgEQgFgDgIAAQgGAAgEADQgFACgEAFQgCAEgCAHQgCAGAAAGIABAOQACAFADAFQADAEAFADQADADAGAAIAIgBIAGgCIAFgCIADgDIAKAOQgGAFgIADQgIADgLAAQgJAAgIgDg");
	this.shape_5.setTransform(-60.9,5.3);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AghAxIAAhhIAgAAQAJAAAHADQAHADAEAEQAFAFABAFQACAGAAAGQAAAGgCAFQgBAFgFAFQgEAEgHADQgIADgJAAIgMAAIAAAigAgOgBIALAAIAHAAIAFgDQADgCABgDQACgDAAgEQAAgEgCgDQgBgDgCgCQgDgCgDgBIgFgBIgNAAg");
	this.shape_6.setTransform(-72.5,5.3);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAcAxIAAhBIgVApIgOAAIgUgnIAAA/IgSAAIAAhhIAUAAIAZA0IAZg0IAVAAIAABhg");
	this.shape_7.setTransform(-82.2,5.3);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgUAyIgKgDIADgQIAJADIANABQAHAAAFgEQAFgEABgHQAAgFgFgEQgDgEgJAAIgMAAIAAgPIAMAAQAIAAADgEQAEgEABgGQAAgFgEgEQgEgDgGAAIgHABIgEACIgFACIgDADIgJgLIADgEIAHgEIAIgEQAFgBAGAAQAIAAAGACQAGACAEAEQADAEACAEQACAFAAAFQAAAEgCAEQgBAEgCADIgEAFIgGADIAGABIAFAFIAEAGQABAEABAFQgBAIgCAFQgCAGgFAEQgFAEgHACQgHACgGAAQgKAAgHgBg");
	this.shape_8.setTransform(-94.7,5.3);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAGAxIAAhMIgYANIgHgNIAigVIARAAIAABhg");
	this.shape_9.setTransform(-102.1,5.3);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgDgHQgDgHAAgJQAAgIACgGQADgHAEgFQAEgFAGgDQAHgCAHAAQAPAAAIAJQAIAJAAAUIAAAEIgtAAQAAAHAGAEQAFAEAIAAIALgBIAHgCIAFAPIgIACQgHACgJAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_10.setTransform(-111.9,6.7);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AANA0IAAgpQAAgJgDgCQgDgDgGAAQgDAAgCACQgEABgBADIgCAIIAAAIIAAAhIgTAAIAAhnIATAAIAAApQABgDAGgDQAEgDAIAAQAMAAAGAHQAFAIABALIAAAtg");
	this.shape_11.setTransform(-119.4,5);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgLIAAggIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAHADABQADACAFAAIAFAAIAEgBIABAPIgGABIgJABQgMAAgGgGg");
	this.shape_12.setTransform(-126,5.7);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AANA0IAAgpQAAgJgDgCQgDgDgFAAQgEAAgCACQgDABgCADIgCAIIgBAIIAAAhIgTAAIAAhnIATAAIAAApQADgDAFgDQAEgDAIAAQAMAAAGAHQAFAIAAALIAAAtg");
	this.shape_13.setTransform(-135.9,5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgLIAAggIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAHADABQADACAFAAIAFAAIAEgBIABAPIgGABIgJABQgMAAgGgGg");
	this.shape_14.setTransform(-142.5,5.7);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgJA0IAAhGIASAAIAABGgAgHgfQgCgEgBgEQABgFACgDQADgEAEAAQAFAAACAEQADADABAFQgBAFgDADQgCADgFAAQgEAAgDgDg");
	this.shape_15.setTransform(-146.8,5);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AALAjIgLgqIgKAqIgSAAIgThFIASAAIALAxIALguIARAAIAKAuIALgxIARAAIgTBFg");
	this.shape_16.setTransform(-153.4,6.7);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgYAzIAPgkIgZhBIATAAIAPAtIAQgtIAUAAIgqBlg");
	this.shape_17.setTransform(35.1,-12.9);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AANA1IAAgrQAAgIgDgCQgDgDgFAAQgEAAgDACQgDABgBADIgCAHIgBAJIAAAiIgTAAIAAhpIATAAIAAArQACgEAFgDQAFgDAIAAQANAAAFAIQAGAHgBAMIAAAtg");
	this.shape_18.setTransform(27.7,-16.1);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AghA0IAAhlIARAAIABAJIADgEIAEgDIAGgDIAGgBQAIAAAFADQAGADAEAFQADAEACAHQACAHAAAIQAAAKgDAGQgDAHgEAEQgEAFgGACQgGACgGAAQgIAAgIgEIAAAigAgLgdQgDAGAAAMIAAAOIAHADIAHAAQAGAAAEgFQAFgEAAgLQAAgKgEgFQgDgGgIAAQgHAAgEAGg");
	this.shape_19.setTransform(20,-13);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgPAkQgEgBgDgCQgDgDgCgEQgCgFAAgGQgBgMAIgFQAHgHAPABIADAAIAEAAIADAAIACAAIAAgCQAAgFgDgDQgEgDgFAAQgIAAgGACIgHADIgGgMIADgDIAGgCIAJgCIAJgBQAQAAAIAHQAGAHAAAMIAAAuIgPAAIgBgIQgDAEgFADQgFACgHAAIgJgBgAgJAGQgDADAAAFQAAAEADADQACADAGAAQAFgBAFgEQADgDAAgGIAAgGIgFAAIgHgBQgHAAgCADg");
	this.shape_20.setTransform(12.2,-14.4);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIADgFIAEgDIAGgDIAGgBIAHAAIACABIgCAQIgCgBIgGAAIgGABIgFAFQgCAEgCAFQgBAEAAAHIAAAdg");
	this.shape_21.setTransform(6.5,-14.5);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgNA0IgLgDQgEgCgEgEQgDgEAAgGQAAgGACgEQADgEADgCIgEgGIgBgHQAAgEADgDIAFgHQgEgEgBgEIgCgIQAAgHADgFQADgFAEgDQAFgDAFgBIALgCIAFABIAFAAIAEABIAEAAIARAAIAAANIgCAAIgEAAIgFgBQADACABAEIABAHQAAAHgCAEQgDAFgEADIgKAEIgKABIgHgBIgHgCIgBADIgBACQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAHAAIAOABIALABQAFACAEACQADACACAEQACAEAAAFQAAAFgDAFQgCAEgFAEQgFADgHACQgIACgIAAgAgSAaIgBAFQAAAFAEACQAFACAIAAQAKAAAFgDQAFgDAAgEQAAgEgDgBQgDgCgEAAIgKAAIgIAAIgGgBgAgFgmIgEACIgDAEIgBAGIABAFIADAEIAEACIAFAAIAEAAIAEgCIADgEIABgFIgBgGIgDgEIgEgCIgEAAg");
	this.shape_22.setTransform(-0.2,-12.9);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgNAjQgHgDgFgFQgEgFgCgHQgDgGAAgJQAAgIADgGQACgHAEgFQAFgFAHgDQAGgCAHAAQAIAAAHACQAGADAEAFQAFAFADAHQABAGAAAIQAAAJgBAGQgDAHgFAFQgEAFgGADQgHACgIAAQgHAAgGgCgAgKgPQgEAGgBAJQABAKAEAGQADAFAHAAQAIAAAEgFQAEgGAAgKQAAgJgEgGQgEgFgIAAQgHAAgDAFg");
	this.shape_23.setTransform(-7.9,-14.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgKIAAghIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAGADACQADACAFAAIAFgBIAEAAIABAQIgGAAIgJABQgMAAgGgGg");
	this.shape_24.setTransform(-14.6,-15.4);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgNAjQgHgDgEgFQgFgFgCgHQgCgGAAgJQAAgIACgGQACgHAFgFQAEgFAHgDQAGgCAHAAQAJAAAFACQAHADAEAFQAFAFACAHQACAGAAAIQAAAJgCAGQgCAHgFAFQgEAFgHADQgFACgJAAQgHAAgGgCgAgLgPQgDAGAAAJQAAAKADAGQAEAFAHAAQAIAAAEgFQAEgGAAgKQAAgJgEgGQgEgFgIAAQgHAAgEAFg");
	this.shape_25.setTransform(-21.1,-14.4);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AANA1IAAgrQAAgIgDgCQgDgDgGAAQgDAAgDACQgDABgBADIgCAHIAAAJIAAAiIgUAAIAAhpIAUAAIAAArQACgEAEgDQAFgDAIAAQANAAAFAIQAGAHgBAMIAAAtg");
	this.shape_26.setTransform(-28.8,-16.1);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AghA0IAAhlIARAAIABAJIADgEIAEgDIAGgDIAGgBQAIAAAFADQAGADAEAFQADAEACAHQACAHAAAIQAAAKgDAGQgDAHgEAEQgEAFgGACQgGACgGAAQgIAAgIgEIAAAigAgLgdQgDAGAAAMIAAAOIAHADIAHAAQAGAAAEgFQAFgEAAgLQAAgKgEgFQgDgGgIAAQgHAAgEAGg");
	this.shape_27.setTransform(-36.5,-13);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIAEgFIADgDIAGgDIAHgBIAFAAIADABIgCAQIgDgBIgEAAIgHABIgGAFQgBAEgBAFQgCAEAAAHIAAAdg");
	this.shape_28.setTransform(-46.3,-14.5);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgCgHQgEgHAAgJQAAgIACgGQADgHAEgFQAEgFAGgDQAGgCAIAAQAPAAAIAJQAJAJgBAUIAAAEIgtAAQABAHAFAEQAFAEAIAAIALgBIAIgCIADAPIgIACQgFACgKAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_29.setTransform(-52.8,-14.4);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgFAAQgEAAgCACQgDACgCADIgCAHIgBAIIAAAhIgTAAIAAhFIASAAIAAAJIADgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIAAAMIAAAsg");
	this.shape_30.setTransform(-60.3,-14.5);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgFAAQgEAAgCACQgDACgCADIgCAHIgBAIIAAAhIgTAAIAAhFIASAAIAAAJIADgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIAAAMIAAAsg");
	this.shape_31.setTransform(-67.9,-14.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgJA0IAAhGIASAAIAABGgAgHgfQgCgEgBgEQABgFACgDQADgEAEAAQAFAAACAEQADADABAFQgBAFgDADQgCADgFAAQgEAAgDgDg");
	this.shape_32.setTransform(-73.4,-16.1);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIABAKIADgFIADgDIAGgDIAHgBIAFAAIADABIgCAQIgDgBIgEAAIgHABIgGAFQgBAEgBAFQgCAEAAAHIAAAdg");
	this.shape_33.setTransform(-80.8,-14.5);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgZAdQgGgHAAgOIAAgrIATAAIAAAqQAAAIADACQADADAFAAQADAAADgCQADgCACgDIACgHIABgIIAAghIATAAIAABFIgRAAIgBgIQgDAEgFADQgGADgHAAQgNAAgFgHg");
	this.shape_34.setTransform(-87.7,-14.3);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgNAjQgHgDgEgFQgFgFgCgHQgCgGAAgJQAAgIACgGQACgHAFgFQAEgFAHgDQAGgCAHAAQAJAAAFACQAHADAEAFQAFAFACAHQACAGAAAIQAAAJgCAGQgCAHgFAFQgEAFgHADQgFACgJAAQgHAAgGgCgAgLgPQgDAGAAAJQAAAKADAGQAEAFAHAAQAIAAAEgFQAEgGAAgKQAAgJgEgGQgEgFgIAAQgHAAgEAFg");
	this.shape_35.setTransform(-95.4,-14.4);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgYAzIAPgkIgZhBIATAAIAPAtIAQgtIAUAAIgqBlg");
	this.shape_36.setTransform(-102.7,-12.9);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AANA1IAAgrQAAgIgDgCQgDgDgGAAQgDAAgDACQgDABgBADIgCAHIgBAJIAAAiIgTAAIAAhpIATAAIAAArQADgEAEgDQAFgDAIAAQANAAAFAIQAGAHgBAMIAAAtg");
	this.shape_37.setTransform(-113.5,-16.1);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgRAiQgIgCgEgDIAHgNIAEACIAGACIAHACIAGABQAFAAADgCQADgCAAgDQAAgDgDgCQgCgCgFgBIgIgBIgIgDQgEgBgDgDIgEgFQgCgEAAgFQAAgFACgEQACgEADgDQAEgDAFgBQAFgCAGAAQAJAAAHACQAHACAEACIgFANIgIgDQgGgBgGAAIgEAAIgDABIgEACIgBADQAAABABAAQAAABAAABQAAAAAAAAQABABAAAAQACACAFABIAIACQAMACAFAEQAGAGAAAJQgBAKgGAGQgIAGgPAAQgJAAgIgDg");
	this.shape_38.setTransform(-120.7,-14.4);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgPAkQgDgBgEgCQgEgDgBgEQgDgFAAgGQAAgMAIgFQAHgHAPABIADAAIAEAAIAEAAIABAAIAAgCQAAgFgDgDQgDgDgGAAQgJAAgFACIgHADIgFgMIACgDIAHgCIAIgCIAKgBQAQAAAGAHQAIAHgBAMIAAAuIgQAAIgBgIQgCAEgFADQgFACgHAAIgJgBgAgJAGQgEADAAAFQAAAEAEADQADADAEAAQAGgBAFgEQADgDAAgGIAAgGIgFAAIgHgBQgHAAgCADg");
	this.shape_39.setTransform(-127.6,-14.4);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgCgHQgDgHgBgJQABgIACgGQACgHAEgFQAEgFAHgDQAGgCAGAAQAQAAAIAJQAJAJAAAUIAAAEIguAAQABAHAEAEQAGAEAIAAIALgBIAIgCIADAPIgIACQgFACgKAAQgHAAgHgCgAAPgHQgCgOgNAAQgFAAgEAEQgEAEAAAGIAcAAIAAAAg");
	this.shape_40.setTransform(-134.5,-14.4);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgIA1IAAhpIASAAIAABpg");
	this.shape_41.setTransform(-139.8,-16.1);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgFAAQgEAAgCACQgDACgCADIgCAHIgBAIIAAAhIgTAAIAAhFIASAAIAAAJIADgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIAAAMIAAAsg");
	this.shape_42.setTransform(-145.3,-14.5);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgRAvQgHgCgFgGQgFgFgBgIQgDgIAAgKIAAg6IAUAAIAAA4IABANQABAFACADQADADADACQADABAFABQAGgBADgBQADgCADgDIADgIIABgMIAAg5IAUAAIAAA6QAAAKgCAIQgCAJgFAEQgEAGgIACQgHAEgLAAQgJAAgIgEg");
	this.shape_43.setTransform(-153.8,-15.7);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_1
	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#1B458D").s().p("A8MGzIAAtlMA4ZAAAIAANlg");

	this.timeline.addTween(cjs.Tween.get(this.shape_44).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol3, new cjs.Rectangle(-180.5,-43.4,361,86.9), null);


(lib.Symbol2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_2 copy 2
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgCgHQgDgHAAgJQAAgIACgGQACgHAEgFQAEgFAHgDQAGgCAGAAQAQAAAIAJQAJAJAAAUIAAAEIguAAQABAHAEAEQAGAEAIAAIALgBIAIgCIADAPIgIACQgFACgKAAQgHAAgHgCgAAPgHQgCgOgNAAQgFAAgEAEQgEAEAAAGIAcAAIAAAAg");
	this.shape.setTransform(139.2,23.6);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgNA0IgLgDQgEgCgEgEQgDgEAAgGQAAgGACgEQADgEADgCIgEgGIgBgHQAAgEADgDIAFgHQgEgEgBgEIgCgIQAAgHADgFQADgFAEgDQAFgDAFgBIALgCIAFABIAFAAIAEABIAEAAIARAAIAAANIgCAAIgEAAIgFgBQADACABAEIABAHQAAAHgCAEQgDAFgEADIgKAEIgKABIgHgBIgHgCIgBADIgBACQAAAAAAABQAAABAAAAQAAABABAAQAAABABAAQACACAHAAIAOABIALABQAFACAEACQADACACAEQACAEAAAFQAAAFgDAFQgCAEgFAEQgFADgHACQgIACgIAAgAgSAaIgBAFQAAAFAEACQAFACAIAAQAKAAAFgDQAFgDAAgEQAAgEgDgBQgDgCgEAAIgKAAIgIAAIgGgBgAgFgmIgEACIgDAEIgBAGIABAFIADAEIAEACIAFAAIAEAAIAEgCIADgEIABgFIgBgGIgDgEIgEgCIgEAAg");
	this.shape_1.setTransform(131.8,25.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgPAkQgEgBgDgCQgDgDgCgEQgCgFAAgGQgBgNAIgEQAHgHAPAAIADAAIAEABIADAAIACAAIAAgCQAAgFgDgDQgEgDgFAAQgIAAgGACIgHADIgGgMIADgCIAHgDIAIgCIAJgBQAQAAAIAHQAGAHAAAMIAAAtIgPAAIgBgHQgDAEgFACQgFADgHAAIgJgBgAgJAGQgDADAAAFQAAAFADACQACACAGABQAFAAAEgFQAEgEAAgFIAAgFIgFgBIgHAAQgHAAgCACg");
	this.shape_2.setTransform(124.3,23.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIADgFIAEgDIAGgDIAGgBIAGABIADAAIgCAQIgCgBIgGAAIgGACIgFAEQgCADgCAGQgBAEAAAHIAAAdg");
	this.shape_3.setTransform(118.6,23.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgOAjQgGgDgFgFQgEgFgCgHQgCgGgBgJQABgIACgGQACgHAEgFQAFgFAGgDQAHgCAHAAQAIAAAHACQAGADAFAFQAEAFADAHQACAGAAAIQAAAJgCAGQgDAHgEAFQgFAFgGADQgHACgIAAQgHAAgHgCgAgKgPQgFAGAAAJQAAAKAFAGQADAFAHAAQAIAAAEgFQAEgGAAgKQAAgJgEgGQgEgFgIAAQgHAAgDAFg");
	this.shape_4.setTransform(111.7,23.6);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgKIAAghIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAGADACQADACAFAAIAFgBIAEAAIABAPIgGABIgJABQgMAAgGgGg");
	this.shape_5.setTransform(105,22.6);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgRAiQgIgCgDgDIAFgNIAFACIAGACIAHACIAGABQAFAAADgCQACgCAAgDQAAgDgCgCQgCgCgGgBIgIgBIgIgDQgDgBgDgDIgEgFQgBgEgBgFQABgFABgEQACgEAEgDQADgDAGgBQAEgCAGAAQAJAAAHACQAHACAEACIgGANIgHgDQgGgBgHAAIgCAAIgEABIgEACIAAADQAAABAAAAQAAABAAABQAAAAAAAAQABABAAAAQABACAHABIAHACQAMACAFAEQAGAGgBAJQAAAKgGAGQgIAGgPAAQgJAAgIgDg");
	this.shape_6.setTransform(99.1,23.6);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgJA0IAAhoIASAAIAABog");
	this.shape_7.setTransform(90.8,21.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgOAkQgEgBgEgCQgEgDgCgEQgCgFAAgGQABgNAHgEQAHgHAOAAIAEAAIAEABIAEAAIACAAIAAgCQgBgFgDgDQgDgDgGAAQgJAAgEACIgIADIgGgMIAEgCIAFgDIAJgCIAJgBQARAAAGAHQAIAHAAAMIAAAtIgRAAIAAgHQgDAEgFACQgFADgGAAIgJgBgAgKAGQgCADAAAFQAAAFACACQADACAFABQAGAAAEgFQAFgEAAgFIAAgFIgGgBIgHAAQgHAAgDACg");
	this.shape_8.setTransform(85.4,23.6);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgFAAQgEAAgCACQgDACgCADIgCAHIgBAIIAAAhIgSAAIAAhFIARAAIABAJIACgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIABAMIAAAsg");
	this.shape_9.setTransform(78.2,23.5);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIAEgFIADgDIAGgDIAHgBIAFABIADAAIgCAQIgDgBIgEAAIgHACIgGAEQgBADgBAGQgCAEAAAHIAAAdg");
	this.shape_10.setTransform(72.1,23.5);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgCgHQgEgHAAgJQAAgIACgGQADgHAEgFQAEgFAGgDQAGgCAIAAQAPAAAIAJQAJAJgBAUIAAAEIgtAAQABAHAFAEQAFAEAIAAIALgBIAIgCIAEAPIgJACQgFACgKAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_11.setTransform(65.6,23.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgKIAAghIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAGADACQADACAFAAIAFgBIAEAAIABAPIgGABIgJABQgMAAgGgGg");
	this.shape_12.setTransform(59.1,22.6);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgFAAQgEAAgCACQgDACgCADIgCAHIgBAIIAAAhIgSAAIAAhFIARAAIAAAJIADgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIAAAMIAAAsg");
	this.shape_13.setTransform(52.7,23.5);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgJAxIAAhhIATAAIAABhg");
	this.shape_14.setTransform(47,22.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgiAxIAAhhIAiAAQAIAAAGACQAGACADAEQAEAEACAEIABAJQAAAFgBAEQgCADgCADIgFAEIgFACIAHACQAEAAADADQACADACAFQACAEAAAHQAAAGgCAFQgCAFgEAEQgFADgGACQgHACgIAAgAgPAhIAQAAQAIAAADgEQAEgEAAgFQgBgHgEgDQgEgDgHAAIgPAAgAgPgJIANAAQAEAAAFgCQADgDABgGQgBgHgDgCQgEgDgEAAIgOAAg");
	this.shape_15.setTransform(37.7,22.2);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgNAwQgIgEgGgHQgGgGgCgJQgDgKAAgMQAAgKADgKQADgJAFgHQAGgHAIgDQAJgEAKgBQAKAAAIADQAHADAHAFIgJANIgIgEQgGgDgHAAQgHAAgEADQgFADgEAEQgDAFgBAGQgCAHAAAGQAAAHACAHQABAGADAFQAEADAFAEQAEACAHAAIAHAAIAGgCIAAgZIgRAAIAAgPIAjAAIAAA1IgFACIgGACIgKACIgNABQgJgBgJgDg");
	this.shape_16.setTransform(28.8,22.2);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgeAyIAAgCQAAgIACgGIAFgMQADgGAFgFIAMgKQAHgFAEgFQAFgGAAgGIAAgEIgDgEIgDgDIgGgBQgEAAgDABIgGADIgFAEIgDAEIgMgKIAEgFIAHgGIAKgFQAGgCAGAAQAJAAAGACQAGACADAEQAEAEACAFQACAFAAAFQAAAGgCAFIgFAJIgHAGIgJAHQgKAIgDAFQgFAGgBAEIAqAAIAAAQg");
	this.shape_17.setTransform(17,22.1);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgUAyIgKgDIADgQIAJADIANABQAHAAAFgEQAFgEABgHQAAgFgFgEQgDgEgJAAIgMAAIAAgPIAMAAQAIAAADgEQAEgEABgGQAAgFgEgEQgEgDgGAAIgHABIgEACIgFACIgDADIgJgLIADgEIAHgEIAIgEQAFgBAGAAQAIAAAGACQAGACAEAEQADAEACAEQACAFAAAFQAAAEgCAEQgBAEgCADIgEAFIgGADIAGABIAFAFIAEAGQABAEABAFQgBAIgCAFQgCAGgFAEQgFAEgHACQgHACgGAAQgKAAgHgBg");
	this.shape_18.setTransform(9.7,22.2);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgHAJQgDgEAAgFQAAgDADgEQADgEAEABQAFgBADAEQADADAAAEQAAAGgDADQgDACgFAAQgEAAgDgCg");
	this.shape_19.setTransform(1.1,26.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	// Layer_2 copy
	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgcAmQgJgNAAgZQAAgXAKgOQAJgNASAAQATAAAJANQAKANAAAYQAAAYgKAOQgJANgTAAQgSAAgKgNgAgMgZQgFAIAAARQAAASAFAIQAEAJAIAAQAJAAAEgJQAFgJAAgRQAAgRgFgIQgEgJgJAAQgIAAgEAJg");
	this.shape_20.setTransform(69.3,3.6);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAGAxIAAhMIgYANIgHgNIAigVIARAAIAABhg");
	this.shape_21.setTransform(61.1,3.6);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgOAzQgFgCgEgEQgFgEgCgHQgDgHAAgKQAAgIACgHQACgGAEgEQADgGAGgCQAFgDAIgBQAGAAAFADQAFACACAEIAAgpIATAAIAABoIgQAAIgBgHIgHAFQgFADgHAAQgGAAgGgCgAgKABQgEAGAAAKQAAAKAEAFQAEAGAHAAIAFgBIAEgCIADgCIACgDIAAgMIgBgJQAAgFgCgCIgFgEQgDgBgEgBQgHABgDAEg");
	this.shape_22.setTransform(50.7,3.4);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgIA0IAAhGIASAAIAABGgAgHgfQgCgEAAgEQAAgFACgDQADgEAEAAQAFAAADAEQADADAAAFQAAAFgDADQgDADgFAAQgEAAgDgDg");
	this.shape_23.setTransform(45.2,3.4);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgNAjQgHgDgEgFQgFgFgCgHQgCgGAAgJQAAgIACgGQACgHAFgFQAEgFAHgDQAGgCAHAAQAJAAAFACQAHADAEAFQAFAFACAHQACAGAAAIQAAAJgCAGQgCAHgFAFQgEAFgHADQgFACgJAAQgHAAgGgCgAgLgPQgDAGAAAJQAAAKADAGQAEAFAHAAQAIAAAEgFQAEgGAAgKQAAgJgEgGQgEgFgIAAQgHAAgEAFg");
	this.shape_24.setTransform(39.6,5);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIADgFIAEgDIAGgDIAGgBIAHABIACAAIgCAQIgCgBIgGAAIgGABIgFAFQgCAEgCAFQgBAEAAAHIAAAdg");
	this.shape_25.setTransform(33.4,5);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgOAzQgFgCgEgEQgFgEgCgHQgDgHAAgKQAAgIACgHQACgGAEgEQADgGAGgCQAFgDAIgBQAGAAAFADQAFACACAEIAAgpIATAAIAABoIgQAAIgBgHIgHAFQgFADgHAAQgGAAgGgCgAgKABQgEAGAAAKQAAAKAEAFQAEAGAHAAIAFgBIAEgCIADgCIACgDIAAgMIgBgJQAAgFgCgCIgFgEQgDgBgEgBQgHABgDAEg");
	this.shape_26.setTransform(26.3,3.4);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgGAAQgDAAgCACQgEACgBADIgCAHIAAAIIAAAhIgTAAIAAhFIARAAIABAJIACgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIABAMIAAAsg");
	this.shape_27.setTransform(18.7,4.9);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AAWAxIgGgUIggAAIgHAUIgSAAIAhhhIASAAIAgBhgAALAMIgLglIgMAlIAXAAg");
	this.shape_28.setTransform(10.6,3.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgHAJQgDgEAAgFQAAgDADgEQADgDAEAAQAFAAADADQADADAAAEQAAAGgDADQgDACgFAAQgEAAgDgCg");
	this.shape_29.setTransform(1.1,7.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20}]}).wait(1));

	// Layer_2
	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgGAAQgDAAgCACQgEACgBADIgCAHIAAAIIAAAhIgTAAIAAhFIARAAIABAJIACgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIABAMIAAAsg");
	this.shape_30.setTransform(171.7,-13.6);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgDgHQgDgHAAgJQAAgIACgGQADgHAEgFQAEgFAGgDQAHgCAHAAQAPAAAIAJQAIAJAAAUIAAAEIgtAAQAAAHAGAEQAFAEAIAAIALgBIAHgCIAFAPIgIACQgHACgJAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_31.setTransform(164.4,-13.5);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgDgHQgDgHAAgJQAAgIACgGQADgHAEgFQAEgFAGgDQAHgCAHAAQAPAAAIAJQAIAJAAAUIAAAEIgtAAQAAAHAGAEQAFAEAIAAIALgBIAHgCIAFAPIgIACQgHACgJAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgDAEgBAGIAcAAIAAAAg");
	this.shape_32.setTransform(157.2,-13.5);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgWAkIAAhFIARAAIAAAKIAEgFIADgDIAGgDIAHgBIAFAAIADABIgCAQIgCgBIgGAAIgGABIgGAFQgBAEgBAFQgCAEAAAHIAAAdg");
	this.shape_33.setTransform(151.2,-13.6);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgEgFgCgHQgCgHAAgIQAAgHACgHQACgHAFgFQAEgFAHgCQAGgDAHAAQAGAAAEABIAHADIAFACIACACIgIANIgCgBIgDgCIgEgBIgGgBQgGAAgFAFQgFAFAAAKQAAALAFAFQAFAFAHAAQAGAAAEgCIAFgCIAHANIgDACIgFACIgHACIgJABQgHAAgHgCg");
	this.shape_34.setTransform(145,-13.5);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AgRAiQgHgCgFgDIAGgNIAFACIAGACIAHACIAGABQAFAAADgCQACgCAAgDQAAgDgBgCQgDgCgFgBIgIgBIgIgDQgEgBgDgDIgEgFQgBgEAAgFQAAgFABgEQACgEADgDQAEgDAFgBQAGgCAFAAQAJAAAHACQAHACAEACIgGANIgIgDQgFgBgGAAIgEAAIgDABIgDACIgBADQAAABAAAAQAAABAAABQAAAAAAAAQABABAAAAQABACAHABIAHACQALACAGAEQAFAGABAJQAAAKgIAGQgHAGgPAAQgJAAgIgDg");
	this.shape_35.setTransform(138.4,-13.5);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgNA0IgLgDQgEgCgEgEQgDgEAAgGQAAgGACgEQADgEADgCIgEgGIgBgHQAAgEADgDIAFgHQgEgEgBgEIgCgIQAAgHADgFQADgFAEgDQAFgDAFgBIALgCIAFABIAFAAIAEABIAEAAIARAAIAAANIgCAAIgEAAIgFgBQADACABAEIABAHQAAAHgCAEQgDAFgEADIgKAEIgKABIgHgBIgHgCIgBADIgBACQAAABAAAAQAAABAAAAQAAABABAAQAAABABAAQACACAHAAIAOABIALABQAFACAEACQADACACAEQACAEAAAFQAAAFgDAFQgCAEgFAEQgFADgHACQgIACgIAAgAgSAaIgBAFQAAAFAEACQAFACAIAAQAKAAAFgDQAFgDAAgEQAAgEgDgBQgDgCgEAAIgKAAIgIAAIgGgBgAgFgmIgEACIgDAEIgBAGIABAFIADAEIAEACIAFAAIAEAAIAEgCIADgEIABgFIgBgGIgDgEIgEgCIgEAAg");
	this.shape_36.setTransform(128,-12);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AANAkIAAgpQAAgIgDgDQgDgDgGAAQgDAAgCACQgEACgBADIgCAHIAAAIIAAAhIgTAAIAAhFIARAAIABAJIACgEIAFgEIAFgCIAIgBQAMAAAGAHQAFAIABAMIAAAsg");
	this.shape_37.setTransform(120.4,-13.6);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgJA0IAAhGIASAAIAABGgAgHgfQgCgEgBgEQABgFACgDQADgEAEAAQAFAAADAEQACADAAAFQAAAFgCADQgDADgFAAQgEAAgDgDg");
	this.shape_38.setTransform(114.9,-15.2);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgKIAAghIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAGADACQADACAFAAIAFgBIAEAAIABAQIgGAAIgJABQgMAAgGgGg");
	this.shape_39.setTransform(110.5,-14.5);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgPAkQgEgBgDgCQgDgDgCgEQgCgFAAgGQAAgMAHgFQAHgHAOABIAEAAIAEAAIADAAIADAAIAAgCQAAgFgEgDQgEgDgFAAQgJAAgEACIgIADIgGgMIADgDIAGgCIAJgCIAJgBQAQAAAIAHQAGAHABAMIAAAuIgQAAIgBgIQgDAEgFADQgFACgHAAIgJgBgAgKAGQgCADAAAFQAAAEACADQAEADAFAAQAFgBAEgEQAEgDABgGIAAgGIgGAAIgHgBQgHAAgDADg");
	this.shape_40.setTransform(104.1,-13.5);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AgJAjIgZhFIAUAAIAOAzIAPgzIAUAAIgZBFg");
	this.shape_41.setTransform(97.1,-13.5);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgIA0IAAhGIARAAIAABGgAgHgfQgDgEABgEQgBgFADgDQADgEAEAAQAFAAADAEQACADAAAFQAAAFgCADQgDADgFAAQgEAAgDgDg");
	this.shape_42.setTransform(91.8,-15.2);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgHApQgFgGAAgKIAAghIgNAAIAAgQIANAAIAAgSIARgEIAAAWIATAAIAAAQIgTAAIAAAdQAAAGADACQADACAFAAIAFgBIAEAAIABAQIgGAAIgJABQgMAAgGgGg");
	this.shape_43.setTransform(87.3,-14.5);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AghA0IAAhlIARAAIABAJIADgEIAEgDIAGgDIAGgBQAIAAAFADQAGADAEAFQADAEACAHQACAHAAAIQAAAKgDAGQgDAHgEAEQgEAFgGACQgGACgGAAQgIAAgIgEIAAAigAgLgdQgDAGAAAMIAAAOIAHADIAHAAQAGAAAEgFQAFgEAAgLQAAgKgEgFQgDgGgIAAQgHAAgEAGg");
	this.shape_44.setTransform(80.8,-12.1);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgPAkQgEgBgDgCQgDgDgDgEQgBgFAAgGQAAgMAHgFQAHgHAPABIADAAIAEAAIADAAIADAAIAAgCQAAgFgEgDQgEgDgFAAQgJAAgEACIgIADIgGgMIADgDIAGgCIAJgCIAJgBQAQAAAIAHQAGAHABAMIAAAuIgQAAIgBgIQgDAEgFADQgFACgHAAIgJgBgAgJAGQgDADAAAFQAAAEADADQADADAFAAQAFgBAEgEQAEgDABgGIAAgGIgGAAIgHgBQgHAAgCADg");
	this.shape_45.setTransform(73.1,-13.5);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgJAjQgGgDgFgFQgEgFgCgHQgCgHAAgIQAAgHACgHQACgHAFgFQAEgFAHgCQAGgDAHAAQAGAAAEABIAHADIAFACIACACIgIANIgCgBIgDgCIgEgBIgGgBQgGAAgFAFQgFAFAAAKQAAALAFAFQAFAFAHAAQAGAAAEgCIAFgCIAHANIgDACIgFACIgHACIgJABQgHAAgHgCg");
	this.shape_46.setTransform(66.5,-13.5);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgJAjQgHgDgFgEQgFgFgDgHQgCgHAAgJQAAgIABgGQADgHAEgFQAEgFAGgDQAGgCAIAAQAPAAAIAJQAIAJAAAUIAAAEIgtAAQAAAHAGAEQAFAEAIAAIALgBIAHgCIAFAPIgIACQgHACgJAAQgHAAgHgCgAAPgHQgBgOgNAAQgHAAgDAEQgEAEAAAGIAcAAIAAAAg");
	this.shape_47.setTransform(56.3,-13.5);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgOAzQgFgCgEgEQgFgEgCgHQgDgHAAgLQAAgHACgGQACgHAEgEQADgGAGgCQAFgEAIAAQAGAAAFADQAFADACADIAAgpIATAAIAABoIgQAAIgBgHIgHAFQgFADgHAAQgGAAgGgCgAgKABQgEAGAAAJQAAAMAEAEQAEAGAHAAIAFgBIAEgCIADgCIACgDIAAgMIgBgJQAAgFgCgCIgFgEQgDgBgEgBQgHABgDAEg");
	this.shape_48.setTransform(48.5,-15.2);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgJA0IAAhGIASAAIAABGgAgHgfQgCgEgBgEQABgFACgDQADgEAEAAQAFAAACAEQADADAAAFQAAAFgDADQgCADgFAAQgEAAgDgDg");
	this.shape_49.setTransform(43,-15.2);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AALAjIgLgqIgKAqIgSAAIgThFIASAAIALAxIALguIAQAAIALAuIALgxIARAAIgTBFg");
	this.shape_50.setTransform(36.4,-13.5);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgGATIgCglIARAAIgCAlg");
	this.shape_51.setTransform(26.6,-18);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgeAyIAAgCQAAgIACgGIAFgMQADgGAFgFIAMgKQAHgFAEgFQAFgGAAgGIAAgEIgDgEIgDgDIgGgBQgEAAgDABIgGADIgFAEIgDAEIgMgKIAEgFIAHgGIAKgFQAGgCAGAAQAJAAAGACQAGACADAEQAEAEACAFQACAFAAAFQAAAGgCAFIgFAJIgHAGIgJAHQgKAIgDAFQgFAGgBAEIAqAAIAAAQg");
	this.shape_52.setTransform(21.2,-15);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgHAJQgDgEAAgFQAAgDADgEQADgEAEAAQAFAAADAEQADADAAAEQAAAFgDAEQgDACgFAAQgEAAgDgCg");
	this.shape_53.setTransform(15.8,-11);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgZAoQgJgLAAgWQAAgbALgPQALgPAUAAIAHAAIAGACIAHACIAFADIgHAOIgHgDQgFgCgGAAQgJAAgGAHQgGAHgCANQAEgEAFgDQAGgCAFAAQAGAAAFACQAGACAEAEQAEAEADAFQACAHAAAIQAAAIgDAHQgDAGgFAFQgFAEgGADQgGACgHAAQgPAAgKgLgAgFAAIgFAEIgDAGIgBAGIABAIQAAADACADIAFAEQADACADAAQAEAAADgCIAFgEIADgFIABgHQAAgJgEgFQgEgEgHAAQgDAAgDAAg");
	this.shape_54.setTransform(10.2,-14.9);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AgHAJQgDgEAAgFQAAgDADgEQADgEAEAAQAFAAADAEQADADAAAEQAAAFgDAEQgDACgFAAQgEAAgDgCg");
	this.shape_55.setTransform(1,-11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30}]}).wait(1));

	// Layer_1
	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#1B458D").s().p("A8MIhIAAxBMA4ZAAAIAARBg");

	this.timeline.addTween(cjs.Tween.get(this.shape_56).wait(1));

}).prototype = getMCSymbolPrototype(lib.Symbol2, new cjs.Rectangle(-180.5,-54.4,361,108.9), null);


(lib.phone333 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.nokia23();
	this.instance.parent = this;
	this.instance.setTransform(-47,-125);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone333, new cjs.Rectangle(-47,-125,94,250), null);


(lib.phone_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.phone();
	this.instance.parent = this;
	this.instance.setTransform(29.1,-151.3,0.446,0.446,38.2);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.phone_1, new cjs.Rectangle(-103.3,-151.3,206.8,226.8), null);


(lib.nokialogo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AB3CTIgbgyIgCgBIizAAIgbAyIhnABICiklIB1AAICgEjIAAACgAg3AgIBwAAIg5hog");
	this.shape.setTransform(69.9,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5CWQgwAAgggGQgRgDgPgMQgQgNgFgRIgDgSIABioQABgPALgPQALgMAPgIQATgIAdgCIAzgCICPAAQAmACASAGQAeAJANAZQAHARAAARIgBCfQAAAPgKAOQgKANgOAIQgaALgnACIhGABIgvAAIgiAAgAhtg/QAABtABAWQABAEAGACIAJACIClABIAVgCQANgBAEgJIABh7IgBgKQgCgEgMgEIi8AAQgRADgBAKg");
	this.shape_1.setTransform(-27.2,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhngDIgBACIAACUIhcAAIAAklIBcAAIAACOIAAAAICdiOIB7AAIioCPIAAABIC9CUIiGABg");
	this.shape_2.setTransform(15.6,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtCTIAAkkIAAgBIBaAAIABElg");
	this.shape_3.setTransform(41.6,0.1);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA7CTIizjdIAADcIhWABIgBklICWAAICyDcIABjcIBWAAIAAElg");
	this.shape_4.setTransform(-71,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.nokialogo, new cjs.Rectangle(-91.8,-15,183.7,30.1), null);


(lib.nokia233 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgSAuIgJgCIADgJIAGABIANABQAJAAAGgEQAGgEAAgJQAAgHgFgEQgFgFgJAAIgKAAIAAgKIAJAAIAIAAIAGgEIAEgFIAAgHQABgGgEgFQgEgDgIAAIgHAAIgFACIgEACIgDADIgHgGIAEgEIAFgDIAIgDIAJgCQAHAAAFACQAGACADADQADADABAFQACAEAAAEQAAAEgBAEIgDAHIgGAEIgGAEIAHACIAGAEIADAHQACAEAAAEQAAAHgDAEQgCAGgFADQgEAEgGACQgGABgGAAQgIAAgGgBg");
	this.shape.setTransform(21.1,0.2);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgFAGQgCgCAAgEQAAgDACgCQACgCADAAQAEAAACACQACACAAADQAAAEgCACQgCACgEAAQgDAAgCgCg");
	this.shape_1.setTransform(16.6,4.1);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgaAvIAAgCQAAgHABgHIAFgKIAIgKIALgJIAGgGIAFgFIAEgFIABgHQAAgHgEgEQgEgDgHAAIgHABIgGACIgEAEIgDADIgHgGIAEgFIAGgFIAIgDQAEgCAFAAQAHABAFACQAFACAEADIAFAHIABAJQAAAFgCAEQgBAFgDADIgGAHIgIAGQgJAIgGAGQgFAHgBAHIAqAAIAAALg");
	this.shape_2.setTransform(11.7,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgLAhIgHgDQgDgCgCgEQgDgFAAgFQAAgKAHgFQAHgGAMgBIAEABIAFAAIAEAAIADABIAAgEQAAgHgEgDQgFgEgHAAQgHABgEACIgHACIgEgIIADgCIAFgCIAHgCIAIAAQAMAAAHAFQAHAGAAAMIAAArIgKAAIgBgIQgDAFgGACQgFACgGAAIgHgBgAgGACQgDABgCACQAAAAgBABQAAAAAAABQgBAAAAABQAAAAAAABIgBAFQAAAGADACQAEADAGAAIAFgBIAGgDIAEgFQACgDAAgEIAAgHIgCAAIgEgBIgFAAIgFAAIgGABg");
	this.shape_3.setTransform(2.5,1.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgEAvIAAhAIAKAAIAABAgAgEghQgCgCAAgDQAAgEACgCQACgCACAAQADAAACACQACADAAADQAAADgCACQgCADgDAAQgCAAgCgDg");
	this.shape_4.setTransform(-1.8,0.1);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AAOAxIgegjIAAAjIgMAAIAAhhIAMAAIAAA9IAbgcIAOAAIgbAcIAfAkg");
	this.shape_5.setTransform(-5.9,-0.1);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgMAgQgFgCgEgFQgFgFgCgGQgBgHAAgHQAAgGABgHQACgGAFgFQAEgEAFgCQAGgDAGAAQAHAAAGADQAFACAFAEQADAFACAGQACAHABAGQgBAIgCAGQgCAHgDAEQgFAFgFACQgGACgHAAQgGAAgGgCgAgNgRQgEAIgBAJQABALAEAGQAEAHAJAAQAJAAAFgHQAFgHgBgKQABgEgCgFIgDgHIgGgFQgEgCgEAAQgJAAgEAGg");
	this.shape_6.setTransform(-12.9,1.5);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAWAuIgqhGIAABGIgNAAIAAhbIANAAIAqBFIAAhFIAMAAIAABbg");
	this.shape_7.setTransform(-20.5,0.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.nokia233, new cjs.Rectangle(-26.7,-10.8,53.5,21.8), null);


(lib.nokia = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.backphone();
	this.instance.parent = this;
	this.instance.setTransform(150,-150,1,1,90);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.nokia, new cjs.Rectangle(-150,-150,300,300), null);


(lib.logoooo = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AB2CSIgbgyIgBgBIizAAIgcAyIhmABIChkkIB1AAIChEjIAAABgAg3AgIBvAAIg4hog");
	this.shape.setTransform(69.9,0.1);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("Ag5CWQgvAAgggGQgRgDgQgMQgQgNgEgRIgDgTIABioQABgOAMgPQAKgMAPgJQATgHAdgDIAzgBICNAAQAmACATAGQAdAJANAZQAHAOAAAUIAACeQgCAfggAVQgZALgoACIhFAAIgvAAIgjAAgAhbhNQgQAEgCAJIABCDQACAEAFACIAJACIClAAIAWgBQAMgCAFgJIAAh7IgBgKQgCgGgLgCg");
	this.shape_1.setTransform(-27.1,0);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhmgDIgCACIAACUIhcAAIAAklIBcAAIAACOIAMgJICRiFIB6AAIioCPIABABIC9CUIiGABg");
	this.shape_2.setTransform(15.6,0.1);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgtCTIAAkkIABgBIBYABIACEkg");
	this.shape_3.setTransform(41.6,0);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AA7CTIizjdIAADcIhWABIgBklICWAAICyDcIABjcIBWAAIAAElg");
	this.shape_4.setTransform(-71,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.logoooo, new cjs.Rectangle(-91.8,-15,183.8,30.1), null);


(lib.flashlight_1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.flashlight();
	this.instance.parent = this;
	this.instance.setTransform(-107.6,-110.5,0.725,0.725);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.flashlight_1, new cjs.Rectangle(-107.6,-110.5,215.2,221), null);


(lib.labelll = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgOAjIgHgCIACgKIAGABIAKAAQAEAAAEgCQAEgDAAgEQAAgFgDgDQgDgCgGAAIgIAAIAAgLIAIAAQAFAAADgDQADgCAAgFQAAgDgCgCQgDgDgEgBIgFABIgEACIgDACIgCABIgHgIIADgCIAEgDIAHgDIAIgBQAFABAEABIAHAEIAEAGIABAGIgBAHIgCAEIgDAEIgFACIAFABIAEAEIACAEQACADAAADQAAAGgCAEQgCAEgEADQgDADgFABQgFABgEAAQgIAAgEgBg");
	this.shape.setTransform(40.9,0.7);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgFAGQgCgDAAgDQAAgDACgCQACgCADAAQAEAAACACQACACAAADQAAAEgCACQgCACgEAAQgDAAgCgCg");
	this.shape_1.setTransform(37.2,3.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgVAkIAAgCIABgJIADgJIAHgIIAIgHIAIgHQAEgEgBgFIAAgDIgCgCIgCgCIgFgCIgEACIgFACIgDACIgCADIgIgGIACgFIAGgEIAGgEQAFgBAEAAQAGAAAEACQAEACADADQACACACAEIABAHIgBAHIgEAHIgEAEIgHAFIgJAJQgEAFAAADIAeAAIAAALg");
	this.shape_2.setTransform(33.1,0.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAQAjIgFgOIgXAAIgEAOIgNAAIAXhFIANAAIAXBFgAAIAJIgIgbIgIAbIAQAAg");
	this.shape_3.setTransform(25,0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgGAjIAAhFIANAAIAABFg");
	this.shape_4.setTransform(20.6,0.7);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AANAjIgbgkIAAAkIgOAAIAAhFIAOAAIAAAgIAZggIAPAAIgaAgIAdAlg");
	this.shape_5.setTransform(16.4,0.7);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgNAiQgGgDgEgFQgEgEgCgHQgCgHAAgIQAAgHACgHQACgGAEgFQAEgFAGgDQAGgDAHAAQAJAAAFADQAHADADAFQAEAFACAGQACAHAAAHQAAAIgCAHQgCAHgEAEQgDAFgHADQgFADgJAAQgHAAgGgDgAgMgQQgEAGAAAKQAAALAEAHQAFAGAHAAQAJAAAEgGQAFgHAAgLQAAgKgFgGQgEgHgJAAQgHAAgFAHg");
	this.shape_6.setTransform(9.2,0.7);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AAOAjIgbgtIAAAtIgNAAIAAhFIANAAIAbAtIAAgtIANAAIAABFg");
	this.shape_7.setTransform(2.3,0.7);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1B458D").s().p("Ao5BuIAAjbIRzAAIAADbg");
	this.shape_8.setTransform(47,0);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.labelll, new cjs.Rectangle(-10,-11,114,22), null);


(lib.btnn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgXAdQgKgKAAgTQAAgIACgHQADgIAEgEQAEgGAHgCQAHgDAHAAQAIAAAFACQAHACADAFQAFAFACAIQACAHAAAKIAAACIg0AAQABALAFAHQAHAGALAAQAIAAAFgBIAHgCIAEAKIgDACIgFABIgIABIgJABQgSAAgJgKgAAUgGQgBgKgFgGQgDgFgKAAQgJAAgFAFQgEAGgBAKIAmAAIAAAAg");
	this.shape.setTransform(29.9,0.9);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgVAmIAAhKIALAAIABANIAEgGIAFgDIAGgEQADgBAFAAIAFAAIAEABIgCAMIgDgBIgFgBQgKABgFAIQgHAJAAAOIAAAgg");
	this.shape_1.setTransform(23.9,0.8);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgOAlQgGgDgFgGQgFgEgCgIQgCgHAAgJQAAgIACgHQACgHAFgFQAFgGAGgCQAHgDAHAAQAIAAAHADQAGACAFAGQAEAEADAIQACAHAAAIQAAAJgCAIQgDAGgEAFQgFAGgGADQgHACgIAAQgHAAgHgCgAgPgTQgFAIAAALQAAAMAFAIQAFAHAKAAQALAAAFgHQAFgIAAgMIgBgKQgBgFgDgDQgDgFgEgCQgEgBgFAAQgKAAgFAHg");
	this.shape_2.setTransform(16.8,0.9);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AAhA1IAAhRIgbA3IgMAAIgag2IAABQIgNAAIAAhpIAPAAIAeA/IAfg/IAPAAIAABpg");
	this.shape_3.setTransform(7.2,-0.7);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AASAmIAAgsIgBgKQgBgEgCgCIgFgDIgGAAQgFgBgEADQgEADgDAEQgCAEgBAGIgCAJIAAAjIgNAAIAAhJIAMAAIABAKIADgEIAFgEIAHgDQADgBAFAAQANgBAHAIQAHAHAAAOIAAAvg");
	this.shape_4.setTransform(-5.7,0.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgWAmIAAhKIANAAIAAANIADgGIAGgDIAGgEQAEgBAEAAIAFAAIADABIgBAMIgDgBIgFgBQgKABgFAIQgGAJAAAOIAAAgg");
	this.shape_5.setTransform(-11.8,0.8);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgNAmQgFgBgDgCQgEgDgDgFQgCgEAAgHQAAgMAIgFQAIgIAOABIAFAAIAFAAIAFABIADAAIAAgEQAAgJgFgEQgEgDgJAAQgIAAgFACIgIADIgFgKIAEgCIAGgCIAIgBIAJgBQAOAAAIAGQAIAHAAAMIAAAyIgMAAIgBgIQgDAFgHADQgGACgGAAIgJgBgAgIACIgFAEIgDAEIgBAGQAAAHAFADQADADAIAAQACAAAEgCIAGgDQAEgCABgEQACgDAAgEIAAgJIgCAAIgFAAIgFgBIgGAAQgEAAgEABg");
	this.shape_6.setTransform(-18.7,0.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgXAdQgJgKAAgTQAAgIABgHQADgIAFgEQADgGAHgCQAHgDAHAAQAIAAAFACQAHACADAFQAFAFACAIQACAHAAAKIAAACIg0AAQABALAFAHQAHAGALAAQAIAAAFgBIAHgCIAEAKIgDACIgFABIgIABIgJABQgSAAgJgKgAAUgGQgBgKgFgGQgDgFgKAAQgJAAgFAFQgEAGgCAKIAnAAIAAAAg");
	this.shape_7.setTransform(-26,0.9);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgdA1IAAhpIAOAAIAABcIAtAAIAAANg");
	this.shape_8.setTransform(-33,-0.7);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1B458D").s().p("AoMCMIAAkXIQZAAIAAEXg");

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

}).prototype = getMCSymbolPrototype(lib.btnn, new cjs.Rectangle(-52.5,-14,105,28), null);


(lib.background1 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1B458D").s().p("A8MXXMAAAgutMA4ZAAAMAAAAutg");

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

}).prototype = getMCSymbolPrototype(lib.background1, new cjs.Rectangle(-180.5,-149.4,361,299), null);


(lib.fresss = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.instance = new lib.btnn();
	this.instance.parent = this;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({scaleX:1.11,scaleY:1.11},23).to({scaleX:1,scaleY:1},23).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-52.5,-14,105,28);


// stage content:
(lib.index = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// logo
	this.instance = new lib.nokialogo();
	this.instance.parent = this;
	this.instance.setTransform(150,125);
	this.instance.alpha = 0;

	this.timeline.addTween(cjs.Tween.get(this.instance).to({alpha:1},17,cjs.Ease.get(1)).wait(17).to({alpha:0},10,cjs.Ease.get(1)).to({_off:true},16).wait(277));

	// frame1
	this.instance_1 = new lib.background1();
	this.instance_1.parent = this;
	this.instance_1.setTransform(160.5,131.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(34).to({x:484.5},25,cjs.Ease.get(1)).to({_off:true},1).wait(277));

	// white
	this.instance_2 = new lib.Symbol5();
	this.instance_2.parent = this;
	this.instance_2.setTransform(156.6,125.6);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(233).to({_off:false},0).to({alpha:1},2).to({alpha:0},2).to({_off:true},2).wait(98));

	// nokia 2.3 txt
	this.instance_3 = new lib.nokia233();
	this.instance_3.parent = this;
	this.instance_3.setTransform(125.8,180.7);
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(235).to({_off:false},0).to({_off:true},101).wait(1));

	// txt
	this.instance_4 = new lib.tssttsts();
	this.instance_4.parent = this;
	this.instance_4.setTransform(173.3,121.9);
	this.instance_4._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(235).to({_off:false},0).to({_off:true},101).wait(1));

	// nokia
	this.instance_5 = new lib.logoooo();
	this.instance_5.parent = this;
	this.instance_5.setTransform(190.9,23.5);
	this.instance_5._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_5).wait(235).to({_off:false},0).to({_off:true},101).wait(1));

	// nokia--phone
	this.instance_6 = new lib.phone333();
	this.instance_6.parent = this;
	this.instance_6.setTransform(53,120);
	this.instance_6._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_6).wait(235).to({_off:false},0).to({_off:true},101).wait(1));

	// btn copy
	this.instance_7 = new lib.fresss();
	this.instance_7.parent = this;
	this.instance_7.setTransform(231.6,217);
	this.instance_7._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_7).wait(236).to({_off:false},0).to({_off:true},100).wait(1));

	// btn
	this.instance_8 = new lib.btnn();
	this.instance_8.parent = this;
	this.instance_8.setTransform(231.6,217);
	this.instance_8._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(235).to({_off:false},0).to({_off:true},1).wait(101));

	// white
	this.instance_9 = new lib.white();
	this.instance_9.parent = this;
	this.instance_9.setTransform(154.5,248);
	this.instance_9._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_9).wait(235).to({_off:false},0).to({_off:true},101).wait(1));

	// flashing light
	this.instance_10 = new lib.flashlight_1();
	this.instance_10.parent = this;
	this.instance_10.setTransform(132.6,82.5);
	this.instance_10.alpha = 0;
	this.instance_10._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_10).wait(225).to({_off:false},0).to({alpha:1},6).wait(2).to({alpha:0},5).to({_off:true},2).wait(97));

	// Label
	this.instance_11 = new lib.labelll();
	this.instance_11.parent = this;
	this.instance_11.setTransform(336.6,30);
	this.instance_11._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_11).wait(50).to({_off:false},0).to({x:250.6},34,cjs.Ease.get(1)).to({_off:true},152).wait(101));

	// Layer_4
	this.instance_12 = new lib.nokia();
	this.instance_12.parent = this;
	this.instance_12.setTransform(-138,80);
	this.instance_12._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_12).wait(180).to({_off:false},0).to({x:54},30,cjs.Ease.get(1)).to({_off:true},26).wait(101));

	// background2
	this.instance_13 = new lib.Symbol3();
	this.instance_13.parent = this;
	this.instance_13.setTransform(482.1,194.2);
	this.instance_13._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_13).wait(180).to({_off:false},0).to({x:243.1},30,cjs.Ease.get(1)).to({_off:true},26).wait(101));

	// phone
	this.instance_14 = new lib.phone_1();
	this.instance_14.parent = this;
	this.instance_14.setTransform(22,431.1);
	this.instance_14._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_14).wait(50).to({_off:false},0).to({x:216,y:195.1},34,cjs.Ease.get(1)).wait(79).to({x:438},30,cjs.Ease.get(1)).to({_off:true},1).wait(143));

	// blue background1
	this.instance_15 = new lib.Symbol2();
	this.instance_15.parent = this;
	this.instance_15.setTransform(-183,118);
	this.instance_15._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_15).wait(50).to({_off:false},0).to({x:8},34,cjs.Ease.get(1)).wait(79).to({x:-183,alpha:0},30,cjs.Ease.get(1)).to({_off:true},2).wait(142));

	// white
	this.instance_16 = new lib.Symbol6();
	this.instance_16.parent = this;
	this.instance_16.setTransform(144.1,125.1);
	this.instance_16.alpha = 0;
	this.instance_16._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_16).wait(50).to({_off:false},0).to({alpha:0.328},34,cjs.Ease.get(1)).wait(79).to({alpha:0},30,cjs.Ease.get(1)).to({_off:true},1).wait(143));

	// background
	this.instance_17 = new lib.background();
	this.instance_17.parent = this;
	this.instance_17.setTransform(-25,-12,0.873,0.873);

	this.timeline.addTween(cjs.Tween.get(this.instance_17).wait(337));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(125,107.1,366,299);
// library properties:
lib.properties = {
	id: 'EEABD359699744C6A819CEB91FAEDAE6',
	width: 300,
	height: 250,
	fps: 24,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/background.jpg", id:"background"},
		{src:"images/index_atlas_P_.png", id:"index_atlas_P_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EEABD359699744C6A819CEB91FAEDAE6'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}



})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;